local PLUGIN = PLUGIN or {}

PLUGIN.name = "AdminPlus"
PLUGIN.author = "Gary Tate"
PLUGIN.description = "Enhanced Administration."

-- @todo allow for second parameter deciding admin tier (admin, superadmin, founder, etc)
function PLUGIN:SetAdminAccessLevel(command)
	ix.command.list[command:lower()].OnCheckAccess = function(self, client)
		return client:IsAdmin()
	end
end

PLUGIN:SetAdminAccessLevel("Event")
PLUGIN:SetAdminAccessLevel("CharGiveFlag")
PLUGIN:SetAdminAccessLevel("CharTakeFlag")
PLUGIN:SetAdminAccessLevel("CharSetModel")
PLUGIN:SetAdminAccessLevel("CharGiveItem")
PLUGIN:SetAdminAccessLevel("PlyWhitelist")
PLUGIN:SetAdminAccessLevel("PlyUnwhitelist")

if SERVER then

	ix.chat.Register("help", {
		color = Color(255, 50, 50),
		deadCanChat = true,
		OnChatAdd = function(self, speaker, text, bAnonymous, data)
			local icon = ix.util.GetMaterial("icon16/error.png")
			chat.AddText(icon, Color(255,100,100), "@help ", speaker, color_white, ": "..text)
		end
	})

	ix.chat.Register("warn", {
		color = Color(255, 75, 75),
		deadCanChat = true,
		OnChatAdd = function(self, speaker, text, bAnonymous, data)
			local icon = ix.util.GetMaterial("icon16/bell.png")
			chat.AddText(icon, self.color, "Warning: ", text)
		end
	})

end

function PLUGIN:OnLoaded()
	timer.Simple(0, function()
		ix.chat.classes.ooc.OnChatAdd = function(self, speaker, text)
			-- @todo remove and fix actual cause of speaker being nil
			if (!IsValid(speaker)) then
				return
			end

			local icon = "icon16/user.png"

			if (speaker:IsSuperAdmin()) then
				icon = "icon16/shield.png"
			elseif (speaker:IsAdmin()) then
				icon = "icon16/star.png"
			elseif (speaker:IsUserGroup("moderator") or speaker:IsUserGroup("operator")) then
				icon = "icon16/wrench.png"
			elseif (speaker:IsUserGroup("vip") or speaker:IsUserGroup("donator") or speaker:IsUserGroup("donor")) then
				icon = "icon16/heart.png"
			end

			icon = Material(hook.Run("GetPlayerIcon", speaker) or icon)

			--chat.AddText(icon, Color(255, 50, 50), "[OOC] ", hook.Run("GetPlayerChatColor", speaker) or Color(255, 100, 100), speaker:SteamName(), color_white, ": "..text)
			chat.AddText(icon, Color(255,215,0), "[OOC] ", Color(192, 192, 196), speaker:SteamName(), color_white, ": "..text)
		end
	end)
end

ix.command.Add("PlySetHP", {
	description = "cmdSetHP",
	adminOnly = true,
	arguments = {
		ix.type.character,
		ix.type.number
	},
	OnRun = function(self, client, target, health)
		if (target and health) then
			target.player:SetHealth(health)
		end

		client:NotifyLocalized(string.format("You set %s's health to %s.", target.player:Nick(), health))
	end
})

ix.command.Add("PlySetArmor", {
	description = "cmdSetArmor",
	adminOnly = true,
	arguments = {
		ix.type.character,
		ix.type.number
	},
	OnRun = function(self, client, target, armor)
		if (target and armor) then
			target.player:SetArmor(armor)
		end

		client:NotifyLocalized(string.format("You set %s's armor to %s.", target.player:Nick(), armor))
	end
})

ix.command.Add("PlyKick", {
	description = "cmdKick",
	adminOnly = true,
	arguments = {
		ix.type.character,
		bit.bor(ix.type.text, ix.type.optional)
	},
	OnRun = function(self, client, target, reason)
		target.player:Kick(reason)

		for _, v in ipairs(player.GetAll()) do
			if (self:OnCheckAccess(v)) then
				v:NotifyLocalized(string.format("%s has kicked %s for reason: %s", client:GetName(), target.player:Nick(), reason))
			end
		end
	end
})

ix.command.Add("CharGetFlags", {
	description = "@cmdCharGetFlags",
	privilege = "View Character Flags",
	superAdminOnly = true,
	arguments = {
		ix.type.character
	},
	OnRun = function(self, client, target)
		local format = "%s has flags: %s"

		if (#target:GetData("f") != 0) then
			return string.format(format, target.player:GetName(), target:GetData("f"))
		else
			return string.format(format, target.player:GetName(), "none")
		end
	end
})

ix.command.Add("Help", {
	description = "@cmdHelp",
	arguments = ix.type.text,
	OnRun = function(self, client, message)

		local listeners = {}
		for _, v in ipairs(player.GetAll()) do
			if v:IsAdmin() then
				table.insert(listeners, v)
			end
		end

		print(message)

		table.insert(listeners, client)

		ix.chat.Send(client, "help", message, false, listeners, {target = target})

	end
})

ix.command.Add("BugReport", {
	description = "@cmdBugReport",
	OnRun = function(self, client)
		serverguard.command.Run(client, "report", false)
	end
})

ix.command.Add("PlyWarn", {
	description = "@cmdPlyWarn",
	adminOnly = true,
	arguments = {
		ix.type.character,
		ix.type.text
	},
	OnRun = function(self, client, target, message)
		ix.chat.Send(client, "warn", message, false, {client}, {target = target})
		for _, v in ipairs(player.GetAll()) do
			if (self:OnCheckAccess(v)) then
				v:NotifyLocalized("cWarn", client:GetName(), target:GetName(), message)
			end
		end
	end
})

ix.config.Add("menuTitle", "Willard Networks", "The title text.", nil, {
	category = "Appearance"
})

ix.config.Add("menuDescription", "Half Life 2 Roleplay", "The description text.", nil, {
	category = "Appearance"
})

ix.config.Add("canDispatchObserver", true, "Can Dispatchers use Observer", nil, {
	category = "Overwatch Systems"
})
