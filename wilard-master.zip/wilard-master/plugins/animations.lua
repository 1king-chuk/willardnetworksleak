
local PLUGIN = PLUGIN

PLUGIN.name = "Animations"
PLUGIN.author = "Gary Tate"
PLUGIN.description = "Cool models with cooler animations."

-- Overwatch Animations
ix.anim.SetModelClass("models/ninja/combine/combine_soldier.mdl", "overwatch")
ix.anim.SetModelClass("models/ninja/combine/combine_soldier_prisonguard.mdl", "overwatch")
ix.anim.SetModelClass("models/ninja/combine/combine_super_soldier.mdl", "overwatch")
ix.anim.SetModelClass("models/ninja/combine/combinonew.mdl", "overwatch")
ix.anim.SetModelClass("models/ninja/combine/combinonew_armor.mdl", "overwatch")
ix.anim.SetModelClass("models/ninja/combine/combinonew_mopp.mdl", "overwatch")
