
PLUGIN.name = "Dispatch Chat"
PLUGIN.author = "SleepyMode"
PLUGIN.description = "Adds the /d command."

do
	local CLASS = {}

	function CLASS:CanSay(speaker, text)
		if (!speaker:IsDispatch()) then
			speaker:NotifyLocalized("notAllowed")

			return false
		end
	end

	function CLASS:CanHear(speaker, listener)
		return listener:IsDispatch()
	end

	function CLASS:OnChatAdd(speaker, text)
		local faction = ix.faction.Get(speaker:GetFaction())
		chat.AddText(Color(255, 200, 50, 255), "@dispatch ", faction.color, speaker:Name(), Color(150, 200, 150, 255), text)
	end

	ix.chat.Register("dispatch_chat", CLASS)
end

do
	local COMMAND = {}
	COMMAND.arguments = ix.type.text

	function COMMAND:OnRun(client, message)
		if (!client:IsRestricted()) then
			ix.chat.Send(client, "dispatch_chat", message)
		else
			return "@notNow"
		end
	end

	ix.command.Add("D", COMMAND)
end