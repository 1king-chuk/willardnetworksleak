net.Receive("hazelShowDatafile", function()
    local panel = vgui.Create("hazelShowDatafile")
end)
