LANGUAGE = {
    cmdHazelDatafile = "Manage the files of active citizens in the city."
}
