
local PLUGIN = PLUGIN

local PANEL = {}

function PANEL:Init()
    local height = ScrH() * 0.75
    local width = height * (4/3)
    self:SetSize(width, height)
    self:Center()
    self:SetBackgroundBlur(true)
    self:SetDeleteOnClose(true)
    self:SetDraggable(false)
    self:MakePopup()
    self:SetTitle("Hazel")

    -- Information Section
    local information = self:Add("DPanel")
    information:Dock(TOP)
    information:SetHeight(height / 4)

    local mugshotside = information:Add("DPanel")
    mugshotside:Dock(RIGHT)
    mugshotside:SetWidth(height / 6)

    local mugshotfront = information:Add("DPanel")
    mugshotfront:Dock(RIGHT)
    mugshotfront:SetWidth(height / 6)

    local info = {}

    for i = 1, 4 do
        info[i] = information:Add("DPanel")
        info[i]:Dock(TOP)
        info[i]:SetHeight(information:GetTall() / 3)
    end

    local targetName = info[1]:Add("DLabel")
    targetName:DockMargin(50, 0, 0, 0)
    targetName:Dock(FILL)
    targetName:SetFont("ixMediumLightFont")
    targetName:SetText("BASIC INFORMATION")
    targetName:SetWidth(400)

end

vgui.Register("hazelShowDatafile", PANEL, "DFrame")
