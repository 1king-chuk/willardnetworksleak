
local PLUGIN = PLUGIN

PLUGIN.name = "Hazel Datafile"
PLUGIN.description = "A custom datafile interface."
PLUGIN.author = "Gary Tate"

ix.util.Include("cl_hooks.lua")
ix.util.Include("sv_hooks.lua")

if SERVER then
    util.AddNetworkString("hazelShowDatafile")
end

ix.command.Add("Datafile", {
    description = "@cmdHazelDatafile",
    arguments = {
        ix.type.text
    },
    OnCheckAccess = function(self, client)
        return client:IsCombine()
    end,
    OnRun = function(self, client, target)
        ix.log.Add(client, "hazelOpenedDatafile", client, target)
        net.Start("hazelShowDatafile")
        net.Send(client)
    end
})
