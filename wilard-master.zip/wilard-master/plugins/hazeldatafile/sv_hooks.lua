
ix.log.AddType("hazelOpenedDatafile", function(client, target)
    return string.format("[HAZEL] %s has accessed %s's datafile.", client:GetName(), target)
end)
