
local PLUGIN = PLUGIN

PLUGIN.name = "Thermal Vision"
PLUGIN.author = "Gary Tate"
PLUGIN.description = "Allows Overwatch forces to access thermal vision."

ix.util.Include("cl_hooks.lua")
ix.util.Include("sv_hooks.lua")

ix.config.Add("thermalVision", true, "smelly", nil, {
	category = "Visuals"
})

ix.command.Add("ToggleThermals", {
	description = "Toggles thermal googles.",
	OnCheckAccess = function(self, client)
		return client:IsDispatch() and ix.config.Get("thermalVision", false)
	end,
	OnRun = function(self, client)
		local active = client:GetData("thermalActive", false)
		client:SetData("thermalActive", !active)

		net.Start("ixToggleThermals")
			net.WriteBool(active)
		net.Send(client)
	end
})
