
util.AddNetworkString("ixToggleThermals")
