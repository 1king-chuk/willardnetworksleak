
local PLUGIN = PLUGIN

PLUGIN.name = "Custom Event Ranges"
PLUGIN.author = "Gary Tate"
PLUGIN.description = "Allows for custom ranges to be used for events."

ix.chat.Register("localevent", {
    CanHear = (ix.config.Get("chatRange", 280) * 2),
    OnChatAdd = function(self, speaker, text)
        chat.AddText(Color(255, 150, 0), text)
    end,
    indicator = "chatPerforming"
})

if CLIENT then
    function PLUGIN:PostDrawTranslucentRenderables(bDrawingDepth, bDrawingSkybox)
        local shouldRender = false
        local range
        
        -- Only runs when /localevent is typed.
        if (string.lower(ix.chat.currentCommand) == "localevent") then
            shouldRender = true
            -- Accepts range from 0 - 65535
            range = tonumber(ix.chat.currentArguments[2]) or (ix.config.Get("chatRange", 280) * 2)
        end

        if shouldRender then
            -- Range Sphere
            render.SetColorMaterial()
            render.DrawSphere(LocalPlayer():GetPos(), (0 - range), 50, 50, Color(255,150,0,100))
        end
    end
end

ix.command.Add("LocalEvent", {
    description = "@cmdLocalEvent",
    adminOnly = true,
    arguments = {
        ix.type.string,
        bit.bor(ix.type.number, ix.type.optional)
    },
    OnRun = function(self, client, event, range)

        local _range = range or (ix.config.Get("chatRange", 280) * 2)

        ix.chat.classes.localevent.range = _range * _range

        ix.chat.Send(client, "localevent", event)

    end
})
