ITEM.name = "PDA"
ITEM.description = "A combine PDA."
ITEM.model = "models/fruity/tablet/tablet_sfm.mdl"
ITEM.class = "weapon_datapad"
ITEM.weaponCategory = "grenade"
ITEM.width = 2
ITEM.height = 2