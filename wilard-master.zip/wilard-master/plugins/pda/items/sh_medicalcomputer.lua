local PLUGIN = PLUGIN

ITEM.name = "Medical Computer"
ITEM.uniqueID = "med_computer"
ITEM.model = "models/props_lab/monitor01a.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.description = "A medical computer that can review medical files."
ITEM.category = "Medical"

ITEM.functions.Place = {
	OnRun = function(itemTable)
		local client = itemTable.player
		local entity = ents.Create("df_medical_computer")
		local trace = client:GetEyeTraceNoCursor()
		
		if (trace.HitPos:Distance( client:GetShootPos() ) <= 192) then
			entity:SetPos(trace.HitPos + Vector( 0, 0, 17 ))
			entity:Spawn()
			entity:SetNWInt("owner", client:GetCharacter():GetID())
			
			if itemTable:GetData("password") then
				entity:SetNWString("password", itemTable:GetData("password"))
			end
			
			if itemTable:GetData("notes") then
				entity:SetNWString("notes", itemTable:GetData("notes"))
			end
			
			if (IsValid(entity)) then
				entity:SetAngles(Angle(0, client:EyeAngles().yaw + 180, 0))
			end

			PLUGIN:SaveMedicalComputers()
		else
			client:NotifyLocalized("You cannot place it that far away!..")
			return false
		end
	end
}