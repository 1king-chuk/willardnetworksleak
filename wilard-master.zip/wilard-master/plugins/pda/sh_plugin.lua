local PLUGIN = PLUGIN

PLUGIN.name = "Datapad"
PLUGIN.author = "Fruity"
PLUGIN.description = "Datapad."

ix.util.Include("sh_datapad.lua")
ix.util.Include("sh_datafile.lua")

ix.command.Add("TerminalAdd", {
	adminOnly = true,
	description = "@cmdTerminalAdd",
	OnRun = function(self, client, arguments)
		local trace = client:GetEyeTraceNoCursor()
		local entity = ents.Create("ix_terminal")
		
		entity:SetPos(trace.HitPos)
		entity:Spawn()
		
		if (IsValid(entity)) then
			entity:SetAngles(Angle(0, client:EyeAngles().yaw + 270, 0))
			
			client:NotifyLocalized("You have added a terminal.")
		end

		PLUGIN:SaveTerminals()
	end
})

if (SERVER) then
	function PLUGIN:Move( client, movedata )
		if client:IsValid() then
			if client:GetCharacter() then
				local LUpper = client:LookupBone( "ValveBiped.Bip01_L_UpperArm" )
				local RUpper = client:LookupBone( "ValveBiped.Bip01_R_UpperArm" )
				local RForeArm = client:LookupBone( "ValveBiped.Bip01_R_ForeArm" )
				if client:GetCharacter():GetFaction() == FACTION_MPF then
					if IsValid(client) then
						if client:GetActiveWeapon() then
							if string.find(tostring(client:GetActiveWeapon()), "weapon_datapad") then
								if movedata:GetVelocity() == Vector( 0, 0 ,0 ) then
									client:ManipulateBonePosition(LUpper, Vector(-0, 0, 0))
									client:ManipulateBoneAngles( LUpper, Angle(-0, -0, -0) )
									
									client:ManipulateBonePosition(RUpper, Vector(0, 0, 0))
									client:ManipulateBoneAngles( RUpper, Angle(-20, -22, -33) )
									
									client:ManipulateBonePosition(RForeArm, Vector(0, 0, 0))
									client:ManipulateBoneAngles( RForeArm, Angle(-0, 33, -33) )
								else
									client:ManipulateBonePosition(LUpper, Vector(0, 0, 0))
									client:ManipulateBoneAngles( LUpper, Angle(0, 0, 0) )
									
									client:ManipulateBonePosition(RUpper, Vector(0, 0, 0))
									client:ManipulateBoneAngles( RUpper, Angle(0, 0, 0) )

									client:ManipulateBonePosition(RForeArm, Vector(0, 0, 0))
									client:ManipulateBoneAngles( RForeArm, Angle(0, 0, 0) )
								end
							end
						end
					end
				end
			end
		end
	end
	
	function PLUGIN:PlayerButtonDown( client, key )
		if IsFirstTimePredicted() then
			if key == KEY_LALT then
				local entity = client:GetEyeTraceNoCursor().Entity
				local getPassword = entity:GetNWString("password")
				local getNotes = entity:GetNWString("notes")
				
				if (IsValid(entity) and entity:GetClass() == "df_medical_computer") then
					if client:GetCharacter():GetID() != entity:GetNWInt("owner") then
						return false
					end
					
					if client._inWebsitePanel then
						return false
					end
					
					if (entity:GetClass() != "df_medical_computer") then
						return false
					end
					
					if (client:GetShootPos():Distance(entity:GetPos()) > 100) then
						return false
					end
					
					local pos = entity:GetPos()
					
					ix.item.Spawn("med_computer", pos + Vector( 0, 0, 2 ), function(item, entityCreated) item:SetData("password", getPassword) item:SetData("notes", getNotes) end, entity:GetAngles())
					
					entity:Remove()
				else
					return false
				end
			end
		end
	end
	
	-- A function to load the static props.
	function PLUGIN:LoadMedicalComputers()
		local computers = ix.data.Get("medicalcomputers_"..game.GetMap())
		if computers then
			for k, v in pairs(computers) do
				local entity = ents.Create("df_medical_computer")
				entity:SetAngles(v.angles)
				entity:SetPos(v.position)
				entity:Spawn()
				entity:SetNWString("password", v.password)
				entity:SetNWString("notes", v.notes)
				entity:SetNWInt("owner", v.owner)
			end
		end
	end
	
	-- A function to save the static props.
	function PLUGIN:SaveMedicalComputers()
		local MedicalComputers = {}
		
		for k, v in pairs(ents.FindByClass("df_medical_computer")) do
			MedicalComputers[#MedicalComputers + 1] = {
				angles = v:GetAngles(),
				position = v:GetPos(),
				password = v:GetNWString("password"),
				notes = v:GetNWString("notes"),
				owner = v:GetNWInt("owner")
			}
		end
		
		ix.data.Set("medicalcomputers_"..game.GetMap(), MedicalComputers)
	end
	
	-- A function to load the static props.
	function PLUGIN:LoadTerminals()
		local terminals = ix.data.Get("terminals_"..game.GetMap())
		if terminals then
			for k, v in pairs(terminals) do
				local entity = ents.Create("ix_terminal")
				entity:SetAngles(v.angles)
				entity:SetPos(v.position)
				entity:Spawn()

				local physicsObject = entity:GetPhysicsObject()		
				if (IsValid(physicsObject)) then
					physicsObject:EnableMotion(false)
				end
			end
			MsgC(Color(0, 255, 0), "[TERMINAL] Terminals Loaded.\n")
		else
			MsgC(Color(0, 255, 0), "[TERMINAL] No Terminals Loaded.\n")
		end
	end

	-- A function to save the static props.
	function PLUGIN:SaveTerminals()
		local terminals = {}
		
		for k, v in pairs(ents.FindByClass("ix_terminal")) do
			terminals[#terminals + 1] = {
				angles = v:GetAngles(),
				position = v:GetPos()
			}
		end
		
		ix.data.Set("terminals_"..game.GetMap(), terminals)
	end
	
	-- Called when Helix has loaded all of the entities.
	function PLUGIN:InitPostEntity()
		self:LoadMedicalComputers()
		self:LoadTerminals()
	end

	-- Called just after data should be saved.
	function PLUGIN:SaveData()
		self:SaveMedicalComputers()
		self:SaveTerminals()
	end
end