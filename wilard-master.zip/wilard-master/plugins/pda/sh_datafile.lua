local PLUGIN = PLUGIN
PLUGIN.file = {}

function PLUGIN:RefreshDatafile(id, bIsLocal)
	if (bIsLocal) then
		local query = mysql:Select("ix_characters")
		query:Where("id", id)
		query:Limit(1)
		query:Callback(function(result)
			if (!istable(result)) then
				return
			end
			
			if not result[1] then
				return
			end
			
			if (!table.IsEmpty(PLUGIN.file)) then
				table.Empty(PLUGIN.file)
			end
			
			local tempGeneric = util.JSONToTable(result[1].genericdata)
			if tempGeneric.name != result[1].name then
				tempGeneric.name = result[1].name
				
				local updateQuery = mysql:Update("ix_characters")
				updateQuery:Where("id", id)
				updateQuery:Limit(1)
				updateQuery:Update("genericdata", util.TableToJSON(tempGeneric) or "")
				updateQuery:Execute()
			end
			
			PLUGIN.file = {
				genericdata = util.JSONToTable(result[1].genericdata or ""),
				datafilelogs = util.JSONToTable(result[1].datafilelogs or ""),
				datafileviolations = util.JSONToTable(result[1].datafileviolations or ""),
				datafilemedicalrecords = util.JSONToTable(result[1].datafilemedicalrecords or "")
			}
			
			timer.Simple(0.05, function()
				netstream.Start(client, "OpenDatafileCl", PLUGIN.file)
			end)
		end)
		query:Execute()
	elseif (tonumber(id) != nil and string.len( id ) <= 5) then
		local query = mysql:Select("ix_characters")
		query:Where("datafilecid", id)
		query:Limit(1)
		query:Callback(function(result)
			if (!istable(result)) then
				return
			end
			
			if not result[1] then
				return
			end
			
			if (!table.IsEmpty(PLUGIN.file)) then
				table.Empty(PLUGIN.file)
			end
			
			local tempGeneric = util.JSONToTable(result[1].genericdata)
			if tempGeneric.name != result[1].name then
				tempGeneric.name = result[1].name
				
				local updateQuery = mysql:Update("ix_characters")
				updateQuery:Where("datafilecid", id)
				updateQuery:Limit(1)
				updateQuery:Update("genericdata", util.TableToJSON(tempGeneric) or "")
				updateQuery:Execute()
			end
			
			PLUGIN.file = {
				genericdata = util.JSONToTable(result[1].genericdata or ""),
				datafilelogs = util.JSONToTable(result[1].datafilelogs or ""),
				datafileviolations = util.JSONToTable(result[1].datafileviolations or ""),
				datafilemedicalrecords = util.JSONToTable(result[1].datafilemedicalrecords or "")
			}
			
			timer.Simple(0.05, function()
				netstream.Start(client, "OpenDatafileCl", PLUGIN.file)
			end)
		end)
		query:Execute()
	else
		local query = mysql:Select("ix_characters")
		query:WhereLike("name", id)
		query:Limit(1)
		query:Callback(function(result)
			if (!istable(result)) then
				return
			end
			
			if not result[1] then
				return
			end
			
			if (!table.IsEmpty(PLUGIN.file)) then
				table.Empty(PLUGIN.file)
			end
			
			local tempGeneric = util.JSONToTable(result[1].genericdata)
			if tempGeneric.name != result[1].name then
				tempGeneric.name = result[1].name
				
				local updateQuery = mysql:Update("ix_characters")
				updateQuery:Where("name", id)
				updateQuery:Limit(1)
				updateQuery:Update("genericdata", util.TableToJSON(tempGeneric) or "")
				updateQuery:Execute()
			end
			
			PLUGIN.file = {
				genericdata = util.JSONToTable(result[1].genericdata or ""),
				datafilelogs = util.JSONToTable(result[1].datafilelogs or ""),
				datafileviolations = util.JSONToTable(result[1].datafileviolations or ""),
				datafilemedicalrecords = util.JSONToTable(result[1].datafilemedicalrecords or "")
			}
			
			timer.Simple(0.05, function()
				netstream.Start(client, "OpenDatafileCl", PLUGIN.file)
			end)
		end)
		query:Execute()
	end
end

if (SERVER) then	
	function PLUGIN:DatabaseConnected()
		if (ix.data.Get("DatafileMysqlCreated") == false or ix.data.Get("DatafileMysqlCreated") == nil) then
			local query = mysql:Alter("ix_characters")
				query:Add("genericdata", "text DEFAULT NULL")
			query:Execute()
			
			local query2 = mysql:Alter("ix_characters")
				query2:Add("datafilelogs", "text DEFAULT NULL")
			query2:Execute()
			
			local query3 = mysql:Alter("ix_characters")
				query3:Add("datafileviolations", "text DEFAULT NULL")
			query3:Execute()
			
			local query4 = mysql:Alter("ix_characters")
				query4:Add("datafilemedicalrecords", "text DEFAULT NULL")
			query4:Execute()
			
			local query5 = mysql:Alter("ix_characters")
				query5:Add("datafilecid", "text DEFAULT NULL")
			query5:Execute()
			
			ix.data.Set("DatafileMysqlCreated", true)
		end
	end
	
	function PLUGIN:PlayerLoadedCharacter(client)
		local bHasDatafile = client:GetCharacter():GetData("hasDatafile")

		if client:IsValid() then
			if client:GetCharacter() then
				local LUpper = client:LookupBone( "ValveBiped.Bip01_L_UpperArm" )
				local RUpper = client:LookupBone( "ValveBiped.Bip01_R_UpperArm" )
				local RForeArm = client:LookupBone( "ValveBiped.Bip01_R_ForeArm" )
				client:ManipulateBonePosition(LUpper, Vector(0, 0, 0))
				client:ManipulateBoneAngles( LUpper, Angle(0, 0, 0) )
				
				client:ManipulateBonePosition(RUpper, Vector(0, 0, 0))
				client:ManipulateBoneAngles( RUpper, Angle(0, 0, 0) )

				client:ManipulateBonePosition(RForeArm, Vector(0, 0, 0))
				client:ManipulateBoneAngles( RForeArm, Angle(0, 0, 0) )
			end
		end
		
		if (!bHasDatafile or bHasDatafile == nil) then
			PLUGIN:CreateDatafile(client)
		end
	end

	function PLUGIN:CreateDatafile(client)
		if (client:IsValid()) then
			local character = client:GetCharacter()
			local citizenid = character:GetData("cid") or "N/A"
			
			GenericData = {
				id = character:GetID(),
				name = character:GetName(),
				cid  = character:GetData("cid") or "N/A",
				socialCredits = 100,
				socialCreditsDate = os.date("%d/%m/%Y"),
				geneticDesc = character:GetData("geneticDesc") or "N/A",
				occupation = "N/A",
				occupationDate = os.date("%d/%m/%Y"),
				designatedStatus = "N/A",
				designatedStatusDate = os.date("%d/%m/%Y"),
				permits = false,
				bol = false,
				anticitizen = false,
				combine = false,
			}
			
			if client:IsCombine() then
				GenericData.combine = true
			end
			
			defaultLogs = {
				[1] = {
					text = "TRANSFERRED TO DISTRICT",
					date = os.date("%d/%m/%Y"),
					poster = "Overwatch",
				},
			}
			
			defaultViolations = {}
			defaultMedicalRecords = {}

			-- Set all the values.
			local queryObj = mysql:Update("ix_characters");
				queryObj:Where("id", client:GetCharacter():GetID())
				queryObj:Update("genericdata", util.TableToJSON(GenericData))
				queryObj:Update("datafilelogs", util.TableToJSON(defaultLogs))
				queryObj:Update("datafileviolations", util.TableToJSON(defaultViolations))
				queryObj:Update("datafilemedicalrecords", util.TableToJSON(defaultMedicalRecords))
				queryObj:Update("datafilecid", citizenid)
			queryObj:Execute()

			character:SetData("hasDatafile", true)
		end
	end

	netstream.Hook("OpenDatafile", function(client, id, bIsLocal)
		PLUGIN:RefreshDatafile(id, bIsLocal)
	end)
	
	netstream.Hook("EditDatafile", function(client, genericdata)
		local queryObj = mysql:Update("ix_characters")
			queryObj:Where("id", genericdata.id)
			queryObj:Update("genericdata", util.TableToJSON(genericdata))
		queryObj:Execute()
		
		PLUGIN:RefreshDatafile(genericdata.id, true)
	end)
	
	netstream.Hook("AddLog", function(client, logsTable, genericdata, posterName, points, text)
		logsTable[#logsTable + 1] = {
			text = text,
			date = os.date("%d/%m/%Y"),
			points = points or nil,
			poster = posterName
		}
		
		local queryObj = mysql:Update("ix_characters")
			queryObj:Where("id", genericdata.id)
			queryObj:Update("datafilelogs", util.TableToJSON(logsTable))
		queryObj:Execute()
	
		PLUGIN:RefreshDatafile(genericdata.id, true)
	end)
	
	netstream.Hook("AddViolation", function(client, violationsTable, genericdata, posterName, text)
		violationsTable[#violationsTable + 1] = {
			text = text,
			date = os.date("%d/%m/%Y"),
			poster = posterName
		}
		
		local queryObj = mysql:Update("ix_characters")
			queryObj:Where("id", genericdata.id)
			queryObj:Update("datafileviolations", util.TableToJSON(violationsTable))
		queryObj:Execute()
	
		PLUGIN:RefreshDatafile(genericdata.id, true)
	end)
	
	netstream.Hook("AddMedicalRecord", function(client, medicalTable, genericdata, posterName, text)
		medicalTable[#medicalTable + 1] = {
			text = text,
			date = os.date("%d/%m/%Y"),
			poster = posterName
		}
		
		local queryObj = mysql:Update("ix_characters")
			queryObj:Where("id", genericdata.id)
			queryObj:Update("datafilemedicalrecords", util.TableToJSON(medicalTable))
		queryObj:Execute()
	
		PLUGIN:RefreshDatafile(genericdata.id, true)
	end)
else
	netstream.Hook("OpenDatafileCl", function(table)
		for k, v in pairs(PLUGIN.contentSubframe:GetChildren()) do
			v:SetVisible(false)
		end
		
		PLUGIN.file = table
		PLUGIN.datafileInfo = vgui.Create("ixDatafileInfo", PLUGIN.contentSubframe)
		PLUGIN.datafileFunctions = vgui.Create("ixDatafileFunctions", PLUGIN.contentSubframe)
	end)
end