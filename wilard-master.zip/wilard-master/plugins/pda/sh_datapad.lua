local PLUGIN = PLUGIN

PLUGIN.updatelist = {}
PLUGIN.verdictCode = ""
PLUGIN.comCode = ""

function PLUGIN:GetUpdates()
	PLUGIN.verdictCode = ix.data.Get("verdictCodes")
	PLUGIN.comCode = ix.data.Get("comCodes")
	local query = mysql:Select("ix_datapad")
	query:Select("update_id")
	query:Select("update_text")
	query:Select("update_date")
	query:Select("update_poster")
	query:Callback(function(result)
		if (!istable(result)) then
			return
		end
		
		if (!table.IsEmpty(PLUGIN.updatelist)) then
			table.Empty(PLUGIN.updatelist)
		end
		
		PLUGIN.updatelist = result
	end)
	
	query:Execute()
end

function PLUGIN:Refresh()
	PLUGIN:GetUpdates()
	timer.Simple(0.05, function()
		netstream.Start(client, "OpenPDA", PLUGIN.updatelist, PLUGIN.verdictCode, PLUGIN.comCode)
	end)
end

function PLUGIN:SetVerdictCode(text)
	ix.data.Set("verdictCodes", text, false, true)
	PLUGIN:Refresh()
end

function PLUGIN:SetComCode(text)
	ix.data.Set("comCodes", text, false, true)
	PLUGIN:Refresh()
end

if (CLIENT) then
	 function PLUGIN:LoadFonts(font, genericFont)
		surface.CreateFont( "DatapadTitle", {
			font = "Open Sans Bold", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
			extended = false,
			size = 32,
			weight = 550,
			antialias = true,
		} )
	end
			
	netstream.Hook("OpenPDA", function(table, verdictcode, comcode)
		if IsValid(PLUGIN.ixDatapad) then
			PLUGIN.ixDatapad:Remove()
		end
		
		PLUGIN.verdictCode = verdictcode
		PLUGIN.comCode = comcode
		PLUGIN.updatelist = table
		PLUGIN.ixDatapad = vgui.Create("ixDatafilePDA")
		surface.PlaySound("willardnetworks/datapad/open.wav")
	end)
else	
	function PLUGIN:DatabaseConnected()
		local query = mysql:Create("ix_datapad")
		query:Create("update_id", "INT(11) UNSIGNED NOT NULL AUTO_INCREMENT")
		query:Create("update_text", "TEXT")
		query:Create("update_date", "TEXT")
		query:Create("update_poster", "TEXT")
		query:PrimaryKey("update_id")
		query:Execute()
	end
	
	netstream.Hook("AddUpdate", function(client, text)		
		local timestamp = os.date( "%d.%m.%Y" )
		local queryObj = mysql:Insert("ix_datapad")
			queryObj:Insert("update_text", text)
			queryObj:Insert("update_date", timestamp)
			queryObj:Insert("update_poster", client:Name())
		queryObj:Execute()
		
		PLUGIN:Refresh()
	end)
	
	netstream.Hook("RemoveUpdate", function(client, id)		
		local queryObj = mysql:Delete("ix_datapad")
			queryObj:Where("update_id", id)
		queryObj:Execute()
		
		PLUGIN:Refresh()
	end)
	
	netstream.Hook("EditUpdate", function(client, id, newText)		
		local queryObj = mysql:Update("ix_datapad")
			queryObj:Where("update_id", id)
			queryObj:Update("update_text", newText)
		queryObj:Execute()
		
		PLUGIN:Refresh()
	end)
	
	netstream.Hook("EditVerdictCodes", function(client, newText)		
		PLUGIN:SetVerdictCode(newText)
	end)
	
	netstream.Hook("EditComCodes", function(client, newText)		
		PLUGIN:SetComCode(newText)
	end)
end