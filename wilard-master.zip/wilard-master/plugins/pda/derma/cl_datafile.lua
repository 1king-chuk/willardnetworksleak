local PLUGIN = PLUGIN

local color = Color(41, 243, 229, 255)

local function CreateRow(parent, title, text, date, bSecondInRow, bUpdateable)
	parent:SetSize(parent:GetWide(), 48)
	parent:Dock(TOP)
	parent.Paint = function(self, w, h) 
		if (bSecondInRow) then				
			surface.SetDrawColor(0, 0, 0, 75)
			surface.DrawRect(0, 0, w, h)
		else
			surface.SetDrawColor(40, 88, 115, 75)
			surface.DrawRect(0, 0, w, h)
		end
	end
	
	local top = parent:Add("EditablePanel")
	top:SetSize(parent:GetWide(), parent:GetTall() * 0.5)
	top:Dock(TOP)
	top.Paint = function(self, w, h) end
	
	local topTitle = top:Add("DLabel")
	topTitle:SetTextColor(Color(154, 169, 175, 255))
	topTitle:SetFont("MenuFont")
	topTitle:SetText(string.upper(title)..":")
	topTitle:Dock(LEFT)
	topTitle:DockMargin(20, 5, 0, 0)
	topTitle:SizeToContents()
		
	local bottom = parent:Add("EditablePanel")
	bottom:SetSize(parent:GetWide(), parent:GetTall() * 0.4)
	bottom:Dock(TOP)
	bottom.Paint = function(self, w, h) end
	bottom:SetName( "bottom" )
			
	local titleText = bottom:Add("DLabel")
	titleText:SetTextColor(color)
	titleText:SetFont("MenuFont")
	titleText:SetText(text)
	titleText:Dock(LEFT)
	titleText:DockMargin(20, 0, 0, 0)
	titleText:SizeToContents()
	
	if (bUpdateable) then
		local topDate = top:Add("DLabel")
		topDate:SetFont("MenuFont")
		topDate:SetTextColor(Color(154, 169, 175, 255))
		topDate:SetText(string.upper("updated")..": "..date)
		topDate:Dock(RIGHT)
		topDate:DockMargin(0, 5, 20, 0)
		topDate:SizeToContents()
	end
end

local function CreateButton(name, text, path)
	name:SetSize(480, 40)
	name:SetContentAlignment(4)
	name:SetTextInset(20, 0)
	name:Dock(TOP)
	name:SetFont("TitlesFont")
	name:DockMargin(0, 0, 0, 9)
	name:SetText(string.upper(text))
	name.Paint = function(self, w, h) 
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("willardnetworks/datafile/"..path))
		surface.DrawTexturedRect(0, 0, w, h) 
	end
end

local function createUpdateButton(parent)
	parent:SetSize(137, 18)
	parent:Dock(RIGHT)
	parent:DockMargin(0, 0, 21, 0)
	parent:SetFont("MenuFont")
	parent:SetText(string.upper("update"))
	parent:SetContentAlignment(5)
	parent.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(Material("willardnetworks/datafile/smallestbutton.png"))
		surface.DrawTexturedRect(0, 0, w, h)
	end
end

local PANEL = {}

function PANEL:Init()
	PLUGIN.mainTitle:SetText(string.upper("datafile"))
	self:SetSize(self:GetParent():GetWide(), 338)
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 15)
	self.Paint = function(self, w, h) end
	
	local titleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(titleFrame, self, "information")
	
	titleSubframe = titleFrame:Add("EditablePanel")
	titleSubframe:SetSize(128, 0)
	titleSubframe:Dock(RIGHT)
	titleSubframe.Paint = function(self, w, h) end
	
	local viewLogs = titleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(viewLogs, titleSubframe, 87, "view logs", RIGHT)
	
	local back = titleSubframe:Add("DButton")	
	PLUGIN:CreateTitleFrameRightTextButton(back, titleSubframe, 68, "back", LEFT)	
	back.DoClick = function()
		PLUGIN.mainTitle:SetText(string.upper("datapad"))
		surface.PlaySound("willardnetworks/datapad/back.wav")
		if IsValid(PLUGIN.datafileInfo) then
			PLUGIN.datafileInfo:SetVisible(false)
		end
		
		if IsValid(PLUGIN.datafileFunctions) then
			PLUGIN.datafileFunctions:SetVisible(false)
		end
		
		PLUGIN.updates:SetVisible(true)
		PLUGIN.functions:SetVisible(true)
	end
	
	PLUGIN:DrawDividerLine(titleSubframe, 2, 13, back:GetWide() + 7, 4)
	
	viewLogs.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		PLUGIN.datafileInfo:SetVisible(false)
		PLUGIN.datafileFunctions:SetVisible(false)
		PLUGIN.viewEntryLogs = vgui.Create("ixDatafileEntryLogs", PLUGIN.contentSubframe)
	end
	
	local infoContentFrame = self:Add("EditablePanel")
	infoContentFrame:SetSize(self:GetWide(), 288)
	infoContentFrame:Dock(TOP)
	infoContentFrame:DockMargin(0, -2, 0, 0)
	infoContentFrame.Paint = function(self, w, h) end
	
	local name = infoContentFrame:Add("EditablePanel")
	CreateRow(name, "name", PLUGIN.file.genericdata.name, nil, false, false)
	
	local cid = infoContentFrame:Add("EditablePanel")
	CreateRow(cid, "cid", PLUGIN.file.genericdata.cid, nil, true, false)
	
	local socialCredits = infoContentFrame:Add("EditablePanel")
	
	if PLUGIN.file.genericdata.combine == true then
		CreateRow(socialCredits, "sterilized credits", PLUGIN.file.genericdata.socialCredits, PLUGIN.file.genericdata.socialCreditsDate, false, true)
	else
		CreateRow(socialCredits, "social credits", PLUGIN.file.genericdata.socialCredits, PLUGIN.file.genericdata.socialCreditsDate, false, true)
	end
	
	for k, v in pairs(socialCredits:GetChildren()) do
		if v:GetName() == "bottom" then
			local updateSocialButton = v:Add("DButton")
			createUpdateButton(updateSocialButton)
			updateSocialButton.DoClick = function()
				surface.PlaySound("willardnetworks/datapad/navigate2.wav")
				titleFrame:SetVisible(false)
				infoContentFrame:SetVisible(false)
				
				local updateCreditsTitleFrame = self:Add("EditablePanel")
				PLUGIN:CreateTitle(updateCreditsTitleFrame, self, "edit social credits")
				
				local updateCreditsTitleSubframe = updateCreditsTitleFrame:Add("EditablePanel")
				updateCreditsTitleSubframe:SetSize(141, 0)
				updateCreditsTitleSubframe:Dock(RIGHT)
				updateCreditsTitleSubframe.Paint = function(self, w, h) end
				
				local editCredits = updateCreditsTitleSubframe:Add("DButton")
				PLUGIN:CreateTitleFrameRightTextButton(editCredits, updateCreditsTitleSubframe, 87, "edit credits", RIGHT)
				
				local back = updateCreditsTitleSubframe:Add("DButton")	
				PLUGIN:CreateTitleFrameRightTextButton(back, updateCreditsTitleSubframe, 68, "back", LEFT)	
				
				PLUGIN:DrawDividerLine(updateCreditsTitleSubframe, 2, 13, back:GetWide() + 7, 4)
				
				local updateCreditsFrame = self:Add("DPanel")
				updateCreditsFrame:SetSize(self:GetWide(), 288)
				updateCreditsFrame:Dock(TOP)
				updateCreditsFrame:DockMargin(0, -2, 0, 0)
				updateCreditsFrame.Paint = function(self, w, h)
					surface.SetDrawColor(40, 88, 115, 40)
					surface.DrawRect(0, 0, w, h)
				end
				
				local reason = updateCreditsFrame:Add("DLabel")
				reason:SetFont("MenuFont")
				reason:SetText(string.upper("reason:"))
				reason:SetTextColor(color)
				reason:Dock(TOP)
				reason:DockMargin( 20, 20, 20, 10)
				
				local entry = vgui.Create("DTextEntry", updateCreditsFrame)
				entry:Dock(TOP)
				entry:DockMargin(20, 0, 20, 10)
				entry:SetMultiline(false)
				entry:SetVerticalScrollbarEnabled( false )
				entry:SetEnterAllowed(false)
				entry:SetTextColor( color )
				entry:SetCursorColor( color )
				entry.Paint = function(self, w, h)
					surface.SetDrawColor(40, 88, 115, 75)
					surface.DrawRect(0, 0, w, h)
					
					self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
				end
				
				entry.MaxChars = 50
				entry.OnTextChanged = function(self)
					local txt = self:GetValue()
					local amt = string.len(txt)
					if amt > self.MaxChars then
						self:SetText(self.OldText)
						self:SetValue(self.OldText)
					else
						self.OldText = txt
					end
				end
				
				local amount = updateCreditsFrame:Add("DLabel")
				amount:SetFont("MenuFont")
				amount:SetText(string.upper("amount:"))
				amount:SetTextColor(color)
				amount:Dock(TOP)
				amount:DockMargin( 20, 0, 20, 10)

				local number = vgui.Create("DNumberWang", updateCreditsFrame)
				number:Dock(TOP)
				number:DockMargin(20, 0, 20, 0)
				number:SetMinMax( -10, 10 )
				number:SetTextColor( color )
				number:SetCursorColor( color )
				number.Paint = function(self, w, h)
					surface.SetDrawColor(40, 88, 115, 75)
					surface.DrawRect(0, 0, w, h)
					
					self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
				end
				
				local limitCount = 0
				
				for k, v in pairs(PLUGIN.file.datafilelogs) do
					if PLUGIN.file.datafilelogs[k].points then
						if PLUGIN.file.datafilelogs[k].points != 0 then
							if PLUGIN.file.datafilelogs[k].date == os.date("%d/%m/%Y") then
								limitCount = limitCount + PLUGIN.file.datafilelogs[k].points
							end
						end
					end
				end
				
				editCredits.DoClick = function()
					if (number:GetValue() > 10 or number:GetValue() < -10) then
						LocalPlayer():NotifyLocalized("The amount has to between -10 and 10!")
						return false
					end
					
					if ((number:GetValue() + limitCount) > 10 or (number:GetValue() + limitCount) < -10) then
						LocalPlayer():NotifyLocalized("This person has received "..limitCount.." SC today, the max per day is -10/10!")
						return false
					end
					
					if (number:GetValue() == 0) then
						LocalPlayer():NotifyLocalized("You need to either add or deduct points!")
						return false
					end
					
					surface.PlaySound("willardnetworks/datapad/navigate.wav")
			
					PLUGIN.file.genericdata.socialCredits = PLUGIN.file.genericdata.socialCredits + number:GetValue()
					PLUGIN.file.genericdata.socialCreditsDate = os.date("%d/%m/%Y")
					netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), number:GetValue(), entry:GetText())
					netstream.Start("EditDatafile", PLUGIN.file.genericdata)
				end
									
				back.DoClick = function()
					surface.PlaySound("willardnetworks/datapad/back.wav")
					updateCreditsTitleFrame:SetVisible(false)
					updateCreditsFrame:SetVisible(false)
					titleFrame:SetVisible(true)
					infoContentFrame:SetVisible(true)
				end
			end
		end
	end
	
	local geneticDescription = infoContentFrame:Add("EditablePanel")
	CreateRow(geneticDescription, "genetic description", PLUGIN.file.genericdata.geneticDesc, nil, true, false)
	
	local occupation = infoContentFrame:Add("EditablePanel")
	CreateRow(occupation, "occupation", PLUGIN.file.genericdata.occupation, PLUGIN.file.genericdata.occupationDate, false, true)

	for k, v in pairs(occupation:GetChildren()) do
		if v:GetName() == "bottom" then
			local updateOccupationButton = v:Add("DButton")
			createUpdateButton(updateOccupationButton)
			updateOccupationButton.DoClick = function()
				surface.PlaySound("willardnetworks/datapad/navigate2.wav")
				titleFrame:SetVisible(false)
				infoContentFrame:SetVisible(false)
				
				local updateOccupationTitleFrame = self:Add("EditablePanel")
				PLUGIN:CreateTitle(updateOccupationTitleFrame, self, "edit occupation")
				
				local updateOccupationTitleSubframe = updateOccupationTitleFrame:Add("EditablePanel")
				updateOccupationTitleSubframe:SetSize(175, 0)
				updateOccupationTitleSubframe:Dock(RIGHT)
				updateOccupationTitleSubframe.Paint = function(self, w, h) end
				
				local editOccupation = updateOccupationTitleSubframe:Add("DButton")
				PLUGIN:CreateTitleFrameRightTextButton(editOccupation, updateOccupationTitleSubframe, 87, "edit occupation", RIGHT)
				
				local back = updateOccupationTitleSubframe:Add("DButton")	
				PLUGIN:CreateTitleFrameRightTextButton(back, updateOccupationTitleSubframe, 68, "back", LEFT)	
				
				PLUGIN:DrawDividerLine(updateOccupationTitleSubframe, 2, 13, back:GetWide() + 7, 4)
				
				local updateOccupationFrame = self:Add("DPanel")
				updateOccupationFrame:SetSize(self:GetWide(), 288)
				updateOccupationFrame:Dock(TOP)
				updateOccupationFrame:DockMargin(0, -2, 0, 0)
				updateOccupationFrame.Paint = function(self, w, h)
					surface.SetDrawColor(40, 88, 115, 40)
					surface.DrawRect(0, 0, w, h)
				end
				
				local occupationName = updateOccupationFrame:Add("DLabel")
				occupationName:SetFont("MenuFont")
				occupationName:SetText(string.upper("enter occupation name:"))
				occupationName:SetTextColor(color)
				occupationName:Dock(TOP)
				occupationName:DockMargin( 20, 20, 20, 10)
				
				local entry = vgui.Create("DTextEntry", updateOccupationFrame)
				entry:Dock(TOP)
				entry:DockMargin(20, 0, 20, 10)
				entry:SetMultiline(false)
				entry:SetVerticalScrollbarEnabled( false )
				entry:SetText(PLUGIN.file.genericdata.occupation)
				entry:SetEnterAllowed(false)
				entry:SetTextColor( color )
				entry:SetCursorColor( color )
				entry.Paint = function(self, w, h)
					surface.SetDrawColor(40, 88, 115, 75)
					surface.DrawRect(0, 0, w, h)
					
					self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
				end
				
				entry.MaxChars = 50
				entry.OnTextChanged = function(self)
					local txt = self:GetValue()
					local amt = string.len(txt)
					if amt > self.MaxChars then
						self:SetText(self.OldText)
						self:SetValue(self.OldText)
					else
						self.OldText = txt
					end
				end
				
				editOccupation.DoClick = function()
					surface.PlaySound("willardnetworks/datapad/navigate.wav")
					PLUGIN.file.genericdata.occupation = entry:GetText()
					PLUGIN.file.genericdata.occupationDate = os.date("%d/%m/%Y")
					netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), 0, "OCCUPATION: "..entry:GetText())
					netstream.Start("EditDatafile", PLUGIN.file.genericdata)
				end
									
				back.DoClick = function()
					surface.PlaySound("willardnetworks/datapad/back.wav")
					updateOccupationTitleFrame:SetVisible(false)
					updateOccupationFrame:SetVisible(false)
					titleFrame:SetVisible(true)
					infoContentFrame:SetVisible(true)
				end
			end
		end
	end
	
	local designatedStatus = infoContentFrame:Add("EditablePanel")
	CreateRow(designatedStatus, "designated status", PLUGIN.file.genericdata.designatedStatus, PLUGIN.file.genericdata.designatedStatusDate, true, true)
	
	for k, v in pairs(designatedStatus:GetChildren()) do
		if v:GetName() == "bottom" then
			local updateStatusButton = v:Add("DButton")
			createUpdateButton(updateStatusButton)
			updateStatusButton.DoClick = function()
				surface.PlaySound("willardnetworks/datapad/navigate2.wav")
				titleFrame:SetVisible(false)
				infoContentFrame:SetVisible(false)
				
				local updateStatusTitleFrame = self:Add("EditablePanel")
				PLUGIN:CreateTitle(updateStatusTitleFrame, self, "edit designated status")
				
				local updateStatusTitleSubframe = updateStatusTitleFrame:Add("EditablePanel")
				updateStatusTitleSubframe:SetSize(137, 0)
				updateStatusTitleSubframe:Dock(RIGHT)
				updateStatusTitleSubframe.Paint = function(self, w, h) end
				
				local editStatus = updateStatusTitleSubframe:Add("DButton")
				PLUGIN:CreateTitleFrameRightTextButton(editStatus, updateStatusTitleSubframe, 87, "edit status", RIGHT)
				
				local back = updateStatusTitleSubframe:Add("DButton")	
				PLUGIN:CreateTitleFrameRightTextButton(back, updateStatusTitleSubframe, 68, "back", LEFT)	
				
				PLUGIN:DrawDividerLine(updateStatusTitleSubframe, 2, 13, back:GetWide() + 7, 4)
				
				local updateStatusFrame = self:Add("DPanel")
				updateStatusFrame:SetSize(self:GetWide(), 288)
				updateStatusFrame:Dock(TOP)
				updateStatusFrame:DockMargin(0, -2, 0, 0)
				updateStatusFrame.Paint = function(self, w, h)
					surface.SetDrawColor(40, 88, 115, 40)
					surface.DrawRect(0, 0, w, h)
				end
				
				local statusName = updateStatusFrame:Add("DLabel")
				statusName:SetFont("MenuFont")
				statusName:SetText(string.upper("enter status name:"))
				statusName:SetTextColor(color)
				statusName:Dock(TOP)
				statusName:DockMargin( 20, 20, 20, 10)
				
				local entry = vgui.Create("DTextEntry", updateStatusFrame)
				entry:Dock(TOP)
				entry:DockMargin(20, 0, 20, 10)
				entry:SetMultiline(false)
				entry:SetVerticalScrollbarEnabled( false )
				entry:SetText(PLUGIN.file.genericdata.designatedStatus)
				entry:SetEnterAllowed(false)
				entry:SetTextColor( color )
				entry:SetCursorColor( color )
				entry.Paint = function(self, w, h)
					surface.SetDrawColor(40, 88, 115, 75)
					surface.DrawRect(0, 0, w, h)
					
					self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
				end
				
				entry.MaxChars = 50
				entry.OnTextChanged = function(self)
					local txt = self:GetValue()
					local amt = string.len(txt)
					if amt > self.MaxChars then
						self:SetText(self.OldText)
						self:SetValue(self.OldText)
					else
						self.OldText = txt
					end
				end
				
				editStatus.DoClick = function()
					surface.PlaySound("willardnetworks/datapad/navigate.wav")
					PLUGIN.file.genericdata.designatedStatus = entry:GetText()
					PLUGIN.file.genericdata.designatedStatusDate = os.date("%d/%m/%Y")
					netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), 0, "DESIGNATED STATUS: "..entry:GetText())
					netstream.Start("EditDatafile", PLUGIN.file.genericdata)
				end
									
				back.DoClick = function()
					surface.PlaySound("willardnetworks/datapad/back.wav")
					updateStatusTitleFrame:SetVisible(false)
					updateStatusFrame:SetVisible(false)
					titleFrame:SetVisible(true)
					infoContentFrame:SetVisible(true)
				end
			end
		end
	end
end

vgui.Register("ixDatafileInfo", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 15)
	self.Paint = function(self, w, h) end
	
	local titleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(titleFrame, self, "view datafile logs")
	
	titleSubframe = titleFrame:Add("EditablePanel")
	titleSubframe:SetSize(181, 0)
	titleSubframe:Dock(RIGHT)
	titleSubframe.Paint = function(self, w, h) end
	
	local addGenericNote = titleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(addGenericNote, titleSubframe, 87, "add generic note", RIGHT)
	
	local back = titleSubframe:Add("DButton")	
	PLUGIN:CreateTitleFrameRightTextButton(back, titleSubframe, 68, "back", LEFT)	
	
	PLUGIN:DrawDividerLine(titleSubframe, 2, 13, back:GetWide() + 7, 4)
	
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		self:SetVisible(false)
		if IsValid(PLUGIN.datafileInfo) then
			PLUGIN.datafileInfo:SetVisible(true)
		end
		
		if IsValid(PLUGIN.datafileFunctions) then
			PLUGIN.datafileFunctions:SetVisible(true)
		end
	end
	
	local logsFrame = self:Add("DScrollPanel")
	logsFrame:SetSize(self:GetWide(), 576)
	logsFrame:Dock(TOP)
	logsFrame:DockMargin(0, -2, 0, 0)
	
	addGenericNote.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		titleFrame:SetVisible(false)
		logsFrame:SetVisible(false)
		
		local genericTitleFrame = self:Add("EditablePanel")
		PLUGIN:CreateTitle(genericTitleFrame, self, "add generic note")
		
		genericTitleSubframe = genericTitleFrame:Add("EditablePanel")
		genericTitleSubframe:SetSize(184, 0)
		genericTitleSubframe:Dock(RIGHT)
		genericTitleSubframe.Paint = function(self, w, h) end
		
		local saveGenericNote = genericTitleSubframe:Add("DButton")
		PLUGIN:CreateTitleFrameRightTextButton(saveGenericNote, genericTitleSubframe, 87, "save generic note", RIGHT)
		
		local genericBack = genericTitleSubframe:Add("DButton")	
		PLUGIN:CreateTitleFrameRightTextButton(genericBack, genericTitleSubframe, 68, "back", LEFT)	
		
		PLUGIN:DrawDividerLine(genericTitleSubframe, 2, 13, genericBack:GetWide() + 7, 4)
		
		local textEntryPanel = self:Add("DPanel")
		textEntryPanel:Dock(TOP)
		textEntryPanel:DockMargin(0, -2, 0, 0)
		textEntryPanel:SetSize(self:GetWide(), 576)
		textEntryPanel.Paint = function(self, w, h)
			surface.SetDrawColor(40, 88, 115, 75)
			surface.DrawRect(0, 0, w, h)
		end
		
		local genericEntry = textEntryPanel:Add("DTextEntry")
		genericEntry:SetSize(self:GetWide(), 30)
		genericEntry:Dock(TOP)
		genericEntry:DockMargin(0, -2, 0, 0)
		genericEntry:SetMultiline(false)
		genericEntry:RequestFocus()
		genericEntry:SetEnterAllowed(false)
		genericEntry:SetVerticalScrollbarEnabled( false )
		genericEntry:SetTextColor( color )
		genericEntry:SetCursorColor( color )
		genericEntry.Paint = function(self, w, h)			
			self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
		end
		genericEntry.MaxChars = 70
		genericEntry.OnTextChanged = function(self)
			local txt = self:GetValue()
			local amt = string.len(txt)
			if amt > self.MaxChars then
				self:SetText(self.OldText)
				self:SetValue(self.OldText)
			else
				self.OldText = txt
			end
		end
		
		saveGenericNote.DoClick = function()
			surface.PlaySound("willardnetworks/datapad/navigate.wav")
			netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), 0, genericEntry:GetText())
		end
		
		genericBack.DoClick = function()
			surface.PlaySound("willardnetworks/datapad/back.wav")
			genericTitleFrame:SetVisible(false)
			textEntryPanel:SetVisible(false)
			titleFrame:SetVisible(true)
			logsFrame:SetVisible(true)
		end
	end
	
	for k, v in SortedPairs(PLUGIN.file.datafilelogs, true) do
		local frame = logsFrame:Add("DPanel")
		frame:SetTall(48)
		frame:Dock(TOP)
		frame.Paint = function(self, w, h) 
			if (k % 2 == 0) then				
				surface.SetDrawColor(0, 0, 0, 75)
				surface.DrawRect(0, 0, w, h)
			else
				surface.SetDrawColor(40, 88, 115, 75)
				surface.DrawRect(0, 0, w, h)
			end
		end
		
		local top = frame:Add("EditablePanel")
		top:SetSize(frame:GetWide(), frame:GetTall() * 0.5)
		top:Dock(TOP)
		top.Paint = function(self, w, h) end
		
		local topPoster = top:Add("DLabel")
		topPoster:SetTextColor(Color(154, 169, 175, 255))
		topPoster:SetFont("MenuFont")
		topPoster:SetText(string.upper(PLUGIN.file.datafilelogs[k].poster))
		topPoster:Dock(LEFT)
		topPoster:DockMargin(20, 5, 0, 0)
		topPoster:SizeToContents()
		
		local topDate = top:Add("DLabel")
		topDate:SetTextColor(Color(154, 169, 175, 255))
		topDate:SetFont("MenuFont")
		topDate:SetText(string.upper("posted: ")..PLUGIN.file.datafilelogs[k].date)
		topDate:Dock(RIGHT)
		topDate:DockMargin(0, 5, 20, 0)
		topDate:SizeToContents()
			
		local bottom = frame:Add("EditablePanel")
		bottom:SetSize(frame:GetWide(), frame:GetTall() * 0.4)
		bottom:Dock(TOP)
		bottom.Paint = function(self, w, h) end
		bottom:SetName( "bottom" )
				
		local bottomText = bottom:Add("DLabel")
		bottomText:SetTextColor(color)
		bottomText:SetFont("MenuFont")
		bottomText:SetText(PLUGIN.file.datafilelogs[k].text)
		bottomText:Dock(LEFT)
		bottomText:DockMargin(20, 0, 0, 0)
		bottomText:SizeToContents()
		
		if PLUGIN.file.datafilelogs[k].points then 
			if PLUGIN.file.datafilelogs[k].points != 0 then
				local points = bottom:Add("DLabel")
				points:SetTextColor(color)
				points:SetFont("MenuFont")
				points:SetText(string.upper("points: ")..PLUGIN.file.datafilelogs[k].points)
				points:Dock(RIGHT)
				points:DockMargin(0, 0, 20, 0)
				points:SizeToContents()
			end
		end
	end
end

vgui.Register("ixDatafileEntryLogs", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), 300)
	self:Dock(TOP)
	self.Paint = function(self, w, h) end
	
	local titleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(titleFrame, self, "functions")
	
	local titleViolations = self:Add("DButton")
	CreateButton(titleViolations, "title violations", "smallerbuttonarrow.png")
	titleViolations:DockMargin(0, -2, 0, 9)
	
	titleViolations.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		PLUGIN.datafileInfo:SetVisible(false)
		PLUGIN.datafileFunctions:SetVisible(false)
		PLUGIN.viewTitleViolations = vgui.Create("ixDatafileTitleViolations", PLUGIN.contentSubframe)
	end
	
	local medicalRecords = self:Add("DButton")
	CreateButton(medicalRecords, "medical records", "smallerbuttonarrow.png")

	medicalRecords.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		PLUGIN.datafileInfo:SetVisible(false)
		PLUGIN.datafileFunctions:SetVisible(false)
		PLUGIN.viewMedicalRecords = vgui.Create("ixDatafileMedicalRecords", PLUGIN.contentSubframe)
	end
	
	local permits = self:Add("DButton")
	if PLUGIN.file.genericdata.permits == false then
		CreateButton(permits, "permit business licenses", "licensebuttonoff.png")
	else
		CreateButton(permits, "permit business licenses", "licensebutton.png")
	end
	
	permits.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		if PLUGIN.file.genericdata.permits == false then
			PLUGIN.file.genericdata.permits = true
			netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), 0, "Enabled business permit.")
		else
			PLUGIN.file.genericdata.permits = false
			netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), 0, "Removed business permit.")
		end
	
		netstream.Start("EditDatafile", PLUGIN.file.genericdata)
	end
	
	local bol = self:Add("DButton")
	if PLUGIN.file.genericdata.bol == false then
		CreateButton(bol, "be on lookout (b.o.l)", "bolbutton.png")
	else
		CreateButton(bol, "be on lookout (b.o.l)", "bolbuttonon.png")
	end
	
	bol.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		if PLUGIN.file.genericdata.bol == false then
			PLUGIN.file.genericdata.bol = true
			netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), 0, "Enabled B.O.L. status")
		else
			PLUGIN.file.genericdata.bol = false
			netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), 0, "Removed B.O.L status.")
		end
		
		netstream.Start("EditDatafile", PLUGIN.file.genericdata)
	end
	
	local anticitizen = self:Add("DButton")
	if PLUGIN.file.genericdata.anticitizen == false then
		CreateButton(anticitizen, "anti-citizen", "acbutton.png")
	else
		CreateButton(anticitizen, "anti-citizen", "acbuttonon.png")
	end
	
	anticitizen.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		if PLUGIN.file.genericdata.anticitizen == false then
			PLUGIN.file.genericdata.anticitizen = true
			netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), 0, "Enabled anti-citizen status.")
		else
			PLUGIN.file.genericdata.anticitizen = false
			netstream.Start("AddLog", PLUGIN.file.datafilelogs, PLUGIN.file.genericdata, LocalPlayer():Name(), 0, "Removed anti-citizen status.")
		end
		
		netstream.Start("EditDatafile", PLUGIN.file.genericdata)
	end
end

vgui.Register("ixDatafileFunctions", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 15)
	self.Paint = function(self, w, h) end
	
	local titleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(titleFrame, self, "title violations")
	
	titleSubframe = titleFrame:Add("EditablePanel")
	titleSubframe:SetSize(159, 0)
	titleSubframe:Dock(RIGHT)
	titleSubframe.Paint = function(self, w, h) end
	
	local addViolation = titleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(addViolation, titleSubframe, 87, "add violation", RIGHT)
	
	local back = titleSubframe:Add("DButton")	
	PLUGIN:CreateTitleFrameRightTextButton(back, titleSubframe, 68, "back", LEFT)	
	
	PLUGIN:DrawDividerLine(titleSubframe, 2, 13, back:GetWide() + 7, 4)
	
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		self:SetVisible(false)
		if IsValid(PLUGIN.datafileInfo) then
			PLUGIN.datafileInfo:SetVisible(true)
		end
		
		if IsValid(PLUGIN.datafileFunctions) then
			PLUGIN.datafileFunctions:SetVisible(true)
		end
	end
	
	local violationsFrame = self:Add("DScrollPanel")
	violationsFrame:SetSize(self:GetWide(), 576)
	violationsFrame:Dock(TOP)
	violationsFrame:DockMargin(0, -2, 0, 0)
	
	addViolation.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		titleFrame:SetVisible(false)
		violationsFrame:SetVisible(false)
		
		local violationsTitleFrame = self:Add("EditablePanel")
		PLUGIN:CreateTitle(violationsTitleFrame, self, "add title violation")
		
		PLUGIN.violationsTitleSubframe = violationsTitleFrame:Add("EditablePanel")
		PLUGIN.violationsTitleSubframe:SetSize(162, 0)
		PLUGIN.violationsTitleSubframe:Dock(RIGHT)
		PLUGIN.violationsTitleSubframe.Paint = function(self, w, h) end
		
		local saveViolation = PLUGIN.violationsTitleSubframe:Add("DButton")
		PLUGIN:CreateTitleFrameRightTextButton(saveViolation, PLUGIN.violationsTitleSubframe, 87, "save violation", RIGHT)
		
		local violationBack = PLUGIN.violationsTitleSubframe:Add("DButton")	
		PLUGIN:CreateTitleFrameRightTextButton(violationBack, PLUGIN.violationsTitleSubframe, 68, "back", LEFT)	
		
		PLUGIN:DrawDividerLine(PLUGIN.violationsTitleSubframe, 2, 13, violationBack:GetWide() + 7, 4)
		
		local violationsNewFrame = self:Add("DPanel")
		violationsNewFrame:Dock(TOP)
		violationsNewFrame:DockMargin(0, -2, 0, 0)
		violationsNewFrame:SetSize(self:GetWide(), 576)
		violationsNewFrame.Paint = function(self, w, h)
			surface.SetDrawColor(40, 88, 115, 75)
			surface.DrawRect(0, 0, w, h)
		end
		
		local verdictCodeText = violationsNewFrame:Add("DLabel")
		verdictCodeText:SetFont("MenuFont")
		verdictCodeText:SetTextColor(color)
		verdictCodeText:SetText(string.upper("verdict code [format: V###]:"))
		verdictCodeText:Dock(TOP)
		verdictCodeText:SetZPos(1)
		verdictCodeText:DockMargin(20, 20, 20, 10)
		
		local verdictCode = violationsNewFrame:Add("DTextEntry")
		verdictCode:Dock(TOP)
		verdictCode:DockMargin(20, 0, 20, 10)
		verdictCode:SetMultiline(false)
		verdictCode:RequestFocus()
		verdictCode:SetEnterAllowed(false)
		verdictCode:SetVerticalScrollbarEnabled( false )
		verdictCode:SetTextColor( color )
		verdictCode:SetZPos(2)
		verdictCode:SetCursorColor( color )
		verdictCode.MaxChars = 4
		verdictCode.Paint = function(self, w, h)
			surface.SetDrawColor(40, 88, 115, 75)
			surface.DrawRect(0, 0, w, h)
			
			self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
		end
		
		verdictCode.OnTextChanged = function(self)
			local txt = self:GetValue()
			local amt = string.len(txt)
			if amt > self.MaxChars then
				if self.OldText then
					self:SetText(self.OldText)
					self:SetValue(self.OldText)
				end
			else
				self.OldText = txt
			end
		end
		
		local reasonText = violationsNewFrame:Add("DLabel")
		reasonText:SetFont("MenuFont")
		reasonText:SetTextColor(color)
		reasonText:SetText(string.upper("reason:"))
		reasonText:Dock(TOP)
		reasonText:DockMargin(20, 0, 20, 10)
		reasonText:SetZPos(3)
		
		local reason = violationsNewFrame:Add("DTextEntry")
		reason:Dock(TOP)
		reason:DockMargin(20, 0, 20, 10)
		reason:SetMultiline(false)
		reason:RequestFocus()
		reason:SetEnterAllowed(false)
		reason:SetVerticalScrollbarEnabled( false )
		reason:SetTextColor( color )
		reason:SetCursorColor( color )
		reason:SetZPos(4)
		reason.MaxChars = 45
		reason.Paint = function(self, w, h)
			surface.SetDrawColor(40, 88, 115, 75)
			surface.DrawRect(0, 0, w, h)
			
			self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
		end
		
		reason.OnTextChanged = function(self)
			local txt = self:GetValue()
			local amt = string.len(txt)
			if amt > self.MaxChars then
				if self.OldText then
					self:SetText(self.OldText)
					self:SetValue(self.OldText)
				end
			else
				self.OldText = txt
			end
		end
		
		local punishmentText = violationsNewFrame:Add("DLabel")
		punishmentText:SetFont("MenuFont")
		punishmentText:SetTextColor(color)
		punishmentText:SetText(string.upper("punishment:"))
		punishmentText:Dock(TOP)
		punishmentText:SetZPos(5)
		punishmentText:DockMargin(20, 0, 20, 10)
		
		local punishmentBox = violationsNewFrame:Add("DComboBox")
		punishmentBox:SetZPos(6)
		punishmentBox:SetFont("MenuFont")
		punishmentBox:SetTextColor(color)
		punishmentBox:Dock(TOP)
		punishmentBox:DockMargin(20, 0, 20, 10)
		punishmentBox:SetValue( string.upper("options") )
		punishmentBox:AddChoice( string.upper("amputation") )
		punishmentBox:AddChoice( string.upper("re-education") )
		punishmentBox:AddChoice( string.upper("verbal warning") )
		punishmentBox:AddChoice( string.upper("other") )
		punishmentBox.Paint = function(panel, width, height)
			surface.SetDrawColor(40, 88, 115, 75)
			surface.DrawRect(0, 0, width, height)
		end
		
		saveViolation.DoClick = function()
			surface.PlaySound("willardnetworks/datapad/navigate.wav")
			netstream.Start("AddViolation", PLUGIN.file.datafileviolations, PLUGIN.file.genericdata, LocalPlayer():Name(), "["..verdictCode:GetText().."] :: ["..reason:GetText().."] :: ["..punishmentBox:GetText().."]")
		end
		
		violationBack.DoClick = function()
			surface.PlaySound("willardnetworks/datapad/back.wav")
			violationsTitleFrame:SetVisible(false)
			violationsNewFrame:SetVisible(false)
			titleFrame:SetVisible(true)
			violationsFrame:SetVisible(true)
		end
	end
	
	for k, v in SortedPairs(PLUGIN.file.datafileviolations, true) do
		local frame = violationsFrame:Add("DPanel")
		frame:SetTall(48)
		frame:Dock(TOP)
		frame.Paint = function(self, w, h) 
			if (k % 2 == 0) then				
				surface.SetDrawColor(0, 0, 0, 75)
				surface.DrawRect(0, 0, w, h)
			else
				surface.SetDrawColor(40, 88, 115, 75)
				surface.DrawRect(0, 0, w, h)
			end
		end
		
		local top = frame:Add("EditablePanel")
		top:SetSize(frame:GetWide(), frame:GetTall() * 0.5)
		top:Dock(TOP)
		top.Paint = function(self, w, h) end
		
		local topPoster = top:Add("DLabel")
		topPoster:SetTextColor(Color(154, 169, 175, 255))
		topPoster:SetFont("MenuFont")
		topPoster:SetText(string.upper(PLUGIN.file.datafileviolations[k].poster))
		topPoster:Dock(LEFT)
		topPoster:DockMargin(20, 5, 0, 0)
		topPoster:SizeToContents()
		
		local topDate = top:Add("DLabel")
		topDate:SetTextColor(Color(154, 169, 175, 255))
		topDate:SetFont("MenuFont")
		topDate:SetText(string.upper("posted: ")..PLUGIN.file.datafileviolations[k].date)
		topDate:Dock(RIGHT)
		topDate:DockMargin(0, 5, 20, 0)
		topDate:SizeToContents()
			
		local bottom = frame:Add("EditablePanel")
		bottom:SetSize(frame:GetWide(), frame:GetTall() * 0.4)
		bottom:Dock(TOP)
		bottom.Paint = function(self, w, h) end
		bottom:SetName( "bottom" )
				
		local bottomText = bottom:Add("DLabel")
		bottomText:SetTextColor(color)
		bottomText:SetFont("MenuFont")
		bottomText:SetText(PLUGIN.file.datafileviolations[k].text)
		bottomText:Dock(LEFT)
		bottomText:DockMargin(20, 0, 0, 0)
		bottomText:SizeToContents()
	end
end

vgui.Register("ixDatafileTitleViolations", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 15)
	self.Paint = function(self, w, h) end
	
	local titleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(titleFrame, self, "medical records")
	
	titleSubframe = titleFrame:Add("EditablePanel")
	titleSubframe:SetSize(142, 0)
	titleSubframe:Dock(RIGHT)
	titleSubframe.Paint = function(self, w, h) end
	
	local addRecord = titleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(addRecord, titleSubframe, 87, "add record", RIGHT)
	
	local back = titleSubframe:Add("DButton")	
	PLUGIN:CreateTitleFrameRightTextButton(back, titleSubframe, 68, "back", LEFT)	
	
	PLUGIN:DrawDividerLine(titleSubframe, 2, 13, back:GetWide() + 7, 4)
	
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		self:SetVisible(false)
		if IsValid(PLUGIN.datafileInfo) then
			PLUGIN.datafileInfo:SetVisible(true)
		end
		
		if IsValid(PLUGIN.datafileFunctions) then
			PLUGIN.datafileFunctions:SetVisible(true)
		end
	end
	
	local recordsFrame = self:Add("DScrollPanel")
	recordsFrame:SetSize(self:GetWide(), 576)
	recordsFrame:Dock(TOP)
	recordsFrame:DockMargin(0, -2, 0, 0)
	
	addRecord.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		titleFrame:SetVisible(false)
		recordsFrame:SetVisible(false)
		
		local recordsTitleFrame = self:Add("EditablePanel")
		PLUGIN:CreateTitle(recordsTitleFrame, self, "add medical record")
		
		recordsTitleSubframe = recordsTitleFrame:Add("EditablePanel")
		recordsTitleSubframe:SetSize(144, 0)
		recordsTitleSubframe:Dock(RIGHT)
		recordsTitleSubframe.Paint = function(self, w, h) end
		
		local saveRecord = recordsTitleSubframe:Add("DButton")
		PLUGIN:CreateTitleFrameRightTextButton(saveRecord, recordsTitleSubframe, 87, "save record", RIGHT)
		
		local recordBack = recordsTitleSubframe:Add("DButton")	
		PLUGIN:CreateTitleFrameRightTextButton(recordBack, recordsTitleSubframe, 68, "back", LEFT)	
		
		PLUGIN:DrawDividerLine(recordsTitleSubframe, 2, 13, recordBack:GetWide() + 7, 4)
		
		local recordsNewFrame = self:Add("DPanel")
		recordsNewFrame:Dock(TOP)
		recordsNewFrame:DockMargin(0, -2, 0, 0)
		recordsNewFrame:SetSize(self:GetWide(), 576)
		recordsNewFrame.Paint = function(self, w, h)
			surface.SetDrawColor(40, 88, 115, 75)
			surface.DrawRect(0, 0, w, h)
		end
		
		local recordsCodeText = recordsNewFrame:Add("DLabel")
		recordsCodeText:SetFont("MenuFont")
		recordsCodeText:SetTextColor(color)
		recordsCodeText:SetText(string.upper("Record content:"))
		recordsCodeText:Dock(TOP)
		recordsCodeText:SetZPos(1)
		recordsCodeText:DockMargin(20, 20, 20, 10)
		
		local record = recordsNewFrame:Add("DTextEntry")
		record:Dock(TOP)
		record:DockMargin(20, 0, 20, 10)
		record:SetMultiline(false)
		record:RequestFocus()
		record:SetEnterAllowed(false)
		record:SetVerticalScrollbarEnabled( false )
		record:SetTextColor( color )
		record:SetZPos(2)
		record:SetCursorColor( color )
		record.MaxChars = 50
		record.Paint = function(self, w, h)
			surface.SetDrawColor(40, 88, 115, 75)
			surface.DrawRect(0, 0, w, h)
			
			self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
		end
		
		record.OnTextChanged = function(self)
			local txt = self:GetValue()
			local amt = string.len(txt)
			if amt > self.MaxChars then
				if self.OldText then
					self:SetText(self.OldText)
					self:SetValue(self.OldText)
				end
			else
				self.OldText = txt
			end
		end
		
		saveRecord.DoClick = function()
			surface.PlaySound("willardnetworks/datapad/navigate.wav")
			netstream.Start("AddMedicalRecord", PLUGIN.file.datafilemedicalrecords, PLUGIN.file.genericdata, LocalPlayer():Name(), record:GetText())
		end
		
		recordBack.DoClick = function()
			surface.PlaySound("willardnetworks/datapad/back.wav")
			recordsTitleFrame:SetVisible(false)
			recordsNewFrame:SetVisible(false)
			titleFrame:SetVisible(true)
			recordsFrame:SetVisible(true)
		end
	end
	
	for k, v in SortedPairs(PLUGIN.file.datafilemedicalrecords, true) do
		local frame = recordsFrame:Add("DPanel")
		frame:SetTall(48)
		frame:Dock(TOP)
		frame.Paint = function(self, w, h) 
			if (k % 2 == 0) then				
				surface.SetDrawColor(0, 0, 0, 75)
				surface.DrawRect(0, 0, w, h)
			else
				surface.SetDrawColor(40, 88, 115, 75)
				surface.DrawRect(0, 0, w, h)
			end
		end
		
		local top = frame:Add("EditablePanel")
		top:SetSize(frame:GetWide(), frame:GetTall() * 0.5)
		top:Dock(TOP)
		top.Paint = function(self, w, h) end
		
		local topPoster = top:Add("DLabel")
		topPoster:SetTextColor(Color(154, 169, 175, 255))
		topPoster:SetFont("MenuFont")
		topPoster:SetText(string.upper(PLUGIN.file.datafilemedicalrecords[k].poster))
		topPoster:Dock(LEFT)
		topPoster:DockMargin(20, 5, 0, 0)
		topPoster:SizeToContents()
		
		local topDate = top:Add("DLabel")
		topDate:SetTextColor(Color(154, 169, 175, 255))
		topDate:SetFont("MenuFont")
		topDate:SetText(string.upper("posted: ")..PLUGIN.file.datafilemedicalrecords[k].date)
		topDate:Dock(RIGHT)
		topDate:DockMargin(0, 5, 20, 0)
		topDate:SizeToContents()
			
		local bottom = frame:Add("EditablePanel")
		bottom:SetSize(frame:GetWide(), frame:GetTall() * 0.4)
		bottom:Dock(TOP)
		bottom.Paint = function(self, w, h) end
		bottom:SetName( "bottom" )
				
		local bottomText = bottom:Add("DLabel")
		bottomText:SetTextColor(color)
		bottomText:SetFont("MenuFont")
		bottomText:SetText(PLUGIN.file.datafilemedicalrecords[k].text)
		bottomText:Dock(LEFT)
		bottomText:DockMargin(20, 0, 0, 0)
		bottomText:SizeToContents()
	end
end

vgui.Register("ixDatafileMedicalRecords", PANEL, "EditablePanel")