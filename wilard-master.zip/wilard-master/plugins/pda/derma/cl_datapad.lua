
local PLUGIN = PLUGIN

local color = Color(41, 243, 229, 255)

function PLUGIN:DrawDividerLine(parent, w, h, x, y)
	local dividerLine = parent:Add("DShape")
	dividerLine:SetType( "Rect" )
	dividerLine:SetSize(w, h)
	dividerLine:SetPos(x, y)
	dividerLine:SetColor(color)
end

function PLUGIN:CreateTitle(name, parent, text)
	name:SetSize(parent:GetWide(), 27)
	name:Dock(TOP)
	name:DockMargin(0, 0, 0, 11)
	name.Paint = function(self, w, h) end
	
	local title = name:Add("DLabel")
	title:SetFont("TitlesFont")
	title:SetTextColor(color)
	title:SetText(string.upper(text))
	title:SetTextInset(0, -5)
	title:SizeToContents()
	
	PLUGIN:DrawDividerLine(name, name:GetWide(), 4, 0, name:GetTall() - 4)
end

function PLUGIN:CreateTitleFrameRightTextButton(name, parent, width, text, dock)
	name:SetFont("MenuFont")
	name:SetTextColor(color)
	name:SetText(string.upper(text))
	name:Dock(dock)
	name:DockMargin(0, 0, -4, 8)
	name:SizeToContents()
	name.Paint = function(self, w, h) end
end

function PLUGIN:CreateUpdates(parent, k, v, datemargin)
	parent:SetSize(parent:GetWide(), 48)
	parent:Dock(TOP)
	parent.Paint = function(self, w, h) 
		if k % 2 == 0 then				
			surface.SetDrawColor(0, 0, 0, 75)
			surface.DrawRect(0, 0, w, h)
		else
			surface.SetDrawColor(40, 88, 115, 75)
			surface.DrawRect(0, 0, w, h)
		end
	end
	
	local top = parent:Add("EditablePanel")
	top:SetSize(parent:GetWide(), parent:GetTall() * 0.5)
	top:Dock(TOP)
	top.Paint = function(self, w, h) end
	
	local name = top:Add("DLabel")
	name:SetTextColor(Color(154, 169, 175, 255))
	name:SetFont("MenuFont")
	name:SetText(v.update_poster)
	name:Dock(LEFT)
	name:DockMargin(20, 5, 0, 0)
	name:SizeToContents()
	
	local date = top:Add("DLabel")
	date:SetFont("MenuFont")
	date:SetTextColor(Color(154, 169, 175, 255))
	date:SetText(v.update_date)
	date:Dock(RIGHT)
	date:DockMargin(0, 5, datemargin, 0)
	date:SizeToContents()
	
	local bottom = parent:Add("EditablePanel")
	bottom:SetSize(parent:GetWide(), parent:GetTall() * 0.4)
	bottom:Dock(TOP)
	bottom.Paint = function(self, w, h) end
	bottom:SetName( "bottom" )

	local string = v.update_text
	local a = string.find(string, "[\n]")
	local excerpt = string.sub(string, 1, a)	
		
	local textExcerpt = bottom:Add("HTML")
	textExcerpt:SetSize(440, 100)
	textExcerpt:SetHTML("<p style='font-family: Open Sans; font-size: 13; color: rgb(41,243,229);'>"..excerpt.."</p>")
	textExcerpt:SetPos(12, -10)
end

function PLUGIN:CreateButton(name, text)
	name:SetSize(480, 46)
	name:SetContentAlignment(4)
	name:SetTextInset(20, 0)
	name:Dock(TOP)
	name:SetFont("TitlesFont")
	name:DockMargin(0, 0, 0, 9)
	name:SetText(string.upper(text))
	name.Paint = function(self, w, h) 
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("willardnetworks/datafile/button.png"))
		surface.DrawTexturedRect(0, 0, w, h) 
	end
end

function PLUGIN:CreateEditingButton(name, text)
	name:SetSize(560 / 5, 200 / 6)
	name:SetContentAlignment(5)
	name:Dock(LEFT)
	name:DockMargin(0, 0, 10, 0)
	name:SetFont("MenuFontBold")
	name:SetText(string.upper(text))
	name.Paint = function(self, w, h) 
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(Material("willardnetworks/datafile/buttonnoarrow.png"))
		surface.DrawTexturedRect(0, 0, w, h)
	end
end

local PANEL = {}

function PANEL:Init()
	self:SetSize(ScrW(), ScrH())
	self:MakePopup()
	self.Paint = function(self, w, h) end
	
	local mainFrame = self:Add("EditablePanel")
	mainFrame:SetSize(645, 850)
	mainFrame:Center()
	mainFrame.Paint = function(self, w, h)
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("willardnetworks/datafile/mainframe.png"))
		surface.DrawTexturedRect(0, 0, w, h)
	end
	
	local close = self:Add("DButton")
	close:SetSize(107, 105)
	close:SetPos(ScrW() * 0.5 + mainFrame:GetWide() * 0.5 - close:GetWide() * 0.6, ScrH() * 0.5 - mainFrame:GetTall() * 0.5 - close:GetTall() * 0.4)
	close:SetText("")
	close.Paint = function(self, w, h)
		if close:IsHovered() then
			surface.SetDrawColor(Color(255, 255, 255, 50))
			surface.SetMaterial(Material("willardnetworks/datafile/gadgetlight.png"))
			surface.DrawTexturedRect(0, 0, w, h)
		end
	end
	close.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/close.wav")
		self:Remove()
	end

	local subFrame = mainFrame:Add("EditablePanel")
	subFrame:SetSize(560, 782)
	subFrame:Center()
	subFrame.Paint = function(self, w, h) end
	
	local titleFrame = subFrame:Add("EditablePanel")
	titleFrame:SetSize(subFrame:GetWide(), 50)
	titleFrame:Dock(TOP)
	titleFrame.Paint = function(self, w, h) end
	
	PLUGIN.mainTitle = titleFrame:Add("DLabel")
	PLUGIN.mainTitle:SetFont("DatapadTitle")
	PLUGIN.mainTitle:SetText(string.upper("datapad"))
	PLUGIN.mainTitle:SetTextInset(20, 4)
	PLUGIN.mainTitle:SizeToContents()
	
	local contentFrame = subFrame:Add("EditablePanel")
	contentFrame:SetSize(subFrame:GetWide(), subFrame:GetTall() - titleFrame:GetTall())
	contentFrame:Dock(TOP)
	contentFrame.Paint = function(self, w, h) end
	
	local padding = 80
	PLUGIN.contentSubframe = contentFrame:Add("EditablePanel")
	PLUGIN.contentSubframe:SetSize(contentFrame:GetWide() - padding, contentFrame:GetTall() - padding)
	PLUGIN.contentSubframe:Center()
	PLUGIN.contentSubframe.Paint = function(self, w, h) end
	
	PLUGIN.updates = vgui.Create("ixDatapadUpdates", PLUGIN.contentSubframe)
	PLUGIN.functions = vgui.Create("ixDatapadFunctions", PLUGIN.contentSubframe)
end

vgui.Register("ixDatafilePDA", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), 230)
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 32)
	self.Paint = function(self, w, h) end
	
	local updatesTitleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(updatesTitleFrame, self, "updates")
		
	updatesTitleSubframe = updatesTitleFrame:Add("EditablePanel")
	updatesTitleSubframe:SetSize(183, 0)
	updatesTitleSubframe:Dock(RIGHT)
	updatesTitleSubframe.Paint = function(self, w, h) end
		
	local editUpdates = updatesTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(editUpdates, updatesTitleSubframe, 87, "edit updates", RIGHT)
	
	local viewLogs = updatesTitleSubframe:Add("DButton")	
	PLUGIN:CreateTitleFrameRightTextButton(viewLogs, updatesTitleSubframe, 68, "view logs", LEFT)	
	
	PLUGIN:DrawDividerLine(updatesTitleSubframe, 2, 13, viewLogs:GetWide() + 7, 4)
	
	local updatesContentFrame = self:Add("EditablePanel")
	updatesContentFrame:SetSize(self:GetWide(), 192)
	updatesContentFrame:Dock(TOP)
	updatesContentFrame:DockMargin(0, -2, 0, 0)
	updatesContentFrame.Paint = function(self, w, h) end
		
	for k, v in SortedPairsByMemberValue(PLUGIN.updatelist, "update_id", true) do
		local updateFrame = updatesContentFrame:Add("EditablePanel")
		if (k == #PLUGIN.updatelist or k == #PLUGIN.updatelist - 1 or k == #PLUGIN.updatelist - 2 or k == #PLUGIN.updatelist - 3) then
			PLUGIN:CreateUpdates(updateFrame, k, v, 20)
		end
	end
		
	editUpdates.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		if IsValid(PLUGIN.searchProfiles) then
			PLUGIN.searchProfiles:SetVisible(false)
		end
		
		PLUGIN.updates:SetVisible(false)
		PLUGIN.functions:SetVisible(false)
		PLUGIN.editupdates = vgui.Create("ixDatapadEditUpdates", PLUGIN.contentSubframe)
	end
	
	viewLogs.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		if IsValid(PLUGIN.searchProfiles) then
			PLUGIN.searchProfiles:SetVisible(false)
		end
		PLUGIN.updates:SetVisible(false)
		PLUGIN.functions:SetVisible(false)
		PLUGIN.viewLogs = vgui.Create("ixDatapadViewUpdates", PLUGIN.contentSubframe)
	end
end

vgui.Register("ixDatapadUpdates", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 32)
	self.Paint = function(self, w, h) end
	
	local updatesTitleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(updatesTitleFrame, self, "edit updates")
	
	PLUGIN:DrawDividerLine(updatesTitleFrame, updatesTitleFrame:GetWide(), 4, 0, updatesTitleFrame:GetTall() - 4)
	
	updatesTitleSubframe = updatesTitleFrame:Add("EditablePanel")
	updatesTitleSubframe:SetSize(140, 0)
	updatesTitleSubframe:Dock(RIGHT)
	updatesTitleSubframe.Paint = function(self, w, h) end
		
	local newUpdate = updatesTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(newUpdate, updatesTitleSubframe, 87, "new update", RIGHT)
	
	local back = updatesTitleSubframe:Add("DButton")	
	PLUGIN:CreateTitleFrameRightTextButton(back, updatesTitleSubframe, 68, "back", LEFT)
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		self:SetVisible(false)
		PLUGIN.updates:SetVisible(true)
		PLUGIN.functions:SetVisible(true)
	end
	
	PLUGIN:DrawDividerLine(updatesTitleSubframe, 2, 13, back:GetWide() + 6, 4)
	
	newUpdate.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		self:SetVisible(false)
		PLUGIN.newUpdate = vgui.Create("ixDatapadNewUpdate", PLUGIN.contentSubframe)
	end
	
	local updatesContentFrame = self:Add("EditablePanel")
	updatesContentFrame:SetSize(self:GetWide(), 48 * 10)
	updatesContentFrame:Dock(TOP)
	updatesContentFrame:DockMargin(0, -2, 0, 0)
	updatesContentFrame.Paint = function(self, w, h) end

	for k, v in SortedPairsByMemberValue(PLUGIN.updatelist, "update_id", true) do
		local updateFrame = updatesContentFrame:Add("EditablePanel")
		PLUGIN:CreateUpdates(updateFrame, k, v, 20)
		
		for k2, v2 in ipairs( updateFrame:GetChildren() ) do
			if v2:GetName() == "bottom" then
				for k3, v3 in ipairs( v2:GetChildren() ) do
					v3:SetWide(340)
				end
				local removeUpdate = v2:Add("DButton")
				removeUpdate:Dock(RIGHT)
				removeUpdate:DockMargin(0, 0, 16, 5)
				removeUpdate:SetFont("MenuFont")
				removeUpdate:SetTextColor(color)
				removeUpdate:SetText(string.upper("remove"))
				removeUpdate:SizeToContents()
				removeUpdate.Paint = function(self, w, h) end
				removeUpdate.DoClick = function()
					netstream.Start("RemoveUpdate", v.update_id)
				end
				
				PLUGIN:DrawDividerLine(updateFrame, 2, 11, updatesContentFrame:GetWide() - removeUpdate:GetWide() - 20, 28)
				
				local editUpdate = v2:Add("DButton")
				editUpdate:Dock(RIGHT)
				editUpdate:DockMargin(0, 0, 7, 5)
				editUpdate:SetFont("MenuFont")
				editUpdate:SetTextColor(color)
				editUpdate:SetText(string.upper("edit"))
				editUpdate:SizeToContents()
				editUpdate.Paint = function(self, w, h) end
				editUpdate.DoClick = function()
					self:SetVisible(false)
					surface.PlaySound("willardnetworks/datapad/navigate2.wav")
					PLUGIN.editUpdate = vgui.Create("ixDatapadNewUpdate", PLUGIN.contentSubframe)
					PLUGIN.textEntry:SetValue(v.update_text)
					PLUGIN.addUpdate:SetText(string.upper("edit update"))
					PLUGIN.addUpdate.DoClick = function()
						netstream.Start("EditUpdate", v.update_id, PLUGIN.textEntry:GetText())
					end
				end
			end
		end
				
	end
end

vgui.Register("ixDatapadEditUpdates", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 32)
	self.Paint = function(self, w, h) end
	
	local updatesTitleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(updatesTitleFrame, self, "add/edit updates")
	
	updatesTitleSubframe = updatesTitleFrame:Add("EditablePanel")
	updatesTitleSubframe:SetSize(209, 0)
	updatesTitleSubframe:Dock(RIGHT)
	updatesTitleSubframe.Paint = function(self, w, h) end
		
	PLUGIN.addUpdate = updatesTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(PLUGIN.addUpdate, updatesTitleSubframe, 20, "add update", RIGHT)

	local preview = updatesTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(preview, updatesTitleSubframe, 20, "preview", RIGHT)
	preview:DockMargin(0, 0, 9, 8)
	preview.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		if PLUGIN.newUpdate:IsVisible() then
			PLUGIN.newUpdate:Dock(NODOCK)
			PLUGIN.newUpdate:SetPos(0, 790)
		elseif PLUGIN.editUpdate:IsVisible() then
			PLUGIN.editUpdate:Dock(NODOCK)
			PLUGIN.editUpdate:SetPos(0, 790)
		end
			
		local previewFrame = vgui.Create("ixDatapadNewUpdatePreview", PLUGIN.contentSubframe)
	end
	
	PLUGIN:DrawDividerLine(updatesTitleFrame, updatesTitleFrame:GetWide(), 4, 0, updatesTitleFrame:GetTall() - 4)
	
	local back = updatesTitleSubframe:Add("DButton")	
	PLUGIN:CreateTitleFrameRightTextButton(back, updatesTitleSubframe, 68, "back", LEFT)
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		self:SetVisible(false)
		PLUGIN.editupdates:SetVisible(true)
	end
	
	PLUGIN:DrawDividerLine(updatesTitleSubframe, 2, 13, back:GetWide() + 5, 4)
	PLUGIN:DrawDividerLine(updatesTitleSubframe, 2, 13, back:GetWide() + preview:GetWide() + 16, 4)
	
	local updatesContentFrame = self:Add("EditablePanel")
	updatesContentFrame:SetSize(self:GetWide(), self:GetTall() - 126)
	updatesContentFrame:Dock(TOP)
	updatesContentFrame:DockMargin(0, -2, 0, 0)
	updatesContentFrame.Paint = function(self, w, h) end
	
	PLUGIN.textEntry = vgui.Create("DTextEntry", updatesContentFrame)
	PLUGIN.textEntry:SetSize(self:GetWide(), updatesContentFrame:GetTall())
	PLUGIN.textEntry:SetMultiline(true)
	PLUGIN.textEntry:SetEnterAllowed(true)
	PLUGIN.textEntry:SetVerticalScrollbarEnabled( true )
	PLUGIN.textEntry:RequestFocus()
	PLUGIN.textEntry:SetTextColor( color )
	PLUGIN.textEntry:SetCursorColor( color )
	PLUGIN.textEntry.Paint = function(self, w, h)
		surface.SetDrawColor(40, 88, 115, 75)
		surface.DrawRect(0, 0, w, h)
		
		self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
	end
		
	local textEntry = PLUGIN.textEntry
	
	PLUGIN.addUpdate.DoClick = function()
		if #PLUGIN.updatelist == 10 then
			LocalPlayer():NotifyLocalized("You need to delete an update before you can create a new one!")
			surface.PlaySound("willardnetworks/datapad/deny.wav")
			return false
		end
		netstream.Start("AddUpdate", textEntry:GetText())
	end
	
	local updateHelpFrame = self:Add("EditablePanel")
	updateHelpFrame:SetSize(560, 80)
	updateHelpFrame:Dock(TOP)
	updateHelpFrame:DockMargin(0, 10, 0, 0)
	updateHelpFrame.Paint = function(self, w, h) 
		surface.SetDrawColor(Color(0, 0, 0, 40))
		surface.DrawRect(0, 0, w, h)
	end
	
	local topbuttons = updateHelpFrame:Add("DPanel")
	topbuttons:Dock(TOP)
	topbuttons:SetTall(200 / 6)
	topbuttons.Paint = function(self, w, h) end
	
	local unorderedlist = topbuttons:Add("DButton")
	PLUGIN:CreateEditingButton(unorderedlist, "unordered list")
	unorderedlist.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		textEntry:SetValue(textEntry:GetValue().."<ul style='font-family: Open Sans; font-size: 13; color: rgb(41,243,229);'> <li>Coffee</li> <li>Tea</li> <li>Milk</li> </ul>")
	end
	unorderedlist:SetSize(560 / 2.39, 200 / 6)
	
	local orderedlist = topbuttons:Add("DButton")
	PLUGIN:CreateEditingButton(orderedlist, "ordered list")
	orderedlist.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		textEntry:SetValue(textEntry:GetValue().."<ol style='font-family: Open Sans; font-size: 13; color: rgb(41,243,229);'> <li>Coffee</li> <li>Tea</li> <li>Milk</li> </ol>")
	end
	orderedlist:SetSize(560 / 2.39, 200 / 6)
	
	local bottombuttons = updateHelpFrame:Add("DPanel")
	bottombuttons:Dock(TOP)
	bottombuttons:DockMargin(0, 10, 0, 0)
	bottombuttons:SetTall(200 / 6)
	bottombuttons.Paint = function(self, w, h) end
	
	local underline = bottombuttons:Add("DButton")
	PLUGIN:CreateEditingButton(underline, "underline")
	underline.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		textEntry:SetValue(textEntry:GetValue().."<u>texthere </u>")
	end
	
	local colortext = bottombuttons:Add("DButton")
	PLUGIN:CreateEditingButton(colortext, "color text")
	colortext.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		textEntry:SetValue(textEntry:GetValue().."<colortext style='font-family: Open Sans; font-size: 13; color: red;'>text here</colortext>")
	end
	
	local bold = bottombuttons:Add("DButton")
	PLUGIN:CreateEditingButton(bold, "bold")
	bold.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		textEntry:SetValue(textEntry:GetValue().."<b>text here</b>")
	end
	
	local italic = bottombuttons:Add("DButton")
	PLUGIN:CreateEditingButton(italic, "italic")
	italic.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		textEntry:SetValue(textEntry:GetValue().."<i style='font-family: Open Sans; font-size: 13; color: rgb(41,243,229);'>text here</i>")
	end
end

vgui.Register("ixDatapadNewUpdate", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(560, 782)
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 32)
	self.Paint = function(self, w, h) end
	
	local updatesTitleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(updatesTitleFrame, self, "preview")
	
	local updatesTitleSubframe = updatesTitleFrame:Add("EditablePanel")
	updatesTitleSubframe:SetSize(50, 0)
	updatesTitleSubframe:Dock(RIGHT)
	updatesTitleSubframe.Paint = function(self, w, h) end
		
	local back = updatesTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(back, updatesTitleSubframe, 87, "back", RIGHT)
	back.DoClick = function()
		self:SetVisible(false)
		surface.PlaySound("willardnetworks/datapad/back.wav")
		if PLUGIN.newUpdate:IsVisible() then
			PLUGIN.newUpdate:SetPos(0, 0)
		elseif PLUGIN.editUpdate:IsVisible() then
			PLUGIN.editUpdate:SetPos(0, 0)
		end
	end
	
	PLUGIN:DrawDividerLine(updatesTitleSubframe, 2, 13, 6, 4)
		
	local updatesContentFrame = self:Add("EditablePanel")
	updatesContentFrame:SetSize(self:GetWide(), self:GetParent():GetTall())
	updatesContentFrame:Dock(TOP)
	updatesContentFrame:DockMargin(0, -2, 0, 0)
	updatesContentFrame.Paint = function(self, w, h) end
	
	local updateFrame = updatesContentFrame:Add("HTML")
	updateFrame:SetSize(updatesContentFrame:GetWide(), self:GetParent():GetTall())
	local string = "<p style='font-family: Open Sans; font-size: 13; color: rgb(41,243,229);'>"..PLUGIN.textEntry:GetText().."</p>"
	local html = string.Replace(string, "\n", "<br>")
	updateFrame:SetHTML(html)
	updateFrame.Paint = function(self, w, h) 
		surface.SetDrawColor(40, 88, 115, 75)
		surface.DrawRect(0, 0, w, h)
	end
end

vgui.Register("ixDatapadNewUpdatePreview", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 32)
	self.Paint = function(self, w, h) end
	
	local updatesTitleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(updatesTitleFrame, self, "view logs")
		
	updatesTitleSubframe = updatesTitleFrame:Add("EditablePanel")
	updatesTitleSubframe:SetSize(50, 0)
	updatesTitleSubframe:Dock(RIGHT)
	updatesTitleSubframe.Paint = function(self, w, h) end
		
	local back = updatesTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(back, updatesTitleSubframe, 87, "back", RIGHT)
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		self:SetVisible(false)
		PLUGIN.updates:SetVisible(true)
		PLUGIN.functions:SetVisible(true)
	end
	
	PLUGIN:DrawDividerLine(updatesTitleSubframe, 2, 13, 6, 4)
	
	local updatesContentFrame = self:Add("EditablePanel")
	updatesContentFrame:SetSize(self:GetWide(), 48 * 10)
	updatesContentFrame:Dock(TOP)
	updatesContentFrame:DockMargin(0, -2, 0, 0)
	updatesContentFrame.Paint = function(self, w, h) end

	for k, v in SortedPairsByMemberValue(PLUGIN.updatelist, "update_id", true) do
		local updateFrame = updatesContentFrame:Add("EditablePanel")
		PLUGIN:CreateUpdates(updateFrame, k, v, 20)
		for k2, v2 in ipairs( updateFrame:GetChildren() ) do
			if v2:GetName() == "bottom" then
				for k3, v3 in pairs(v2:GetChildren()) do
					v3:SetWide(360)
				end
				local viewLog = v2:Add("DButton")
				viewLog:SetTextColor(color)
				viewLog:SetFont("MenuFont")
				viewLog:SetText(string.upper("view log"))
				viewLog:Dock(RIGHT)
				viewLog:DockMargin(0, 0, 16, 5)
				viewLog:SizeToContents()
				viewLog.Paint = function(self, w, h) end
				
				viewLog.DoClick = function()
					surface.PlaySound("willardnetworks/datapad/navigate2.wav")
					PLUGIN.viewLogs:SetVisible(false)
					PLUGIN.viewLogID = v
					PLUGIN.viewLog = vgui.Create("ixDatapadViewUpdate", PLUGIN.contentSubframe)
				end
			end
		end
	end
end
vgui.Register("ixDatapadViewUpdates", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 32)
	self.Paint = function(self, w, h) end
	
	local updatesTitleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(updatesTitleFrame, self, "view log")
	
	updatesTitleSubframe = updatesTitleFrame:Add("EditablePanel")
	updatesTitleSubframe:SetSize(50, 0)
	updatesTitleSubframe:Dock(RIGHT)
	updatesTitleSubframe.Paint = function(self, w, h) end
		
	local back = updatesTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(back, updatesTitleSubframe, 87, "back", RIGHT)
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		self:SetVisible(false)
		PLUGIN.viewLogs:SetVisible(true)
	end
	
	PLUGIN:DrawDividerLine(updatesTitleSubframe, 2, 13, 6, 4)
	
	local updatesContentFrame = self:Add("EditablePanel")
	updatesContentFrame:SetSize(self:GetWide(), self:GetParent():GetTall())
	updatesContentFrame:Dock(TOP)
	updatesContentFrame:DockMargin(0, -2, 0, 0)
	updatesContentFrame.Paint = function(self, w, h) end
	
	local updateFrame = updatesContentFrame:Add("EditablePanel")
	PLUGIN:CreateUpdates(updateFrame, 1, PLUGIN.viewLogID, 20)
	updateFrame:SetSize(updatesContentFrame:GetWide(), self:GetParent():GetTall())
	for k, v in pairs(updateFrame:GetChildren()) do
		if v:GetName() == "bottom" then
			v:Dock(TOP)
			v:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall() - 50)
			for k2, v2 in pairs(v:GetChildren()) do
				local string = "<p style='font-family: Open Sans; font-size: 13; color: rgb(41,243,229);'>"..PLUGIN.viewLogID.update_text.."</p>"
				local html = string.Replace(string, "\n", "<br>")
				v2:SetHTML(html)
				v2:SetSize(self:GetParent():GetWide() - 16, self:GetParent():GetTall() - 20)
			end
		end
	end
end
vgui.Register("ixDatapadViewUpdate", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()	
	self:SetSize(self:GetParent():GetWide(), 300)
	self:Dock(TOP)
	self.Paint = function(self, w, h) end
	
	local titleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(titleFrame, self, "functions")
		
	local searchProfiles = self:Add("DButton")
	PLUGIN:CreateButton(searchProfiles, "search citizen data profiles")
	searchProfiles:DockMargin(0, -2, 0, 9)
	searchProfiles.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		PLUGIN.functions:SetVisible(false)
		PLUGIN.searchProfiles = vgui.Create("ixDatapadSearchProfiles", PLUGIN.contentSubframe)
	end
	
	local viewMyData = self:Add("DButton")
	PLUGIN:CreateButton(viewMyData, "view my data profile")
	viewMyData.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		PLUGIN.updates:SetVisible(false)
		PLUGIN.functions:SetVisible(false)
		netstream.Start("OpenDatafile", LocalPlayer():GetCharacter():GetID(), true)
	end
	
	local verdictCodes = self:Add("DButton")
	PLUGIN:CreateButton(verdictCodes, "verdict codes")
	verdictCodes.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		PLUGIN.updates:SetVisible(false)
		PLUGIN.functions:SetVisible(false)
		PLUGIN.verdictCodes = vgui.Create("ixDatapadFunctionVerdictCodes", PLUGIN.contentSubframe)
	end
	
	local communicationCodes = self:Add("DButton")
	PLUGIN:CreateButton(communicationCodes, "communication codes")
	communicationCodes.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate.wav")
		PLUGIN.updates:SetVisible(false)
		PLUGIN.functions:SetVisible(false)
		PLUGIN.communicationCodes = vgui.Create("ixDatapadFunctionComCodes", PLUGIN.contentSubframe)
	end
end

vgui.Register("ixDatapadFunctions", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), 247)
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 32)
	self.Paint = function(self, w, h) end
	
	local searchProfilesTitleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(searchProfilesTitleFrame, self, "search profiles")
	
	searchTitleSubframe = searchProfilesTitleFrame:Add("EditablePanel")
	searchTitleSubframe:SetSize(108, 0)
	searchTitleSubframe:Dock(RIGHT)
	searchTitleSubframe.Paint = function(self, w, h) end
	
	local search = searchTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(search, searchTitleSubframe, 87, "search", RIGHT)
	
	local back = searchTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(back, searchTitleSubframe, 87, "back", LEFT)
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		self:SetVisible(false)
		PLUGIN.functions:SetVisible(true)
	end
	
	PLUGIN:DrawDividerLine(searchTitleSubframe, 2, 13, back:GetWide() + 7, 4)
	
	local contentFrame = self:Add("EditablePanel")
	contentFrame:SetSize(self:GetWide(), self:GetParent():GetTall())
	contentFrame:Dock(TOP)
	contentFrame:DockMargin(0, -2, 0, 0)
	contentFrame.Paint = function(self, w, h) 
		surface.SetDrawColor(40, 88, 115, 75)
		surface.DrawRect(0, 0, w, h)
	end
	
	local nameText = contentFrame:Add("DLabel")
	nameText:SetFont("MenuFont")
	nameText:SetTextColor(color)
	nameText:SetText(string.upper("Name or CID:"))
	nameText:Dock(TOP)
	nameText:SetZPos(1)
	nameText:DockMargin(20, 20, 20, 10)
	
	local name = contentFrame:Add("DTextEntry")
	name:Dock(TOP)
	name:DockMargin(20, 0, 20, 10)
	name:SetMultiline(false)
	name:RequestFocus()
	name:SetEnterAllowed(true)
	name:SetVerticalScrollbarEnabled( false )
	name:SetTextColor( color )
	name:SetZPos(2)
	name:SetCursorColor( color )
	name.Paint = function(self, w, h)
		surface.SetDrawColor(40, 88, 115, 75)
		surface.DrawRect(0, 0, w, h)
		
		self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
	end
	
	name.OnEnter = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		netstream.Start("OpenDatafile", name:GetText(), false)
	end
	
	search.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		netstream.Start("OpenDatafile", name:GetText(), false)
	end
end

vgui.Register("ixDatapadSearchProfiles", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 32)
	self.Paint = function(self, w, h) end
	
	local verdictTitleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(verdictTitleFrame, self, "verdict codes")
		
	verdictCodesTitleSubframe = verdictTitleFrame:Add("EditablePanel")
	verdictCodesTitleSubframe:SetSize(130, 0)
	verdictCodesTitleSubframe:Dock(RIGHT)
	verdictCodesTitleSubframe.Paint = function(self, w, h) end
		
	local editCodes = verdictCodesTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(editCodes, verdictCodesTitleSubframe, 48, "edit codes", RIGHT)
	
	local back = verdictCodesTitleSubframe:Add("DButton")	
	PLUGIN:CreateTitleFrameRightTextButton(back, verdictCodesTitleSubframe, 48, "back", LEFT)
	
	PLUGIN:DrawDividerLine(verdictCodesTitleSubframe, 2, 13, back:GetWide() + 6, 4)
	
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		PLUGIN.updates:SetVisible(true)
		PLUGIN.functions:SetVisible(true)
		self:SetVisible(false)
	end
	
	local verdictContentFrame = self:Add("EditablePanel")
	verdictContentFrame:SetSize(self:GetWide(), self:GetParent():GetTall())
	verdictContentFrame:Dock(TOP)
	verdictContentFrame:DockMargin(0, -2, 0, 0)
	verdictContentFrame.Paint = function(self, w, h) end
	
	local textEntry = vgui.Create("DTextEntry", verdictContentFrame)
	textEntry:SetSize(self:GetWide(), verdictContentFrame:GetTall())
	textEntry:SetMultiline(true)
	textEntry:SetValue(PLUGIN.verdictCode or "")
	textEntry:SetEnterAllowed(true)
	textEntry:SetVerticalScrollbarEnabled( true )
	textEntry:SetEditable(false)
	textEntry:RequestFocus()
	textEntry:SetTextColor( color )
	textEntry:SetCursorColor( color )
	textEntry.Paint = function(self, w, h)
		surface.SetDrawColor(40, 88, 115, 75)
		surface.DrawRect(0, 0, w, h)
		
		self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
	end
	
	editCodes.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		textEntry:SetEditable(true)
		editCodes:SetText(string.upper("save"))
		editCodes:SetContentAlignment(6)
		editCodes:Dock(NODOCK)
		editCodes:SetPos(8)
		verdictCodesTitleSubframe:SetSize(88, 0)
		editCodes.DoClick = function() 
			netstream.Start("EditVerdictCodes", textEntry:GetText())
		end
	end
end

vgui.Register("ixDatapadFunctionVerdictCodes", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 32)
	self.Paint = function(self, w, h) end
	
	local comTitleFrame = self:Add("EditablePanel")
	PLUGIN:CreateTitle(comTitleFrame, self, "communication codes")
	
	comCodesTitleSubframe = comTitleFrame:Add("EditablePanel")
	comCodesTitleSubframe:SetSize(130, 0)
	comCodesTitleSubframe:Dock(RIGHT)
	comCodesTitleSubframe.Paint = function(self, w, h) end
		
	local editCodes = comCodesTitleSubframe:Add("DButton")
	PLUGIN:CreateTitleFrameRightTextButton(editCodes, comCodesTitleSubframe, 48, "edit codes", RIGHT)
	
	local back = comCodesTitleSubframe:Add("DButton")	
	PLUGIN:CreateTitleFrameRightTextButton(back, comCodesTitleSubframe, 48, "back", LEFT)
	
	PLUGIN:DrawDividerLine(comCodesTitleSubframe, 2, 13, back:GetWide() + 6, 4)
	
	back.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/back.wav")
		PLUGIN.updates:SetVisible(true)
		PLUGIN.functions:SetVisible(true)
		self:SetVisible(false)
	end
	
	local comContentFrame = self:Add("EditablePanel")
	comContentFrame:SetSize(self:GetWide(), self:GetParent():GetTall())
	comContentFrame:Dock(TOP)
	comContentFrame:DockMargin(0, -2, 0, 0)
	comContentFrame.Paint = function(self, w, h) end
	
	local textEntry = vgui.Create("DTextEntry", comContentFrame)
	textEntry:SetSize(self:GetWide(), comContentFrame:GetTall())
	textEntry:SetMultiline(true)
	textEntry:SetValue(PLUGIN.comCode or "")
	textEntry:SetEnterAllowed(true)
	textEntry:SetVerticalScrollbarEnabled( true )
	textEntry:SetEditable(false)
	textEntry:RequestFocus()
	textEntry:SetTextColor( color )
	textEntry:SetCursorColor( color )
	textEntry.Paint = function(self, w, h)
		surface.SetDrawColor(40, 88, 115, 75)
		surface.DrawRect(0, 0, w, h)
		
		self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
	end
	
	editCodes.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/navigate2.wav")
		textEntry:SetEditable(true)
		editCodes:SetText(string.upper("save"))
		editCodes:SetContentAlignment(6)
		editCodes:Dock(NODOCK)
		editCodes:SetPos(8)
		comCodesTitleSubframe:SetSize(88, 0)
		editCodes.DoClick = function()
			netstream.Start("EditComCodes", textEntry:GetText())
		end
	end
end

vgui.Register("ixDatapadFunctionComCodes", PANEL, "EditablePanel")