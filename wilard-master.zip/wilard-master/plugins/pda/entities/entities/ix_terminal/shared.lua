
ENT.Type = "anim";
ENT.Author = "Thermadyle and Blt950";
ENT.PrintName = "Terminal";
ENT.Spawnable = true;
ENT.AdminSpawnable = true;
ENT.UsableInVehicle = true;
ENT.PhysgunDisabled = true;

function GetTerminalData(client, id)
	local file = {}
	
	local query = mysql:Select("ix_characters")
	query:Where("datafilecid", id)
	query:Limit(1)
	query:Callback(function(result)
		if (!istable(result)) then
			return
		end
		
		if not result[1] then
			return
		end
		
		if (!table.IsEmpty(file)) then
			table.Empty(file)
		end
		
		file = {
			genericdata = util.JSONToTable(result[1].genericdata or ""),
			datafilelogs = util.JSONToTable(result[1].datafilelogs or ""),
			datafileviolations = util.JSONToTable(result[1].datafileviolations or ""),
			datafilemedicalrecords = util.JSONToTable(result[1].datafilemedicalrecords or "")
		}
		
		timer.Simple(0.05, function()
			netstream.Start(client, "GetDataTerminal", file)
		end)
	end)
	query:Execute()
end