include("shared.lua")

local panel
local receiveTime
local urlOpened
local keys = { KEY_4, KEY_6, KEY_2, KEY_6 }
local validKeysCount = 1
local keyDown
local nextPress = CurTime()
local NextTime = 1
local showData = false
local selectedCID = ""
local file = {}

local function CreateHTML()
	if IsValid( frame ) then frame:Remove() end
	
	frame = vgui.Create( "DFrame" )
	frame:SetTitle( "The Terminal" )
	frame:SetSize( ScrW() - 256, ScrH() - 256 )
	frame:SetPos( 128, 128 )
	frame:MakePopup()
	frame:ShowCloseButton( true )
	
	local html = vgui.Create( "HTML", frame )
	html:SetSize( frame:GetWide() - 10, frame:GetTall() - 31 )
	html:SetPos( 5, 26 )
	html:OpenURL( "http://undeterminedgaming.nn.pe/terminal/" )
	
	frame.lblTitle.UpdateColours = function( label, skin )
		label:SetTextStyleColor( Color( 240, 240, 240 ) )
	end
end

local function ExitScreen()
	if IsValid( frame ) then 
		frame:Remove()
	end
	
	panel = nil
	receiveTime = nil
	keyDown = nil
	file = nil
	showData = nil
	validKeysCount = 1
end

netstream.Hook("openCIDWindow", function(entity, cidTable)
	surface.PlaySound("helix/ui/press.wav")
	
	local CIDpanel = vgui.Create("DFrame")
	CIDpanel:SetSize(300, 300)
	CIDpanel:MakePopup()
	CIDpanel:Center()
	CIDpanel:SetTitle("Which CID do you want to use?")
	CIDpanel.lblTitle.UpdateColours = function( label, skin )
		label:SetTextStyleColor( Color( 240, 240, 240 ) )
	end
		
	local DListView = CIDpanel:Add("DListView")
	DListView:Dock(TOP)
	DListView:SetTall(CIDpanel:GetTall() - 60)
	DListView:AddColumn("Name")
	DListView:AddColumn("ID")
	
	for k, v in pairs(cidTable) do
		DListView:AddLine(v.name, v.id)
	end
	
	local select = CIDpanel:Add("DButton")
	select:Dock(TOP)
	select:SetTall(30)
	select:SetText("Select")
	select.Paint = function(self, w, h)		
		surface.SetDrawColor(Color(30, 30, 30, 255))
		surface.DrawRect(0, 0, w, h)
	end
	
	DListView.OnRowSelected = function( lst, index, pnl )
		surface.PlaySound( "UI/buttonclickrelease.wav" )
		select.DoClick = function()
			selectedCID = pnl:GetColumnText( 2 )
			netstream.Start("StartTerminal", entity, selectedCID)
			CIDpanel:SetVisible(false)
		end
	end
end)

netstream.Hook("GetDataTerminal", function(table)
	file = table
end)

function ENT:Draw()
	
	self:DrawModel()
	
	local ang = self:GetAngles()
	local pos = self:GetPos() + ang:Up() * 18.5 + ang:Right() * 6.8 + ang:Forward() * 13
	ang:RotateAroundAxis(ang:Right(), -90)
	ang:RotateAroundAxis(ang:Up(), 90)
	
	cam.Start3D2D( pos, ang, 0.1 )
	
	local width, height = 163, 142
	
	surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
	surface.DrawRect( 0, 0, width, height )
	
	surface.SetMaterial(Material("effects/tvscreen_noise002a"))
	surface.DrawTexturedRect( 0, 0, width, height )
	
	surface.SetDrawColor( Color( 255, 255, 255, 16 ) )
	
	local alpha = 191 + 64 * math.sin( CurTime() * 4 )
	local deltaTime = CurTime() - ( receiveTime or 0 )
	
	surface.SetDrawColor( Color( 255, 0, 0, 120 ) )
	surface.DrawRect( 0, 0, width, 25 )
	
	if !receiveTime or deltaTime < 0.5 then
		draw.SimpleText( "The Terminal", "panel_font", width / 2, 6, Color( 255, 255, 255, alpha ), TEXT_ALIGN_CENTER )
		
		surface.SetDrawColor( Color( 80, 80, 80, 120 ) )
		surface.DrawRect( 0, 71 + math.sin( CurTime() * 3 ) * height / 3.1, width, 25 )
		draw.SimpleText( "Waiting for CID", "panel_font", width / 2, 71 + math.sin( CurTime() * 3 ) * height / 3.1 + 11, Color( 255, 255, 180, alpha ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		
	elseif receiveTime then
		surface.SetDrawColor( Color( 80, 80, 80, 120 ) )
		surface.DrawRect( 0, height - 25, width, 25 )
		draw.SimpleText( string.format( "Initializing system (%s)", string.rep( ".", math.Clamp( math.floor( ( deltaTime - 0.5 ) * 3 ), 0, 6 ) ) ), "panel_font", width / 2, 12, Color( 255, 255, 255, alpha ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER  )
		draw.SimpleText( "Press E to exit!", "panel_font", width / 2, height - 13, Color( 255, 255, 255, alpha ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		
		if deltaTime > 3 and showData != true then
			draw.SimpleText( "Press 'ENTER' for The Terminal", "panel_font", width / 2 - 1, height / 2 - 8, Color( 255, 255, 180, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER  )
			draw.SimpleText( "Press 'SPACE' for data", "panel_font", width / 2 - 1, height / 2 + 8, Color( 255, 255, 180, alpha ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
	end	
	
	if showData == true then
		draw.SimpleText( "Total Credits:"..file.genericdata.socialCredits or "N/A", "panel_font", width / 2 - 1, height / 2, Color( 255, 255, 180, alpha ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	cam.End3D2D()	
end

local function PanelThink()
	if receiveTime then
		local deltaTime = CurTime() - receiveTime
		if deltaTime > 2 and input.IsKeyDown( KEY_E ) then
			ExitScreen()
			netstream.Start("ExitComputer", panel)
		else
			local keyEnum = keys[ validKeysCount ]
			if keyEnum then
				
				if input.IsKeyDown( keyEnum ) then
					
					if !keyDown then
						keyDown = true
						validKeysCount = validKeysCount + 1
					end
					
				elseif keyDown then
					keyDown = false
				end
			end

			if nextPress < CurTime() and (input.IsKeyDown( KEY_ENTER ) or input.IsKeyDown( KEY_SPACE )) then
				if deltaTime > 3 and input.IsKeyDown( KEY_ENTER ) then
					CreateHTML()
					surface.PlaySound( "ambient/machines/keyboard7_clicks_enter.wav" )
					
					urlOpened = true
					
				elseif deltaTime > 3 and input.IsKeyDown( KEY_SPACE ) then
					showData = true
					surface.PlaySound( "ambient/machines/keyboard7_clicks_enter.wav" )
						
					urlOpened = true
				end
				
			nextPress = CurTime()+3
			end
		end
	end
	
	if !LocalPlayer():Alive() and IsValid( panel ) then
		ExitScreen()
	end
end
hook.Add( "Think", "wp_think", PanelThink )

netstream.Hook( "wp_screen", function(entity, bool)
	local inUse = bool
	if inUse then
		panel = entity
		local ang = panel:GetAngles()
		
		viewPos = nil
		receiveTime = CurTime()
		
		surface.PlaySound( "ambient/machines/combine_terminal_idle4.wav" )
	else
		ExitScreen()
	end
end)