include("shared.lua");

AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
util.AddNetworkString( "TypeSound" )
	
ENT.Type		= "anim"
ENT.Base		= "base_anim"
ENT.Author		= "Fruity"
ENT.CIDTable	= {}

AddCSLuaFile()

function ENT:Initialize()

	self:SetModel( "models/props_combine/combine_smallmonitor001.mdl" )
	
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetSkin(1)
	self.PhysgunDisabled = false
	
	self:SetUseType( USE_TOGGLE )
end

function ENT:StartTerminal( client, cid )
	if self.inUse then
		if self.user then
			if self.user != client then
				client:NotifyLocalized("This terminal is already in use!")
				return false
			end
		end
	end

	GetTerminalData(client, cid)
	
	if !self.nextComputerUse or self.nextComputerUse < CurTime() then
		self.inUse = !self.inUse
		self.user = client
		client:DrawViewModel( !self.inUse )
		client:SetMoveType( ( self.inUse and MOVETYPE_NONE ) or MOVETYPE_WALK )
		self:EmitSound( "plats/hall_elev_door.wav" )
		
		netstream.Start(client, "wp_screen", self, self.inUse)
		
		self.nextComputerUse = CurTime() + 2
	end	
end	

function ENT:GetCIDInformation(client)
	if !table.IsEmpty(self.CIDTable) then
		table.Empty(self.CIDTable)
	end
	
	for k, v in pairs(client:GetCharacter():GetInventory():GetItems()) do
		if v.name == "Citizen ID" and v:GetData("id") != nil then
			table.insert(self.CIDTable, {id = v:GetData("id"), name = v:GetData("name")})
		end
	end
	
	if table.IsEmpty(self.CIDTable) then
		return
	end
	
	if (#self.CIDTable > 1) then
		netstream.Start(client, "openCIDWindow", self, self.CIDTable)
		return
	end
	
	if #self.CIDTable == 1 then
		self:StartTerminal( client, self.CIDTable[1].id )
		return
	end
	
	client:NotifyLocalized("You don't have a Citizen ID!")
end

netstream.Hook("ExitComputer", function(client, self)
	if IsValid( self ) then
		self.inUse = false
		self.user = nil
		client:DrawViewModel( true )
		client:SetMoveType( MOVETYPE_WALK )
		self.Entity:EmitSound( "physics/cardboard/cardboard_box_impact_soft7.wav" )
		
		netstream.Start(client, "wp_screen", self, false)
		
		self.nextComputerUse = CurTime() + 2
	end
end)

function ENT:Use( client )	
	if self.nextComputerUse then
		if self.nextComputerUse > CurTime() then
			return
		end
	end
	
	self:GetCIDInformation(client)
end

netstream.Hook("StartTerminal", function(client, entity, cid)
	entity:StartTerminal( client, cid )
end)