include("shared.lua")

surface.CreateFont( "panel_font", {
	
	[ "font" ] = "Verdana",
	[ "size" ] = 12,
	[ "weight" ] = 128,
	[ "antialias" ] = true
	
} )

surface.CreateFont( "subpanel_font", {
	
	[ "font" ] = "Verdana",
	[ "size" ] = 56,
	[ "blursize" ] = 2,
	[ "weight" ] = 128,
	[ "antialias" ] = true
	
} )

surface.CreateFont( "row_font", {
	
	[ "font" ] = "Verdana",
	[ "size" ] = 42,
	[ "blursize" ] = 2,
	[ "weight" ] = 128,
	[ "antialias" ] = true
	
} )

local panel
local receiveTime
local keys = { KEY_4, KEY_6, KEY_2, KEY_6 }
local validKeysCount = 1
local keyDown
local nextPress = CurTime()
local NextTime = 1
local mainScreen = false
local locked = false
local password = password
local notes = notes
local setNotesActive = false
local setPasswordActive = false
local editingNameEntry = false
local viewRecords = false
local editEntry = false
local editingEditEntry = false
local medicalInformationActive

local function ExitScreen()	
	panel = nil
	receiveTime = nil
	keyDown = nil
	setNotesActive = false
	setPasswordActive = false
	locked = false
	mainScreen = false
	editingNameEntry = false
	viewRecords = false
	medicalInformationActive = false
	editEntry = false
	editingEditEntry = false
	validKeysCount = 1
end

function ENT:Draw()
	
	self:DrawModel()
	
	local ang = self:GetAngles()
	local pos = self:GetPos() + ang:Up() * 12 + ang:Right() * 10 + ang:Forward() * 11.75
	ang:RotateAroundAxis(ang:Right(), -85.6)
	ang:RotateAroundAxis(ang:Up(), 90)
	
	cam.Start3D2D( pos, ang, 0.1 )
	
	local width, height = 200, 170
	
	surface.SetDrawColor( Color( 16, 16, 16, 240 ) )
	surface.DrawRect( 0, 0, width, height )
	
	surface.SetDrawColor( Color( 255, 255, 255, 16 ) )
	surface.DrawRect( 10, height / 2 + math.sin( CurTime() * 4 ) * height / 2.5, width - 22, 1 )
	
	local alpha = 191 + 64 * math.sin( CurTime() * 4 )
	local deltaTime = CurTime() - ( receiveTime or 0 )
	
	if not receiveTime or deltaTime < 0.5 then
		draw.SimpleText( "Medical Computer", "panel_font", width / 2, 25, Color( 255, 255, 255, alpha ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Waiting for user", "panel_font", width / 2, height - 35, Color( 255, 255, 180, alpha ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		
	elseif receiveTime then
		draw.SimpleText( string.format( "Initializing system (%s)", string.rep( ".", math.Clamp( math.floor( ( deltaTime - 0.5 ) * 3 ), 0, 6 ) ) ), "panel_font", 15, 15, Color( 255, 255, 255, alpha ) )
		draw.SimpleText( "Press E to exit!", "panel_font", 15, height - 35, Color( 255, 255, 255, alpha ) )
		
		if deltaTime > 3 then
			if locked == true and self:GetNWString("password") then
				surface.SetDrawColor(0, 0, 0, 40)
				draw.SimpleText( "Password:", "panel_font", 25, 33, Color( 255, 255, 180, alpha ) )
				surface.DrawRect(16, 30, width - 32, 20)
			end
			
			if mainScreen == true then
				surface.SetDrawColor(0, 0, 0, 40)
				draw.SimpleText( "View Medical Information", "panel_font", 25, 33, Color( 255, 255, 180, alpha ) )
				surface.DrawRect(16, 30, width - 32, 20)
				
				draw.SimpleText( "View Notes", "panel_font", 25, 53, Color( 255, 255, 180, alpha ) )
				surface.SetDrawColor(0, 0, 0, 80)
				surface.DrawRect(16, 50, width - 32, 20)
				
				draw.SimpleText( "Set Password", "panel_font", 25, 73, Color( 255, 255, 180, alpha ) )
				surface.SetDrawColor(0, 0, 0, 40)
				surface.DrawRect(16, 70, width - 32, 20)
				
				surface.SetDrawColor(0, 0, 0, 80)
				surface.DrawRect(16, 90, width - 32, 20)
				
				surface.SetDrawColor(0, 0, 0, 40)
				surface.DrawRect(16, 110, width - 32, 20)
			end
			
			if medicalInformationActive == true then
				surface.SetDrawColor(0, 0, 0, 40)
				draw.SimpleText( "Enter Name:", "panel_font", 25, 33, Color( 255, 255, 180, alpha ) )
				surface.DrawRect(16, 30, width - 32, 20)
				
				draw.SimpleText( "Back", "panel_font", 160, height - 35, Color( 255, 255, 255, alpha ) )
			end
			
			if setPasswordActive == true then
				surface.SetDrawColor(0, 0, 0, 40)
				draw.SimpleText( "Set Password:", "panel_font", 25, 33, Color( 255, 255, 180, alpha ) )
				surface.DrawRect(16, 30, width - 32, 20)
				
				draw.SimpleText( "Back", "panel_font", 160, height - 35, Color( 255, 255, 255, alpha ) )
			end
			
			if viewRecords == true then
				draw.SimpleText( "Add", "panel_font", 165, 15, Color( 255, 255, 255, alpha ) )
				draw.SimpleText( "Back", "panel_font", 160, height - 35, Color( 255, 255, 255, alpha ) )
			end
			
			if editEntry == true then
				draw.SimpleText( "Save", "panel_font", 160, 15, Color( 255, 255, 255, alpha ) )
				draw.SimpleText( "Back", "panel_font", 160, height - 35, Color( 255, 255, 255, alpha ) )
			end
			
			if setNotesActive == true then
				draw.SimpleText( "Save", "panel_font", 160, 15, Color( 255, 255, 255, alpha ) )
				draw.SimpleText( "Back", "panel_font", 160, height - 35, Color( 255, 255, 255, alpha ) )
			end
		end	
	end
	
	cam.End3D2D()	
end

local PANEL = {}

function PANEL:Init()
	self:SetSize(950, 750)
	self:SetPos(ScrW() * 0.5 - self:GetWide() * 0.5 + 30, ScrH() * 0.5 - self:GetTall() * 0.5 - 30)
	self.Paint = function(self, w, h) end
	self:MakePopup()
	
	self.enterPassword = self:Add("DTextEntry")
	self.enterPassword:SetPos(400, 118)
	self.enterPassword:SetFont("subpanel_font")
	self.enterPassword:SetSize(430, 90)
	self.enterPassword:SetMultiline(false)
	self.enterPassword:SetValue("Password here")
	self.enterPassword:RequestFocus()
	self.enterPassword:SetVerticalScrollbarEnabled( false )
	self.enterPassword:SetHighlightColor( Color(255, 255, 180, 40) )
	self.enterPassword.Paint = function(self, w, h) 						
		self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
	end
	
	self.enterPassword.OnKeyCode = function(self)
		if NextTime < CurTime() then
			net.Start( "TypeSound" )
			net.SendToServer()
			NextTime = CurTime() + 0.2
		end
	end
	
	self.enterPassword.OnEnter = function()
		if self.enterPassword:GetText() == password then
			editingNameEntry = false
			self:SetVisible(false)
			locked = false
			medicalPanel = vgui.Create("MedicalTerminal")
			surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
			mainScreen = true
		else
			surface.PlaySound("buttons/button2.wav")
		end
	end
end

function PANEL:Think()
	if IsValid(self.enterPassword) then
		local alpha = 191 + 64 * math.sin( CurTime() * 4 )
		self.enterPassword:SetTextColor( Color(255, 255, 180, alpha) )
		self.enterPassword:SetCursorColor( Color(255, 255, 180, alpha) )
		
		if self.enterPassword:IsEditing() then
			editingNameEntry = true
		else
			editingNameEntry = false
		end
	end
end

vgui.Register("LockedScreen", PANEL, "EditablePanel")

local PANEL = {}

function PANEL:Init()
	local alpha = 191 + 64 * math.sin( CurTime() * 4 )
	
	self:SetSize(950, 750)
	self:SetPos(ScrW() * 0.5 - self:GetWide() * 0.5 + 30, ScrH() * 0.5 - self:GetTall() * 0.5 - 30)
	self.Paint = function(self, w, h) end
	self:MakePopup()
		
	self.medicalInfoButton = self:Add("DButton")
	self.medicalInfoButton:Dock(TOP)
	self.medicalInfoButton:SetFont("subpanel_font")
	self.medicalInfoButton:SetText("")
	self.medicalInfoButton:SizeToContents()
	self.medicalInfoButton:SetTall(100)
	self.medicalInfoButton:DockMargin(45, 115, 30, 0)
	self.medicalInfoButton.Paint = function(self, w, h) end
	self.medicalInfoButton.DoClick = function()
		self.viewNotes:SetVisible(false)
		self.setPassword:SetVisible(false)
		surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
		self.medicalInfoButton:SetVisible(false)
		mainScreen = false
		medicalInformationActive = true
		
		self.nameEntry = self:Add("DTextEntry")
		self.nameEntry:SetPos(450, 118)
		self.nameEntry:SetFont("subpanel_font")
		self.nameEntry:SetSize(450, 90)
		self.nameEntry:SetMultiline(false)
		self.nameEntry:SetValue("John Doe")
		self.nameEntry:RequestFocus()
		self.nameEntry:SetVerticalScrollbarEnabled( false )
		self.nameEntry:SetHighlightColor( Color(255, 255, 180, 40) )
		self.nameEntry.Paint = function(self, w, h) 						
			self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
		end
		
		self.nameEntry.OnKeyCode = function(self)
			if NextTime < CurTime() then
				net.Start( "TypeSound" )
				net.SendToServer()
				NextTime = CurTime() + 0.2
			end
		end
		
		self.nameEntry.OnEnter = function()
			netstream.Start("searchMedicalFile", self.nameEntry:GetText())
		end
		
		self.medScreenBack = self:Add("DButton")
		self.medScreenBack:SetSize(200, 100)
		self.medScreenBack:SetText("")
		self.medScreenBack:SetPos(self:GetWide() - self.medScreenBack:GetWide() - 10, self:GetTall() - self.medScreenBack:GetTall() - 10)
		self.medScreenBack.Paint = function(self, w, h) end
		self.medScreenBack.DoClick = function()
			surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
			self.nameEntry:SetVisible(false)
			self.medScreenBack:SetVisible(false)
			self.medicalInfoButton:SetVisible(true)
			self.viewNotes:SetVisible(true)
			self.setPassword:SetVisible(true)
			mainScreen = true
			medicalInformationActive = false
		end
	end
	
	self.viewNotes = self:Add("DButton")
	self.viewNotes:Dock(TOP)
	self.viewNotes:SetFont("subpanel_font")
	self.viewNotes:SetText("")
	self.viewNotes:SizeToContents()
	self.viewNotes:SetTall(100)
	self.viewNotes:DockMargin(45, 5, 30, 0)
	self.viewNotes.Paint = function(self, w, h) end
	self.viewNotes.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
		self.medicalInfoButton:SetVisible(false)
		self.setPassword:SetVisible(false)
		self.viewNotes:SetVisible(false)
		mainScreen = false
		setNotesActive = true
		
		self.notesEntry = self:Add("DTextEntry")
		self.notesEntry:SetPos(60, 120)
		self.notesEntry:SetFont("subpanel_font")
		self.notesEntry:SetSize(850, 500)
		self.notesEntry:SetMultiline(true)
		
		notes = panel:GetNWString("notes")
		
		self.notesEntry:SetValue(notes or "")
		self.notesEntry:RequestFocus()
		self.notesEntry:SetVerticalScrollbarEnabled( true )
		self.notesEntry:SetHighlightColor( Color(255, 255, 180, 40) )
		self.notesEntry.Paint = function(self, w, h) 						
			self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
		end
		
		self.notesEntry.OnKeyCode = function(self)
			if NextTime < CurTime() then
				net.Start( "TypeSound" )
				net.SendToServer()
				NextTime = CurTime() + 0.2
			end
		end
		
		local save = self:Add("DButton")
		save:SetSize(200, 100)
		save:SetText("")
		save:SetPos(self:GetWide() - save:GetWide() - 10, 10)
		save.Paint = function(self, w, h) end
		
		save.DoClick = function()
			surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
			netstream.Start("SaveNotes", self.notesEntry:GetText(), panel)
		end
		
		self.notesBack = self:Add("DButton")
		self.notesBack:SetSize(200, 100)
		self.notesBack:SetText("")
		self.notesBack:SetPos(self:GetWide() - self.notesBack:GetWide() - 10, self:GetTall() - self.notesBack:GetTall() - 10)
		self.notesBack.Paint = function(self, w, h) end
		self.notesBack.DoClick = function()
			self.notesBack:SetVisible(false)
			self.notesEntry:SetVisible(false)
			surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
			self.medicalInfoButton:SetVisible(true)
			self.setPassword:SetVisible(true)
			self.viewNotes:SetVisible(true)
			mainScreen = true
			setNotesActive = false
		end
	end
	
	self.setPassword = self:Add("DButton")
	self.setPassword:Dock(TOP)
	self.setPassword:SetFont("subpanel_font")
	self.setPassword:SetText("")
	self.setPassword:SizeToContents()
	self.setPassword:SetTall(100)
	self.setPassword:DockMargin(45, 10, 30, 0)
	self.setPassword.Paint = function(self, w, h) end
	self.setPassword.DoClick = function()
		surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
		self.medicalInfoButton:SetVisible(false)
		self.setPassword:SetVisible(false)
		self.viewNotes:SetVisible(false)
		mainScreen = false
		setPasswordActive = true
		
		self.passwordEntry = self:Add("DTextEntry")
		self.passwordEntry:SetPos(480, 118)
		self.passwordEntry:SetFont("subpanel_font")
		self.passwordEntry:SetSize(430, 90)
		self.passwordEntry:SetMultiline(false)
		self.passwordEntry:SetValue("Password here")
		self.passwordEntry:RequestFocus()
		self.passwordEntry:SetVerticalScrollbarEnabled( false )
		self.passwordEntry:SetHighlightColor( Color(255, 255, 180, 40) )
		self.passwordEntry.Paint = function(self, w, h) 						
			self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
		end
		
		self.passwordEntry.OnKeyCode = function(self)
			if NextTime < CurTime() then
				net.Start( "TypeSound" )
				net.SendToServer()
				NextTime = CurTime() + 0.2
			end
		end
		
		self.passwordEntry.OnEnter = function()
			netstream.Start("SetPassword", self.passwordEntry:GetText(), panel)
			self.passwordEntry:SetVisible(false)
			surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
			self.medicalInfoButton:SetVisible(true)
			self.setPassword:SetVisible(true)
			self.viewNotes:SetVisible(true)
			mainScreen = true
			setPasswordActive = false
		end
		
		self.passwordBack = self:Add("DButton")
		self.passwordBack:SetSize(200, 100)
		self.passwordBack:SetText("")
		self.passwordBack:SetPos(self:GetWide() - self.passwordBack:GetWide() - 10, self:GetTall() - self.passwordBack:GetTall() - 10)
		self.passwordBack.Paint = function(self, w, h) end
		self.passwordBack.DoClick = function()
			self.passwordBack:SetVisible(false)
			self.passwordEntry:SetVisible(false)
			surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
			self.medicalInfoButton:SetVisible(true)
			self.setPassword:SetVisible(true)
			self.viewNotes:SetVisible(true)
			mainScreen = true
			setPasswordActive = false
		end
	end
end

function PANEL:Think()
	if IsValid(self.nameEntry) then
		local alpha = 191 + 64 * math.sin( CurTime() * 4 )
		self.nameEntry:SetTextColor( Color(255, 255, 180, alpha) )
		self.nameEntry:SetCursorColor( Color(255, 255, 180, alpha) )
		
		if self.nameEntry:IsEditing() then
			editingNameEntry = true
		else
			editingNameEntry = false
		end
	end
	
	if IsValid(self.passwordEntry) then
		local alpha = 191 + 64 * math.sin( CurTime() * 4 )
		self.passwordEntry:SetTextColor( Color(255, 255, 180, alpha) )
		self.passwordEntry:SetCursorColor( Color(255, 255, 180, alpha) )
		
		if self.passwordEntry:IsEditing() then
			editingNameEntry = true
		else
			editingNameEntry = false
		end
	end
	
	if IsValid(self.notesEntry) then
		local alpha = 191 + 64 * math.sin( CurTime() * 4 )
		self.notesEntry:SetTextColor( Color(255, 255, 180, alpha) )
		self.notesEntry:SetCursorColor( Color(255, 255, 180, alpha) )
		
		if self.notesEntry:IsEditing() then
			editingNameEntry = true
		else
			editingNameEntry = false
		end
	end
end

vgui.Register("MedicalTerminal", PANEL, "EditablePanel")

netstream.Hook("createMedicalRecords", function(table, searchname)
	medicalInformationActive = false
	
	viewRecords = true
	
	if IsValid(medicalPanel) then
		for k, v in pairs(medicalPanel:GetChildren()) do
			v:SetVisible(false)
		end
		
		local rowPanel = medicalPanel:Add("DScrollPanel")
		rowPanel:SetSize(medicalPanel:GetWide() - 40, medicalPanel:GetTall() - 250)
		rowPanel:SetPos( 20, 125 )
		rowPanel.Paint = function(self, w, h) end
		
		local sbar = rowPanel:GetVBar()
		function sbar.btnGrip:Paint( w, h )
			surface.SetDrawColor(0, 0, 0, 30)
			surface.DrawRect(0, 0, w, h)
		end
		
		for k, v in SortedPairs(table, true) do
			local entryPanel = rowPanel:Add("DPanel")
			entryPanel:Dock(TOP)
			entryPanel:SetTall(100)
			entryPanel.Paint = function(self, w, h) 
				if k % 2 == 0 then
					surface.SetDrawColor(0, 0, 0, 75)
					surface.DrawRect(20, 0, w - 20, h)
				end
			end
			
			local top = entryPanel:Add("DPanel")
			top:Dock(TOP)
			top:SetTall(50)
			top.Paint = function(self, w, h) end
			
			local poster = top:Add("DLabel")
			poster:Dock(LEFT)
			poster:SetFont("row_font")
			poster:SetText(table[k].poster)
			poster:SetTextColor(Color(255, 255, 180, 255))
			poster:SizeToContents()
			poster:DockMargin(40, 0, 0, 0)
			
			local date = top:Add("DLabel")
			date:Dock(RIGHT)
			date:SetFont("row_font")
			date:SetText(table[k].date)
			date:SetTextColor(Color(255, 255, 180, 255))
			date:SizeToContents()
			date:DockMargin(0, 0, 30, 0)
			
			local bottom = entryPanel:Add("DPanel")
			bottom:Dock(TOP)
			bottom:SetTall(50)
			bottom.Paint = function(self, w, h) end
			
			local text = bottom:Add("DLabel")
			text:Dock(LEFT)
			text:SetFont("row_font")
			if string.len( table[k].text ) > 40 then
				text:SetText(string.upper(string.sub(table[k].text, 1, 39) .."..."))
			else
				text:SetText(table[k].text)
			end
			text:SizeToContents()
			text:DockMargin(40, 0, 0, 0)
		end
		
		local edit = medicalPanel:Add("DButton")
		edit:SetSize(200, 100)
		edit:SetText("")
		edit:SetPos(medicalPanel:GetWide() - edit:GetWide() - 10, 10)
		edit.Paint = function(self, w, h) end
		
		local back = medicalPanel:Add("DButton")
		back:SetSize(200, 100)
		back:SetText("")
		back:SetPos(medicalPanel:GetWide() - back:GetWide() - 10, medicalPanel:GetTall() - back:GetTall() - 10)
		back.Paint = function(self, w, h) end
		back.DoClick = function()
			viewRecords = false
			medicalPanel:SetVisible(false)
			medicalPanel = vgui.Create("MedicalTerminal")
			medicalPanel.medicalInfoButton.DoClick()
		end
		
		edit.DoClick = function()
			surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
			editEntry = true
			back:SetVisible(false)
			edit:SetVisible(false)
			rowPanel:SetVisible(false)
			viewRecords = false
			
			editTextEntry = medicalPanel:Add("DTextEntry")
			editTextEntry:SetPos(40, 118)
			editTextEntry:SetFont("subpanel_font")
			editTextEntry:SetSize(medicalPanel:GetWide() - 50, 90)
			editTextEntry:SetMultiline(false)
			editTextEntry:SetValue("Text Here")
			editTextEntry:RequestFocus()
			editTextEntry:SetVerticalScrollbarEnabled( false )
			editTextEntry:SetTextColor(Color(255, 255, 180, 255))
			editTextEntry:SetCursorColor(Color(255, 255, 180, 255))
			editTextEntry.MaxChars = 40
			editTextEntry:SetHighlightColor( Color(255, 255, 180, 40) )
			editTextEntry.Paint = function(self, w, h) 						
				self:DrawTextEntryText( self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor() )
			end
			
			editTextEntry.OnKeyCode = function(self)
				if NextTime < CurTime() then
					net.Start( "TypeSound" )
					net.SendToServer()
					NextTime = CurTime() + 0.2
				end
			end
			
			editTextEntry.OnTextChanged = function(self)
				local txt = self:GetValue()
				local amt = string.len(txt)
				if amt > self.MaxChars then
					if self.OldText then
						self:SetText(self.OldText)
						self:SetValue(self.OldText)
					end
				else
					self.OldText = txt
				end
			end
			
			editTextEntry.OnEnter = function()	
				surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
				netstream.Start("MedicalComputerAddRecord", searchname, LocalPlayer():Name(), editTextEntry:GetText())
				timer.Simple(0.05, function()
					editEntry = false
					netstream.Start("searchMedicalFile", searchname)
				end)
			end
			
			local function IsEditingEditText()
				if IsValid(editTextEntry) then
					if editTextEntry:IsEditing() then
						editingEditEntry = true
					else
						editingEditEntry = false
					end
				end
			end
			
			hook.Add( "Think", "editentry_Think", IsEditingEditText )
			
			local save = medicalPanel:Add("DButton")
			save:SetSize(200, 100)
			save:SetText("")
			save:SetPos(medicalPanel:GetWide() - save:GetWide() - 10, 10)
			save.Paint = function(self, w, h) end
			
			save.DoClick = function()
				surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
				netstream.Start("MedicalComputerAddRecord", searchname, LocalPlayer():Name(), editTextEntry:GetText())
				timer.Simple(0.05, function()
					editEntry = false
					netstream.Start("searchMedicalFile", searchname)
				end)
			end
		
			local editBack = medicalPanel:Add("DButton")
			editBack:SetSize(200, 100)
			editBack:SetText("")
			editBack:SetPos(medicalPanel:GetWide() - editBack:GetWide() - 10, medicalPanel:GetTall() - editBack:GetTall() - 10)
			editBack.Paint = function(self, w, h) end
			editBack.DoClick = function()
				save:SetVisible(false)
				editTextEntry:SetVisible(false)
				editEntry = false
				surface.PlaySound("willardnetworks/datapad/mouseclick.wav")
				back:SetVisible(true)
				edit:SetVisible(true)
				rowPanel:SetVisible(true)
				viewRecords = true
				editBack:SetVisible(false)
			end
		end
	end
end)

local viewPos
local wantedViewPos
local function View( pl, pos, ang )
	
	if not IsValid( panel ) then return end
	
	if not wantedViewPos then return end
	if not viewPos then viewPos  = pos end
	
	viewPos = viewPos + ( wantedViewPos - viewPos ) * FrameTime() * 6
	
	local ang = panel:GetAngles()
	local view = {
	
		[ "origin" ] = viewPos,
		[ "angles" ] = ( ( panel:GetPos() + ang:Up() * 2 + ang:Right() * 0.65 + ang:Forward() ) - viewPos ):Angle()
	
	}
	
	return view
	
end
hook.Add( "CalcView", "wp_view", View )

local function PanelThink()
	if receiveTime then
	
		local deltaTime = CurTime() - receiveTime
		if (deltaTime > 2 and input.IsKeyDown( KEY_E )) and (editingNameEntry == false and editingEditEntry == false) then
			if IsValid ( FrameDP ) then
				return false
			end
			ExitScreen()
			RunConsoleCommand( "wp_medicaleject" )
		else
		
			local keyEnum = keys[ validKeysCount ]
			if keyEnum then
				
				if input.IsKeyDown( keyEnum ) then
					
					if not keyDown then
						keyDown = true
						validKeysCount = validKeysCount + 1
					end
					
				elseif keyDown then
					keyDown = false
				end
			end

			if nextPress < CurTime() and (input.IsKeyDown( KEY_ENTER ) or input.IsKeyDown( KEY_SPACE ) or input.IsKeyDown ( KEY_M )) then
			nextPress = CurTime()+3
			end
			
		end
	else
		if IsValid(medicalPanel) then
			medicalPanel:SetVisible(false)
		end
		
		if IsValid(passPanel) then
			passPanel:SetVisible(false)
		end
	end
	
	if not LocalPlayer():Alive() and IsValid( panel ) then
		ExitScreen()
	end
	
end
hook.Add( "Think", "wp_medcomputerThink", PanelThink )

netstream.Hook( "wp_medscreen", function( entity, inUse )
	panel = entity
	
	if inUse then
		local ang = panel:GetAngles()
		
		wantedViewPos = panel:GetPos() + ang:Up() * 5 + ang:Right() + ang:Forward() * 24
		viewPos = nil
		receiveTime = CurTime()
		
		if IsValid(medicalPanel) then
			medicalPanel:Remove()
		end
		
		if IsValid(passPanel) then
			passPanel:Remove()
		end
		
		if panel:GetNWString("password") != "" and panel:GetNWString("password") != nil then
			locked = true
			password = panel:GetNWString("password")
			passPanel = vgui.Create("LockedScreen")
			passPanel:SetVisible(false)
			
			timer.Create("passPanel", 3, 1, function()
				passPanel:SetVisible(true)
			end)
		else
			mainScreen = true
			medicalPanel = vgui.Create("MedicalTerminal")
			medicalPanel:SetVisible(false)
			
			timer.Create("MedicalPanel", 3, 1, function()
				medicalPanel:SetVisible(true)
			end)
		end
		
		notes = panel:GetNWString("notes")
		
		surface.PlaySound( "ambient/machines/combine_terminal_idle4.wav" )
	else
		if IsValid(medicalPanel) then
			medicalPanel:Remove()
		end
		
		if timer.Exists( "MedicalPanel" ) then
			timer.Remove( "MedicalPanel")
		end
		
		ExitScreen()
		RunConsoleCommand( "medcomputer_eject" )
	end
end)
