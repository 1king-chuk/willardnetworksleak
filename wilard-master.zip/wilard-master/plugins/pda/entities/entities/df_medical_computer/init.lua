include("shared.lua")

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
util.AddNetworkString( "TypeSound" )
	
ENT.Type		= "anim"
ENT.Base		= "base_anim"
ENT.Author		= "Fruity"

AddCSLuaFile()

function ENT:Initialize()

	self:SetModel( "models/props_lab/monitor01a.mdl" )
	
	self:PhysicsInit( SOLID_VPHYSICS )      -- Make us work with physics,
	self:SetMoveType( MOVETYPE_VPHYSICS )   -- after all, gmod is a physics
	self:SetSolid( SOLID_VPHYSICS )         -- Toolbox
	
	self:GetPhysicsObject():EnableMotion(true)
 
	self:SetUseType( USE_TOGGLE )
	
    local phys = self:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end
	
	local time = 0
	
	timer.Simple(1, function()
		time = 8
	end)
	
	timer.Create("AmbientSound", time, 0, function()
		self:EmitSound( "willardnetworks/datapad/computerloop.wav", 75, 100, 0.15)
	end)
end

function ENT:Use( pl )
	if not pl._nextComputerUse or pl._nextComputerUse < CurTime() then
		pl._inWebsitePanel = not pl._inWebsitePanel
		pl:DrawViewModel( not pl._inWebsitePanel )
		pl:SetMoveType( ( pl._inWebsitePanel and MOVETYPE_NONE ) or MOVETYPE_WALK )
		self:EmitSound( "buttons/button1.wav" )
		
		netstream.Start(pl, "wp_medscreen", self, true )
		
		pl._computer = self
		pl._nextComputerUse = CurTime() + 2
	end
	
	local function ExitComputer( pl )
		if IsValid( pl._computer ) then
			pl._inWebsitePanel = false
			pl:DrawViewModel( true )
			pl:SetMoveType( MOVETYPE_WALK )
			self.Entity:EmitSound( "buttons/button6.wav" )
			
			netstream.Start(pl, "wp_medscreen", self, false )
			
			pl._computer = nil
			pl._nextComputerUse = CurTime() + 2
		end
	end
	
	concommand.Add( "wp_medicaleject", ExitComputer )			
end
		
net.Receive( "TypeSound", function( length, client )
	client:EmitSound(string.format( "ambient/machines/keyboard%d_clicks.wav", math.random( 6 ) ),75)
end )

function ENT:OnRemove()
	if timer.Exists("AmbientSound") then
		timer.Remove("AmbientSound")
	end
end

netstream.Hook("searchMedicalFile", function(client, searchname)
	local query = mysql:Select("ix_characters")
	query:WhereLike("name", searchname)
	query:Limit(1)
	query:Callback(function(result)
		if (!istable(result)) then
			return
		end
		
		if not result[1] then
			return
		end
				
		medicalrecords = util.JSONToTable(result[1].datafilemedicalrecords or "")
		
		timer.Simple(0.05, function()
			netstream.Start(client, "createMedicalRecords", medicalrecords, searchname)
		end)
	end)
	query:Execute()
end)

netstream.Hook("MedicalComputerAddRecord", function(client, name, posterName, text)
	medicalrecords[#medicalrecords + 1] = {
		text = text,
		date = os.date("%d/%m/%Y"),
		poster = posterName
	}
	
	local queryObj = mysql:Update("ix_characters")
		queryObj:WhereLike("name", name)
		queryObj:Update("datafilemedicalrecords", util.TableToJSON(medicalrecords))
	queryObj:Execute()
end)

netstream.Hook("SetPassword", function(client, password, entity)
	entity:SetNWString( "password", password )
end)

netstream.Hook("SaveNotes", function(client, notes, entity)
	entity:SetNWString( "notes", notes )
end)