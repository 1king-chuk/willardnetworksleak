
ENT.Type = "anim";
ENT.Author = "Fruity";
ENT.PrintName = "Medical Computer";
ENT.Spawnable = true;
ENT.AdminSpawnable = true;
ENT.UsableInVehicle = true;