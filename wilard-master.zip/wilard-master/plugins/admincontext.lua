
local PLUGIN = PLUGIN or {}

PLUGIN.name = "Administration Context"
PLUGIN.author = "Gary Tate"
PLUGIN.description = "Adds several context options on players."

properties.Add("ixViewPlayerProperty", {
	MenuLabel = "#View Player",
	Order = 0,
	MenuIcon = "icon16/user.png",
	Format = "%s | %s\nHealth: %s\nArmor: %s",

	Filter = function(self, entity, client)
		return client:IsAdmin() and entity:IsPlayer()
	end,

	Action = function(self, entity)
		self:MsgStart()
			net.WriteEntity(entity)
		self:MsgEnd()
	end,

	Receive = function(self, length, client)
		if (client:IsAdmin()) then
			local entity = net.ReadEntity()
			client:NotifyLocalized(string.format(self.Format, entity:Nick(), entity:SteamID(), entity:Health(), entity:Armor()))
		end
	end
})

-- @todo get this to work
properties.Add("ixViewInventoryProperty", {
	MenuLabel = "#View Inventory",
	Order = 1,
	MenuIcon = "icon16/eye.png",

	Filter = function(self, entity, client)
		return client:IsAdmin() and entity:IsPlayer()
	end,

	Action = function(self, entity)
		self:MsgStart()
			net.WriteEntity(entity)
		self:MsgEnd()
	end,

	Receive = function(self, length, client)
	end
})

properties.Add("ixSetHealthProperty", {
	MenuLabel = "#Health",
	Order = 2,
	MenuIcon = "icon16/heart.png",

	Filter = function(self, entity, client)
		return client:IsAdmin() and entity:IsPlayer()
	end,

	MenuOpen = function( self, option, ent, tr )

		local submenu = option:AddSubMenu()
		local target = IsValid( ent.AttachedEntity ) and ent.AttachedEntity or ent

		for i = 100, 0, -25 do
			local option = submenu:AddOption(i, function() self:SetHealth( ent, i ) end )
		end

	end,

	Action = function(self, entity)
		-- not used
	end,

	SetHealth = function(self, target, health)
		self:MsgStart()
			net.WriteEntity(target)
			net.WriteUInt(health, 8)
		self:MsgEnd()
	end,

	Receive = function(self, length, client)
		if (client:IsAdmin()) then
			print(client)
			local entity = net.ReadEntity()
			local health = net.ReadUInt(8)
			ix.command.Run(client, "PlySetHP", {entity:GetName(), health})
			if (entity:Health() == 0) then entity:Kill() end
		end
	end
})

properties.Add("ixSetArmorProperty", {
	MenuLabel = "#Armor",
	Order = 3,
	MenuIcon = "icon16/shield.png",

	Filter = function(self, entity, client)
		return client:IsAdmin() and entity:IsPlayer()
	end,

	MenuOpen = function( self, option, ent, tr )

		local submenu = option:AddSubMenu()
		local target = IsValid( ent.AttachedEntity ) and ent.AttachedEntity or ent

		for i = 100, 0, -25 do
			local option = submenu:AddOption(i, function() self:SetArmor( ent, i ) end )
		end

	end,

	Action = function(self, entity)
		-- not used
	end,

	SetArmor = function(self, target, armor)
		self:MsgStart()
			net.WriteEntity(target)
			net.WriteUInt(armor, 8)
		self:MsgEnd()
	end,

	Receive = function(self, length, client)
		if (client:IsAdmin()) then
			local entity = net.ReadEntity()
			local armor = net.ReadUInt(8)
			ix.command.Run(client, "PlySetArmor", {entity:GetName(), armor})
		end
	end
})

properties.Add("ixDescription", {
	MenuLabel = "#Edit Description",
	Order = 4,
	MenuIcon = "icon16/book_edit.png",

	Filter = function(self, entity, client)
		return client:IsAdmin() and entity:IsPlayer()
	end,

	Action = function(self, entity)
		self:MsgStart()
			net.WriteEntity(entity)
		self:MsgEnd()
	end,

	Receive = function(self, length, client)
		if (client:IsAdmin()) then
			local entity = net.ReadEntity()
			client:RequestString("Set the character's description.", "New Description", function(text)
				entity:GetCharacter():SetDescription(text)
			end, entity:GetCharacter():GetDescription())
		end
	end

})

properties.Add("ixBodygroups", {
	MenuLabel = "#Edit Bodygroups",
	Order = 5,
	MenuIcon = "icon16/arrow_refresh.png",

	Filter = function(self, entity, client)
		return client:IsAdmin() and entity:IsPlayer()
	end,

	Action = function(self, entity)
		self:MsgStart()
			net.WriteEntity(entity)
		self:MsgEnd()
	end,

	Receive = function(self, length, client)
		if (client:IsAdmin()) then
			local target = net.ReadEntity()
			net.Start("ixBodygroupView")
				net.WriteEntity(target or client)
			net.Send(client)
		end
	end
})

hook.Add("CanProperty", "bone_manipulate", function(ply, property, ent)
	return false
end)
