
local PLUGIN = PLUGIN

ix.radio.RegisterChannel("combine", {
	color = Color(200, 0, 0, 255)
})

ix.radio.RegisterChannel("cab", {
	color = Color(200, 0, 0, 255)
})

ix.radio.RegisterChannel("tac", {
	color = Color(0, 144, 188, 255)
})

ix.radio.RegisterChannel("overwatch", {
	color = Color(0, 144, 188, 255)
})
