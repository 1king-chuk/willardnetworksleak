
ITEM.name = "Handheld Radio Base"
ITEM.model = Model("models/deadbodies/dead_male_civilian_radio.mdl")
ITEM.description = "A standard handheld radio."
