if (CLIENT) then
    function PLUGIN:LoadFonts(font, genericFont)

        surface.CreateFont( "WNMenuTitle", {
        	font = "Open Sans Extrabold", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
        	extended = false,
        	size = 70,
        	weight = 550,
        	antialias = true,
        } )
		
        surface.CreateFont( "WNSmallerMenuTitle", {
        	font = "Open Sans Extrabold", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
        	extended = false,
        	size = 42,
        	weight = 550,
        	antialias = true,
        } )
		
        surface.CreateFont( "WNSmallerMenuTitleNoBold", {
        	font = "Open Sans", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
        	extended = false,
        	size = 42,
        	weight = 550,
        	antialias = true,
        } )
        
        surface.CreateFont( "WNMenuSubtitle", {
        	font = "Yellowtail", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
        	size = 34,
        	weight = 500,
        	antialias = true,
        } )
        
        surface.CreateFont( "WNMenuFont", {
        	font = "Open Sans", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
        	extended = false,
        	size = 20,
        	weight = 550,
        	antialias = true,
        } )
        
        surface.CreateFont( "WNBackFont", {
        	font = "Open Sans", -- Use the font-name which is shown to you by your operating system Font Viewer, not the file name
        	extended = false,
        	size = 16,
        	weight = 550,
        	antialias = true,
        } )
    
    	surface.CreateFont( "MenuFont", {
    		font = "Open Sans",
    		extended = false,
    		size = 18,
    		weight = 550,
    		antialias = true,
    	} )
		
    	surface.CreateFont( "MenuFontBold", {
    		font = "Open Sans Bold",
    		extended = false,
    		size = 18,
    		weight = 550,
    		antialias = true,
    	} )
    
    	surface.CreateFont( "SubtitleFont", {
    		font = "Open Sans",
    		extended = false,
    		size = 14,
    		weight = 550,
    		antialias = true,
    	} )
    
    	surface.CreateFont( "TitlesFont", {
    		font = "Open Sans Bold",
    		extended = false,
    		size = 24,
    		weight = 550,
    		antialias = true,
    	} )
    
    	surface.CreateFont( "TitlesFontNoBold", {
    		font = "Open Sans",
    		extended = false,
    		size = 22,
    		weight = 550,
    		antialias = true,
    	} )
    
    	surface.CreateFont( "SmallerTitleFont", {
    		font = "Open Sans Bold",
    		extended = false,
    		size = 20,
    		weight = 550,
    		antialias = true,
    	} )
    
    	surface.CreateFont( "SmallerTitleFontNoBold", {
    		font = "Open Sans",
    		extended = false,
    		size = 20,
    		weight = 550,
    		antialias = true,
    	} )
    end
end