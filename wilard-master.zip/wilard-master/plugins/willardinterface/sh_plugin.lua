local PLUGIN = PLUGIN

PLUGIN.name = "Willard UI"
PLUGIN.author = "Fruity"
PLUGIN.description = "The UI for Willard Industries."

ix.util.Include("sh_fonts.lua")

if (CLIENT) then
	hook.Add("CreateMenuButtons", "ixConfig", function(tabs)
		if (!CAMI.PlayerHasAccess(LocalPlayer(), "Helix - Manage Config", nil)) then
			return
		end

			tabs["Admin"] = {
			
			RowNumber = 7,
			
			Width = 16,
			
			Height = 17,
			
			Icon = "willardnetworks/tabmenu/navicons/admin.png",
		
			Create = function(info, container)
				local adminContainer = container:Add("DFrame")
				adminContainer:SetSize(ScrW() * 0.65, ScrH() - 320)
				adminContainer:SetPos(ScrW() * 0.5 - adminContainer:GetSize() * 0.5 - 25, 150)
				adminContainer:ShowCloseButton(false)
				adminContainer:SetDeleteOnClose(true)
				adminContainer:SetDraggable( false )
				adminContainer:SetTitle("")
				adminContainer.Paint = function(self, w, h)
				end
				
				local adminTitleIcon = adminContainer:Add("DImage")
				adminTitleIcon:SetImage("willardnetworks/tabmenu/navicons/admin.png")
				adminTitleIcon:SetSize(16, 17)
				adminTitleIcon:SetPos(4, 3)
				
				local adminTitle = adminContainer:Add("DLabel")
				adminTitle:SetFont("TitlesFont")
				adminTitle:SetText("Admin")
				adminTitle:SetPos(26)
				adminTitle:SizeToContents()
				
				local settings = adminContainer:Add("ixSettings")
				settings:SetSearchEnabled(true)

				-- gather categories
				local categories = {}
				local categoryIndices = {}

				for k, v in pairs(ix.config.stored) do
					local index = v.data and v.data.category or "misc"

					categories[index] = categories[index] or {}
					categories[index][k] = v
				end

				-- sort by category phrase
				for k, _ in pairs(categories) do
					categoryIndices[#categoryIndices + 1] = k
				end

				table.sort(categoryIndices, function(a, b)
					return L(a) < L(b)
				end)

				-- add panels
				for _, category in ipairs(categoryIndices) do
					local categoryPhrase = L(category)
					settings:AddCategory(categoryPhrase)

					-- we can use sortedpairs since configs don't have phrases to account for
					for k, v in SortedPairs(categories[category]) do
						if (isfunction(v.hidden) and v.hidden()) then
							continue
						end

						local data = v.data.data
						local type = v.type
						local value = ix.util.SanitizeType(type, ix.config.Get(k))

						-- @todo check ix.gui.properties
						local row = settings:AddRow(type, categoryPhrase)
						row:SetText(ix.util.ExpandCamelCase(k))

						-- type-specific properties
						if (type == ix.type.number) then
							row:SetMin(data and data.min or 0)
							row:SetMax(data and data.max or 1)
							row:SetDecimals(data and data.decimals or 0)
						end

						row:SetValue(value, true)
						row:SetShowReset(value != v.default, k, v.default)

						row.OnValueChanged = function(panel)
							local newValue = ix.util.SanitizeType(type, panel:GetValue())

							panel:SetShowReset(newValue != v.default, k, v.default)

							net.Start("ixConfigSet")
								net.WriteString(k)
								net.WriteType(newValue)
							net.SendToServer()
						end

						row.OnResetClicked = function(panel)
							panel:SetValue(v.default, true)
							panel:SetShowReset(false)

							net.Start("ixConfigSet")
								net.WriteString(k)
								net.WriteType(v.default)
							net.SendToServer()
						end

						row:GetLabel():SetHelixTooltip(function(tooltip)
							local title = tooltip:AddRow("name")
							title:SetImportant()
							title:SetText(k)
							title:SizeToContents()
							title:SetMaxWidth(math.max(title:GetMaxWidth(), ScrW() * 0.5))

							local description = tooltip:AddRow("description")
							description:SetText(v.description)
							description:SizeToContents()
						end)
					end
				end

				settings:SizeToContents()
				container.panel = settings
			end,

			OnSelected = function(info, container)
				container.panel.searchEntry:RequestFocus()
			end,
			
			RowNumber = 6
		}
	end)
	
	hook.Add("Think", "F1Menu", function()
		if input.IsKeyDown( KEY_F1 ) then
			if ix.gui.menu and ix.gui.menu:IsVisible() then
				return
			end
			
			if ix.gui.characterMenu and ix.gui.characterMenu:IsVisible() then
				return
			end
			
			if LocalPlayer():GetCharacter() then
				if F1Frame and F1Frame:IsVisible() then
					return
				end
				
				F1Frame = vgui.Create("ixF1Menu")
			end
		end
	end)
end