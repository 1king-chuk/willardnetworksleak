
local errorModel = "models/error.mdl"
local PANEL = {}

AccessorFunc(PANEL, "animationTime", "AnimationTime", FORCE_NUMBER)

local function SetCharacter(self, character)
	self.character = character

	if (character) then
		self:SetModel(character:GetModel())
		self:SetSkin(character:GetData("skin", 0))

		local bodygroups = character:GetData("groups", nil)
		if (istable(bodygroups)) then
			for k, v in pairs(bodygroups) do
				self:SetBodygroup(k, v)
			end
		else
			self:SetBodyGroups("000000000")
		end
	else
		self:SetModel(errorModel)
	end
end

local function GetCharacter(self)
	return self.character
end

function PANEL:Init()
	self.activeCharacter = ClientsideModel(errorModel)
	self.activeCharacter:SetNoDraw(true)
	self.activeCharacter.SetCharacter = SetCharacter
	self.activeCharacter.GetCharacter = GetCharacter

	self.animationTime = 0.5
	
	self.shadeY = 0
	self.shadeHeight = 0
	
	self.cameraPosition = Vector(80, 0, 35)
	self.cameraAngle = Angle(0, 180, 0)
	self.lastPaint = 0
end

function PANEL:ResetSequence(model, lastModel)
	local sequence = model:LookupSequence("idle_unarmed")

	if (sequence <= 0) then
		sequence = model:SelectWeightedSequence(ACT_IDLE)
	end

	if (sequence > 0) then
		model:ResetSequence(sequence)
	else
		local found = false

		for _, v in ipairs(model:GetSequenceList()) do
			if ((v:lower():find("idle") or v:lower():find("fly")) and v != "idlenoise") then
				model:ResetSequence(v)
				found = true

				break
			end
		end

		if (!found) then
			model:ResetSequence(4)
		end
	end

	model:SetIK(false)

	-- copy cycle if we can to avoid a jarring transition from resetting the sequence
	if (lastModel) then
		model:SetCycle(lastModel:GetCycle())
	end
end

function PANEL:RunAnimation(model)
	model:FrameAdvance((RealTime() - self.lastPaint) * 0.5)
end

function PANEL:LayoutEntity(model)
	model:SetIK(false)

	self:RunAnimation(model)
end

function PANEL:SetActiveCharacter(character)
	self.shadeY = self:GetTall()
	self.shadeHeight = self:GetTall()
	
	-- set character immediately if we're an error (something isn't selected yet)
	if (self.activeCharacter:GetModel() == errorModel) then
		self.activeCharacter:SetCharacter(character)
		self:ResetSequence(self.activeCharacter)

		return
	end
end

function PANEL:Paint(width, height)
	local x, y = self:LocalToScreen(0, 0)

	cam.Start3D(self.cameraPosition, self.cameraAngle, 70, x, y, width, height)
		render.SuppressEngineLighting(true)
		render.SetLightingOrigin(self.activeCharacter:GetPos())

		-- setup lighting
		render.SetModelLighting(0, 1.5, 1.5, 1.5)

		for i = 1, 4 do
			render.SetModelLighting(i, 0.4, 0.4, 0.4)
		end

		render.SetModelLighting(5, 0.04, 0.04, 0.04)

		-- clip anything out of bounds
		local curparent = self
		local rightx = self:GetWide()
		local leftx = 0
		local topy = 0
		local bottomy = self:GetTall()
		local previous = curparent

		while (curparent:GetParent() != nil) do
			local lastX, lastY = previous:GetPos()
			curparent = curparent:GetParent()

			topy = math.Max(lastY, topy + lastY)
			leftx = math.Max(lastX, leftx + lastX)
			bottomy = math.Min(lastY + previous:GetTall(), bottomy + lastY)
			rightx = math.Min(lastX + previous:GetWide(), rightx + lastX)

			previous = curparent
		end

		ix.util.ResetStencilValues()
		
		render.SetStencilWriteMask(1)
		render.SetStencilTestMask(1)
		render.SetStencilReferenceValue(1)

		render.SetStencilFailOperation(STENCIL_KEEP)
		render.SetStencilZFailOperation(STENCIL_KEEP)

		self:LayoutEntity(self.activeCharacter)

		render.SetScissorRect(leftx, topy + self.shadeHeight, rightx, bottomy, true)
		self.activeCharacter:DrawModel()

		render.SetScissorRect(leftx, topy, rightx, bottomy, true)

		render.SetStencilCompareFunction(STENCIL_EQUAL)
		render.SetStencilPassOperation(STENCIL_KEEP)

		render.SetStencilEnable(false)

		render.SetScissorRect(0, 0, 0, 0, false)
		render.SuppressEngineLighting(false)
	cam.End3D()

	self.lastPaint = RealTime()
end

function PANEL:OnRemove()
	self.activeCharacter:Remove()
end

vgui.Register("ixCharMenuCarousel", PANEL, "Panel")

-- character load panel
PANEL = {}

AccessorFunc(PANEL, "animationTime", "AnimationTime", FORCE_NUMBER)
AccessorFunc(PANEL, "backgroundFraction", "BackgroundFraction", FORCE_NUMBER)

function PANEL:Init()
	local parent = self:GetParent()
	local padding = self:GetPadding()
	local halfWidth = parent:GetWide() * 0.5 - (padding * 2)
	local halfHeight = parent:GetTall() * 0.5 - (padding * 2)
	local halfPadding = padding * 0.38

	self.animationTime = 1
	self.backgroundFraction = 1

	-- main panel
	self.panel = self:AddSubpanel("main")
	self.panel:SetTitle("")
	self.panel.OnSetActive = function()
		self:CreateAnimation(self.animationTime, {
			index = 2,
			target = {backgroundFraction = 1},
			easing = "outQuint",
		})
	end
	
	-- Character Count
	local Count = 0
	
	for k, v in pairs(ix.characters) do
		Count = Count + 1
	end
	
	self.CharacterCount = Count
	
	local panelLoad = self.panel:Add("DPanel")
	panelLoad:SetSize(860, 654)
	panelLoad:SetPos(self.panel:GetWide() * 0.5 - panelLoad:GetWide() * 0.5, self.panel:GetTall() * 0.5 - panelLoad:GetTall() * 0.5 - 70)
	panelLoad.Paint = function(self, w, h) end
	
	local titleLabel = panelLoad:Add("DLabel")
	titleLabel:SetTextColor(color_white)
	titleLabel:SetFont("WNMenuTitle")
	titleLabel:SetText("Characters")
	titleLabel:SizeToContents()
	titleLabel:SetContentAlignment(5)
	titleLabel:Dock(TOP)

	local subtitleLabel = panelLoad:Add("DLabel")
	subtitleLabel:SetTextColor(Color(243, 69, 42, 255))
	subtitleLabel:SetFont("WNMenuSubtitle")
	subtitleLabel:SetText("Choose your Character")
	subtitleLabel:SizeToContents()
	subtitleLabel:DockMargin(0, 0, 0, 20)
	subtitleLabel:SetContentAlignment(5)
	subtitleLabel:Dock(TOP)
		
	self.charactersPanel = panelLoad:Add("DPanel")
	self.charactersPanel:SetSize(panelLoad:GetWide(), 480)
	self.charactersPanel:Dock(TOP)
	self.charactersPanel.Paint = function(self, w, h) end
	
	self.characterImages = self.charactersPanel:Add("DPanel")
	self.characterImages.Paint = function(self, w, h) end
	
	if self.CharacterCount == 1 then
		self.characterImages:SetSize(200, 400)
	else
		self.characterImages:SetSize((self.CharacterCount) * 220 - 20, 400)
	end
	
	self.characterImages:SetPos(self.charactersPanel:GetWide() * 0.5 - self.characterImages:GetWide() * 0.5, 0)
	
	self.characterText = self.charactersPanel:Add("DPanel")
	self.characterText.Paint = function(self, w, h) end
	
	if self.CharacterCount == 1 then
		self.characterText:SetSize(200, 80)
	else
		self.characterText:SetSize(self.CharacterCount * 220 - 20, 80)
	end
	
	self.characterText:SetPos(self.charactersPanel:GetWide() * 0.5 - self.characterText:GetWide() * 0.5, self.characterImages:GetTall())
	
	if self.CharacterCount > 4 then
		self.characterText:SetPos(0, self.characterImages:GetTall())	
		self.characterImages:SetPos(0, 0)
		
		self.nextButton = self.panel:Add("DImageButton")
		
		self.nextButton:SetSize(32, 32)
		self.nextButton:SetImage("willardnetworks/charselect/arrow_right.png")
		self.nextButton:MoveRightOf(panelLoad)
		local x, y = self.nextButton:GetPos()
		self.nextButton:SetPos(x + 20, panelLoad:GetTall() * 0.5 + 28)
		
		self.nextButton.OnCursorEntered = function()
			surface.PlaySound("helix/ui/rollover.wav")
			self.nextButton:SetColor( Color( 210, 210, 210, 255 ) )
		end
		
		self.nextButton.OnCursorExited = function()
			self.nextButton:SetColor( Color( 255, 255, 255, 255 ) )
		end
		
		self.nextButton.DoClick = function()				
			local x, y = self.characterImages:GetPos()
			local x2, y2 = self.characterText:GetPos()
			
			if math.abs( x ) == ( (self.CharacterCount - 5) * 220) then
				self.nextButton:SetVisible(false)
			end
			
			self.characterImages:MoveTo( x - 220, y, 0.1, 0, 1 )
			self.characterText:MoveTo( x2 - 220, y2, 0.1, 0, 1 )
			surface.PlaySound("helix/ui/press.wav")
			
			if IsValid(self.previousButton) then
				return
			else
				self.previousButton = self.panel:Add("DImageButton")
				local x, y = self.nextButton:GetPos()
				
				self.previousButton:SetSize(32, 32)
				self.previousButton:SetImage("willardnetworks/charselect/arrow_left.png")
				self.previousButton:SetPos(x - 880 - self.previousButton:GetWide() - 20, y)
				
				self.previousButton.OnCursorEntered = function()
					surface.PlaySound("helix/ui/rollover.wav")
					self.previousButton:SetColor( Color( 210, 210, 210, 255 ) )
				end
				
				self.previousButton.OnCursorExited = function()
					self.previousButton:SetColor( Color( 255, 255, 255, 255 ) )
				end
				
				self.previousButton.DoClick = function()		
					local x, y = self.characterImages:GetPos()
					local x2, y2 = self.characterText:GetPos()
					
					if IsValid(self.nextButton) then
						self.nextButton:SetVisible(true)
					end
					
					surface.PlaySound("helix/ui/press.wav")
					self.characterImages:MoveTo( x + 220, y, 0.1, 0, 1 )
					self.characterText:MoveTo( x2 + 220, y2, 0.1, 0, 1 )
					
					if IsValid(self.previousButton) then
						if x == -220 then
							self.previousButton:Remove()
						end
					end
				end
			end
		end
	end
	
	for i = 1, #ix.characters do
		local id = ix.characters[i]
		local character = ix.char.loaded[id]

		if (!character or character:GetID() == ignoreID) then
			continue
		end

		local index = character:GetFaction()
		local faction = ix.faction.indices[index]
		
		local image = self.characterImages:Add("DImageButton")
		image:SetImage(faction.selectImage or "willardnetworks/charselect/citizen2.png")
		image:Dock(LEFT)
		
		if i == 1 then
			image:DockMargin(0, 0, 0, 0)
		else
			image:DockMargin(0, 0, 20, 0)
		end
		
		image.id = character:GetID()
		image:MoveToBack()
		image:SetSize( 200, 400 )
		image.Paint = function ( self, w, h ) end
		
		local model = image:Add("ixCharMenuCarousel")
		model:SetActiveCharacter(character)
		model:SetSize(550, 440)
		
		if index == FACTION_MPF then
			model:SetPos(-180)
		else
			model:SetPos(-170)
		end
		
		self.characterTextPanel = self.characterText:Add("DPanel")
		self.characterTextPanel:Dock(RIGHT)
		self.characterTextPanel:SetWide(200)
		self.characterTextPanel.id = character:GetID()
		self.characterTextPanel.Paint = function(self, w, h) end
		
		if i == 1 then
			self.characterTextPanel:DockMargin(0, 0, 0, 0)
		else
			self.characterTextPanel:DockMargin(0, 0, 20, 0)
		end
		
		local nameText = self.characterTextPanel:Add("DLabel")
		nameText:SetFont("WNMenuFont")
		
		if string.len( character:GetName() ) > 17 then
			nameText:SetText(string.upper(string.sub(character:GetName(), 1, 16) .."..."))
		else
			nameText:SetText(string.upper(character:GetName()))
		end
		
		nameText:SizeToContents()
		nameText:Dock(TOP)
		nameText:DockMargin(0, 10, 0, 0)
		nameText:SetContentAlignment(5)
		
		local factionText = self.characterTextPanel:Add("DLabel")
		factionText:SetFont("WNMenuFont")
		if (faction.name) == "Overwatch Transhuman Arm" then
			factionText:SetText("OVERWATCH SOLDIER")
		else
			factionText:SetText(string.upper(faction.name))
		end
		
		factionText:SizeToContents()
		factionText:Dock(TOP)
		factionText:SetContentAlignment(5)
		factionText:SetTextColor(Color(200, 200, 200, 200))
	
		local buttons = self.characterTextPanel:Add("DPanel")
		buttons:SetTall(20)
		buttons:Dock(BOTTOM)
		buttons.Paint = function(self, w, h) end
		
		local loadChar = buttons:Add("DImageButton")
		loadChar:SetSize(20, 20)
		loadChar:SetImage("willardnetworks/charselect/check.png")
		loadChar:Dock(LEFT)
		loadChar:DockMargin(75, 0, 0, 0)
		
		loadChar.OnCursorEntered = function()
			surface.PlaySound("helix/ui/rollover.wav")
			loadChar:SetColor( Color( 210, 210, 210, 255 ) )
		end
		
		loadChar.OnCursorExited = function()
			loadChar:SetColor( Color( 255, 255, 255, 255 ) )
		end
		
		loadChar.DoClick = function()
			self.character = character
			self:SetMouseInputEnabled(false)
			self:Slide("down", self.animationTime, function()
				net.Start("ixCharacterChoose")
					net.WriteUInt(self.character:GetID(), 32)
				net.SendToServer()
			end, true)
		end
		
		local deleteButton = buttons:Add("DImageButton")
		deleteButton:SetSize(20, 20)
		deleteButton:SetImage("willardnetworks/charselect/delete.png")
		deleteButton:Dock(RIGHT)
		deleteButton:DockMargin(0, 0, 75, 0)
		
		deleteButton.OnCursorEntered = function()
			surface.PlaySound("helix/ui/rollover.wav")
			deleteButton:SetColor( Color( 210, 210, 210, 255 ) )
		end
		
		deleteButton.OnCursorExited = function()
			deleteButton:SetColor( Color( 255, 255, 255, 255 ) )
		end
		
		deleteButton.DoClick = function()
			self.character = character
			self:SetActiveSubpanel("delete")
		end
	end
	
	local backPanel = panelLoad:Add("DPanel")
	backPanel:Dock(TOP)
	backPanel:SetSize(panelLoad:GetWide(), 30)
	backPanel:DockMargin(0, 20, 0, 0)
	backPanel.Paint = function(self, w, h) end
	
	local back = backPanel:Add("DButton")
	back:SetText("")
	back:SetSize(80, 30)
	back:Center()
	
	back.Paint = function( self, w, h )
		draw.RoundedBox( 10, 0, 0, back:GetWide(), back:GetTall(), Color(78, 79, 100, 240) )
		
		if back:IsHovered() then
			draw.RoundedBox( 10, 0, 0, back:GetWide(), back:GetTall(), Color(78, 79, 100, 255) )
		end
	end
	
	self.factionBackTitle = back:Add("DLabel")
	self.factionBackTitle:SetFont("WNBackFont")
	self.factionBackTitle:SetText("Back")
	self.factionBackTitle:SetTextColor(Color(230, 230, 230, 255))
	self.factionBackTitle:SizeToContents()
	self.factionBackTitle:SetPos(back:GetWide() * 0.5 - self.factionBackTitle:GetWide() * 0.5 + 15, back:GetTall() * 0.5 - self.factionBackTitle:GetTall() * 0.5 - 1)
	
	self.factionBackIcon = back:Add("DImage")
	self.factionBackIcon:SetImage("willardnetworks/mainmenu/back_arrow.png")
	self.factionBackIcon:SetSize(20, 20)
	self.factionBackIcon:SetPos(13, back:GetTall() * 0.5 - 20 * 0.5)
	
	back.OnCursorEntered = function()
		surface.PlaySound("helix/ui/rollover.wav")
		self.factionBackTitle:SetTextColor(Color(255, 255, 255, 255))
	end
	
	back.OnCursorExited = function()
		self.factionBackTitle:SetTextColor(Color(230, 230, 230, 255))
	end
	
	back.DoClick = function()
		self:SlideDown()
		parent.mainPanel:Undim()
	end
	
-- character deletion panel
	self.delete = self:AddSubpanel("delete")
	self.delete:SetTitle(nil)
	self.delete.OnSetActive = function()
		self.deleteModel:SetModel(self.character:GetModel())
		if self.character:GetData("customSkin") then
			self.deleteModel.Entity:SetSkin(self.character:GetData("customSkin"))
		end;

		local bodygroups = self.character:GetData("groups", nil)

		if (istable(bodygroups)) then
			for k, v in pairs(bodygroups) do
				self.deleteModel.Entity:SetBodygroup(k, v)
			end
		end
		
		self:CreateAnimation(self.animationTime, {
			index = 2,
			target = {backgroundFraction = 0},
			easing = "outQuint"
		})
	end

	local deleteInfo = self.delete:Add("Panel")
	deleteInfo:SetSize(parent:GetWide() * 0.5, parent:GetTall())
	deleteInfo:Dock(LEFT)

	local deleteReturn = deleteInfo:Add("ixMenuButton")
	deleteReturn:Dock(BOTTOM)
	deleteReturn:SetText("no")
	deleteReturn.DoClick = function()
		self:SetActiveSubpanel("main")
	end

	local deleteConfirm = self.delete:Add("ixMenuButton")
	deleteConfirm:Dock(BOTTOM)
	deleteConfirm:SetText("yes")
	deleteConfirm:SetContentAlignment(6)
	deleteConfirm:SetTextColor(derma.GetColor("Error", deleteConfirm))
	deleteConfirm.DoClick = function()
	
		self.CharacterCount = self.CharacterCount - 1
		
		local id = self.character:GetID()

		parent:ShowNotice(1, L("deleteComplete", self.character:GetName()))
		
		self:SetActiveSubpanel("main")
		
		net.Start("ixCharacterDelete")
			net.WriteUInt(id, 32)
		net.SendToServer()
		
		for k, v in pairs(self.characterImages:GetChildren()) do
			if v.id == id then
				v:Remove()
			end
		end
		
		for k, v in pairs(self.characterText:GetChildren()) do
			if v.id == id then
				v:Remove()
			end
		end
		
		if self.CharacterCount == 1 then
			self.characterImages:SetSize(200, 400)
			self.characterText:SetSize(200, 80)
		else
			self.characterImages:SetSize((self.CharacterCount) * 220 - 20, 400)
			self.characterText:SetSize(self.CharacterCount * 220 - 20, 80)
		end
		
		if self.CharacterCount > 4 then
			self.characterImages:SetPos(0, 0)
			self.characterText:SetPos(0, self.characterImages:GetTall())
		else
			if IsValid(self.nextButton) then
				self.nextButton:Remove()
			end
			
			if IsValid(self.previousButton) then
				self.previousButton:Remove()
			end
			
			self.characterImages:SetPos(self.charactersPanel:GetWide() * 0.5 - self.characterImages:GetWide() * 0.5, 0)
			self.characterText:SetPos(self.charactersPanel:GetWide() * 0.5 - self.characterText:GetWide() * 0.5, self.characterImages:GetTall())
		end
		
		if IsValid(self.characterTextPanel) then
			if self.CharacterCount == 1 then
				self.characterTextPanel:DockMargin(0, 0, 0, 0)
			end
		end
	end

	self.deleteModel = deleteInfo:Add("ixModelPanel")
	self.deleteModel:Dock(FILL)
	self.deleteModel:SetModel(errorModel)
	self.deleteModel:SetFOV(78)
	self.deleteModel.PaintModel = self.deleteModel.Paint

	local deleteNag = self.delete:Add("Panel")
	deleteNag:SetTall(parent:GetTall() * 0.5)
	deleteNag:Dock(BOTTOM)

	local deleteTitle = deleteNag:Add("DLabel")
	deleteTitle:SetFont("ixTitleFont")
	deleteTitle:SetText(L("areYouSure"):upper())
	deleteTitle:SetTextColor(Color(243, 69, 42, 255))
	deleteTitle:SizeToContents()
	deleteTitle:Dock(TOP)

	local deleteText = deleteNag:Add("DLabel")
	deleteText:SetFont("ixMenuButtonFont")
	deleteText:SetText(L("deleteConfirm"))
	deleteText:SetTextColor(color_white)
	deleteText:SetContentAlignment(7)
	deleteText:Dock(FILL)

	-- finalize setup
	self:SetActiveSubpanel("main", 0)
end

function PANEL:OnCharacterDeleted(character)
	local parent = self:GetParent()
	local bHasCharacter = #ix.characters > 0
	
	if (self.bActive and #ix.characters == 0) then
		self:SlideDown()
		parent.mainPanel.loadButton:SetDisabled(true)
		parent.mainPanel.loadButton:SetTextColor(Color(90, 90, 90, 255))
		
		parent.mainPanel.loadButton.Paint = function( self, w, h )
			surface.SetDrawColor(Color(0, 0, 0, 0));
			surface.DrawRect(0,0, w, h);
			
			if self:IsHovered() and (bHasCharacter) then
				draw.RoundedBox( 10, 0, 0, self:GetWide(), self:GetTall(), Color(78, 79, 100, 240) )
			end
		end
		
		parent.mainPanel.loadButton.OnCursorEntered = function()
			if (!bHasCharacter) then
				parent.mainPanel.loadButton:SetTextColor(Color(90, 90, 90, 255))
				return
			end
		end
		
		parent.mainPanel.loadButton.OnCursorExited = function()
			if (!bHasCharacter) then
				parent.mainPanel.loadButton:SetTextColor(Color(90, 90, 90, 255))
				return
			end
		end
	end
end

function PANEL:OnSlideUp()
	self.bActive = true
end

function PANEL:OnSlideDown()
	self.bActive = false
end

function PANEL:Paint(width, height)
end

vgui.Register("ixCharMenuLoad", PANEL, "ixCharMenuPanel")
