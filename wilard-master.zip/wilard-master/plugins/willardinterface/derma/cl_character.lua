local gradient = surface.GetTextureID("vgui/gradient-d")
local audioFadeInTime = 2
local animationTime = 0.5

local backgrounds = {
	"citizen_bg",
	"cps_bg",
	"headcrab_bg",
	"ota_bg",
	"vort_bg",
	"workers_bg",
	"zombie_bg"
}

local background_url = "willardnetworks/backgrounds/"..table.Random(backgrounds)..".jpg"

-- character menu panel
DEFINE_BASECLASS("ixSubpanelParent")
local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetSize())
	self:SetPos(0, 0)

	self.childPanels = {}
	self.subpanels = {}
	self.activeSubpanel = ""

	self.currentDimAmount = 0
	self.currentY = 0
	self.currentScale = 1
	self.currentAlpha = 255
	self.targetDimAmount = 0
	self.targetScale = 0
end

function PANEL:Dim(length, callback)
	length = length or animationTime
	self.currentDimAmount = 0

	self:CreateAnimation(length, {
		target = {
			currentDimAmount = self.targetDimAmount,
			currentScale = self.targetScale,
			OnComplete = callback
		},
		easing = "outCubic"
	})

	self:OnDim()
end

function PANEL:Undim(length, callback)
	length = length or animationTime
	self.currentDimAmount = self.targetDimAmount

	self:CreateAnimation(length, {
		target = {
			currentDimAmount = 0,
			currentScale = 1
		},
		easing = "outCubic",
		OnComplete = callback
	})

	self:OnUndim()
end

function PANEL:OnDim()
end

function PANEL:OnUndim()
end

function PANEL:Paint(width, height)
	local amount = self.currentDimAmount
	local bShouldScale = self.currentScale != 1
	local matrix

	-- draw child panels with scaling if needed
	if (bShouldScale) then
		matrix = Matrix()
		matrix:Scale(Vector(1, 1, 0.0001) * self.currentScale)
		matrix:Translate(Vector(
			ScrW() * 0.5 - (ScrW() * self.currentScale * 0.5),
			ScrH() * 0.5 - (ScrH() * self.currentScale * 0.5),
			1
		))

		cam.PushModelMatrix(matrix)
		self.currentMatrix = matrix
	end

	BaseClass.Paint(self, width, height)

	if (bShouldScale) then
		cam.PopModelMatrix()
		self.currentMatrix = nil
	end

	if (amount > 0) then
		local color = Color(0, 0, 0, amount)

		surface.SetDrawColor(color)
		surface.DrawRect(0, 0, width, height)
	end
end

vgui.Register("ixCharMenuPanel", PANEL, "ixSubpanelParent")

-- character menu main button list
PANEL = {}

function PANEL:Init()
	local parent = self:GetParent()
	self:SetSize(parent:GetWide(), parent:GetTall())

	self:GetVBar():SetWide(0)
	self:GetVBar():SetVisible(false)
end

function PANEL:Add(name)
	local panel = vgui.Create(name, self)
	panel:Dock(LEFT)

	return panel
end

function PANEL:SizeToContents()
	self:GetCanvas():InvalidateLayout(true)

	-- if the canvas has extra space, forcefully dock to the bottom so it doesn't anchor to the top
	if (self:GetTall() > self:GetCanvas():GetTall()) then
		self:GetCanvas():Dock(BOTTOM)
	else
		self:GetCanvas():Dock(NODOCK)
	end
end

vgui.Register("ixCharMenuButtonList", PANEL, "DScrollPanel")

-- main character menu panel
PANEL = {}

AccessorFunc(PANEL, "bUsingCharacter", "UsingCharacter", FORCE_BOOL)

function PANEL:Init()
	local padding = self:GetPadding()
	local halfWidth = ScrW() * 0.5
	local halfPadding = padding * 0.5
	
	self:DockPadding(padding, padding, padding, padding)

	self.logoPanel = self:Add("Panel")
	self.logoPanel:SetSize(ScrW(), ScrH() * 0.25)
	self.logoPanel:SetPos(0, ScrH() * 0.10)
	
	local newHeight = padding
	local subtitle = L2("schemaDesc") or Schema.description
	
	-- draw schema logo material instead of text if available
	local logo = ix.util.GetMaterial("willardnetworks/newlogo.png")
	
	local logoImage = self.logoPanel:Add("DImage")
	logoImage:SetMaterial(logo)
	logoImage:SetSize(200, 230)
	logoImage:SetPos(halfWidth - logoImage:GetWide() * 0.5, halfPadding)
	logoImage:SetPaintedManually(true)
	
	newHeight = newHeight + logoImage:GetTall()

	local titleLabel = self.logoPanel:Add("DLabel")
	titleLabel:SetTextColor(color_white)
	titleLabel:SetFont("WNMenuTitle")
	titleLabel:SetText(ix.config.Get("menuTitle") or "Willard Networks")
	titleLabel:SizeToContents()
	titleLabel:SetPos(halfWidth - titleLabel:GetWide() * 0.5, halfPadding)
	titleLabel:MoveBelow(logoImage)
	titleLabel:SetPaintedManually(true)
	newHeight = newHeight + titleLabel:GetTall()

	local subtitleLabel = self.logoPanel:Add("DLabel")
	subtitleLabel:SetTextColor(Color(243, 69, 41, 255))
	subtitleLabel:SetFont("WNMenuSubtitle")
	subtitleLabel:SetText(ix.config.Get("menuDescription") or "Place some fancy text here")
	subtitleLabel:SizeToContents()
	subtitleLabel:SetPos(halfWidth - subtitleLabel:GetWide() * 0.5, 0)
	subtitleLabel:MoveBelow(titleLabel)
	subtitleLabel:SetPaintedManually(true)
	newHeight = newHeight + subtitleLabel:GetTall()
	
	local star = self.logoPanel:Add("DImage")
	local starImage = ix.util.GetMaterial("willardnetworks/star7.png")
	star:SetMaterial(starImage)
	star:SetSize(31, 110)
	star:SetPos(halfWidth - star:GetWide() * 0.5, halfPadding)
	star:MoveBelow(subtitleLabel)
	star:SetPaintedManually(true)
	
	newHeight = newHeight + star:GetTall()

	self.buttonList = self.logoPanel:Add("DPanel")
	self.buttonList:SetSize(600, 30)
	self.buttonList:SetPos(halfWidth - self.buttonList:GetWide() * 0.5, 10)
	self.buttonList:MoveBelow(star)
	self.buttonList.Paint = function( self, w, h )
		surface.SetDrawColor(Color(0, 0, 0, 0));
		surface.DrawRect(0,0, w, h);
	end
	
	self:CreateButtons()
	
	newHeight = newHeight + self.buttonList:GetTall()
	
	self.logoPanel:SetTall(newHeight)
end

function PANEL:CreateButtons()
	local parent = self:GetParent()
	local padding = self:GetPadding()
	local halfWidth = ScrW() * 0.5
	local halfPadding = padding * 0.5
	local bHasCharacter = #ix.characters > 0
	self.bUsingCharacter = LocalPlayer().GetCharacter and LocalPlayer():GetCharacter()
	
	local function PaintButton(name, w, h)
		surface.SetDrawColor(Color(0, 0, 0, 0));
		surface.DrawRect(0,0, w, h);
		
		if name:IsHovered() then
			draw.RoundedBox( 10, 0, 0, w, h, Color(78, 79, 100, 240) )
		end
	end
	
	local function OnCursor(name, title)
		name.OnCursorEntered = function()
			surface.PlaySound("helix/ui/rollover.wav")
			title:SetTextColor(Color(255, 255, 255, 255))
		end
		
		name.OnCursorExited = function()
			title:SetTextColor(Color(230, 230, 230, 255))
		end
	end
	
	-- create character button
	local createButton = self.buttonList:Add("DButton")
	createButton:SetText("")
	createButton:SetSize(140, 30)
	createButton:Dock(LEFT)
	createButton.Paint = function( self, w, h ) PaintButton(self, w, h) end
	
	self.createButtonIcon = createButton:Add("DImage")
	self.createButtonIcon:SetImage("willardnetworks/mainmenu/new_arrival.png")
	self.createButtonIcon:SetSize(20, 20)
	self.createButtonIcon:SetPos(9, createButton:GetTall() * 0.5 - 20 * 0.5)
	
	self.createButtonTitle = createButton:Add("DLabel")
	self.createButtonTitle:SetFont("WNMenuFont")
	self.createButtonTitle:SetText("NEW ARRIVAL")
	self.createButtonTitle:SetTextColor(Color(230, 230, 230, 255))
	self.createButtonTitle:SizeToContents()
	self.createButtonTitle:SetPos(createButton:GetWide() * 0.5 - self.createButtonTitle:GetWide() * 0.5 + 14, createButton:GetTall() * 0.5 - self.createButtonTitle:GetTall() * 0.5)
	
	OnCursor(createButton, self.createButtonTitle)
	
	createButton.DoClick = function()
		local maximum = hook.Run("GetMaxPlayerCharacter", LocalPlayer()) or ix.config.Get("maxCharacters", 5)
		-- don't allow creation if we've hit the character limit
		if (#ix.characters >= maximum) then
			self:GetParent():ShowNotice(3, L("maxCharacters"))
			return
		end
		surface.PlaySound("helix/ui/press.wav")
		self:Dim()
		parent.newCharacterPanel:SetActiveSubpanel("faction", 0)
		parent.newCharacterPanel:SlideUp()
	end

	-- load character button
	self.loadButton = self.buttonList:Add("DButton")
	self.loadButton:SetText("")
	self.loadButton:SetSize(140, 30)
	self.loadButton:Dock(LEFT)
	self.loadButton.Paint = function( self, w, h )
		surface.SetDrawColor(Color(0, 0, 0, 0));
		surface.DrawRect(0,0, w, h);
		
		if self:IsHovered() and (bHasCharacter) then
			draw.RoundedBox( 10, 0, 0, w, h, Color(78, 79, 100, 240) )
		end
	end
	
	self.loadButtonTitle = self.loadButton:Add("DLabel")
	self.loadButtonTitle:SetFont("WNMenuFont")
	self.loadButtonTitle:SetText("CHARACTERS")
	self.loadButtonTitle:SetTextColor(Color(230, 230, 230, 255))
	self.loadButtonTitle:SizeToContents()
	self.loadButtonTitle:SetPos(self.loadButton:GetWide() * 0.5 - self.loadButtonTitle:GetWide() * 0.5 + 12, self.loadButton:GetTall() * 0.5 - self.loadButtonTitle:GetTall() * 0.5)
	
	self.loadButtonIcon = self.loadButton:Add("DImage")
	self.loadButtonIcon:SetImage("willardnetworks/mainmenu/characters.png")
	self.loadButtonIcon:SetSize(20, 20)
	self.loadButtonIcon:SetPos(12, self.loadButton:GetTall() * 0.5 - 20 * 0.5)
	
	self.loadButton.OnCursorEntered = function()
		if (!bHasCharacter) then
			self.loadButtonTitle:SetTextColor(Color(90, 90, 90, 255))
			return
		end
		
		surface.PlaySound("helix/ui/rollover.wav")
		self.loadButtonTitle:SetTextColor(Color(255, 255, 255, 255))
	end
	
	self.loadButton.OnCursorExited = function()
		if (!bHasCharacter) then
			self.loadButtonTitle:SetTextColor(Color(90, 90, 90, 255))
			return
		end
		
		self.loadButtonTitle:SetTextColor(Color(230, 230, 230, 255))
	end
	
	self.loadButton.DoClick = function()
		self:Dim()
		parent.loadCharacterPanel:SlideUp()
		surface.PlaySound("helix/ui/press.wav")
	end

	if (!bHasCharacter) then
		self.loadButton:SetDisabled(true)
		self.loadButtonTitle:SetTextColor(Color(90, 90, 90, 255))
		self.loadButtonIcon:SetImageColor(Color(90, 90, 90, 255))
	end

	-- community button
	local extraButton = self.buttonList:Add("DButton")
	extraButton:SetText("")
	extraButton:SetSize(90, 30)
	extraButton:Dock(LEFT)
	extraButton.Paint = function( self, w, h ) PaintButton(self, w, h) end
	
	self.extraButtonTitle = extraButton:Add("DLabel")
	self.extraButtonTitle:SetFont("WNMenuFont")
	self.extraButtonTitle:SetText("INFO ")
	self.extraButtonTitle:SetTextColor(Color(230, 230, 230, 255))
	self.extraButtonTitle:SizeToContents()
	self.extraButtonTitle:SetPos(extraButton:GetWide() * 0.5 - self.extraButtonTitle:GetWide() * 0.5 + 16, extraButton:GetTall() * 0.5 - self.extraButtonTitle:GetTall() * 0.5)
	
	self.extraButtonIcon = extraButton:Add("DImage")
	self.extraButtonIcon:SetImage("willardnetworks/mainmenu/info.png")
	self.extraButtonIcon:SetSize(20, 20)
	self.extraButtonIcon:SetPos(14, extraButton:GetTall() * 0.5 - 20 * 0.5)
	
	OnCursor(extraButton, self.extraButtonTitle)
	
	extraButton.DoClick = function()
		gui.OpenURL("https://willard.network/")
		surface.PlaySound("helix/ui/press.wav")
	end
	
	-- content button
	local contentButton = self.buttonList:Add("DButton")
	contentButton:SetText("")
	contentButton:SetSize(120, 30)
	contentButton:Dock(LEFT)
	contentButton.Paint = function( self, w, h ) PaintButton(self, w, h) end
	
	self.contentButtonTitle = contentButton:Add("DLabel")
	self.contentButtonTitle:SetFont("WNMenuFont")
	self.contentButtonTitle:SetText("CONTENT")
	self.contentButtonTitle:SetTextColor(Color(230, 230, 230, 255))
	self.contentButtonTitle:SizeToContents()
	self.contentButtonTitle:SetPos(contentButton:GetWide() * 0.5 - self.contentButtonTitle:GetWide() * 0.5 + 15, contentButton:GetTall() * 0.5 - self.contentButtonTitle:GetTall() * 0.5)
	
	self.contentButtonIcon = contentButton:Add("DImage")
	self.contentButtonIcon:SetImage("willardnetworks/mainmenu/content.png")
	self.contentButtonIcon:SetSize(20, 20)
	self.contentButtonIcon:SetPos(13, contentButton:GetTall() * 0.5 - 20 * 0.5)
	
	OnCursor(contentButton, self.contentButtonTitle)
	
	contentButton.DoClick = function()
		gui.OpenURL("https://steamcommunity.com/sharedfiles/filedetails/?id=1930942774")
		surface.PlaySound("helix/ui/press.wav")
	end

	-- leave/return button
	self.returnButton = self.buttonList:Add("DButton")
	self.returnButton:SetSize(110, 30)
	self.returnButton:SetText("")
	self.returnButton:Dock(LEFT)
	self.returnButton.Paint = function( self, w, h ) PaintButton(self, w, h) end
	
	self.returnButtonTitle = self.returnButton:Add("DLabel")
	self.returnButtonTitle:SetFont("WNMenuFont")
	self.returnButtonTitle:SetTextColor(Color(230, 230, 230, 255))
	self.returnButtonTitle:SetPos(self.returnButton:GetWide() * 0.5 - self.returnButtonTitle:GetWide() * 0.5 + 18, self.returnButton:GetTall() * 0.5 - self.returnButtonTitle:GetTall() * 0.5)
	
	self.returnButtonIcon = self.returnButton:Add("DImage")
	self.returnButtonIcon:SetImage("willardnetworks/mainmenu/exit.png")
	self.returnButtonIcon:SetSize(20, 20)
	self.returnButtonIcon:SetPos(13, self.returnButton:GetTall() * 0.5 - 20 * 0.5)
	
	OnCursor(self.returnButton, self.returnButtonTitle)
	
	self:UpdateReturnButton()
	
	self.returnButton.DoClick = function()
		if (self.bUsingCharacter) then
			parent:Close()
		else
			RunConsoleCommand("disconnect")
		end
		
		surface.PlaySound("helix/ui/press.wav")
	end
end

function PANEL:UpdateReturnButton(bValue)
	if (bValue == nil) then
		bValue = self.bUsingCharacter
	end

	self.returnButtonTitle:SetText(bValue and "RETURN" or "EXIT")
	self.returnButtonTitle:SizeToContents()
	
	if (!bValue) then
		self.returnButton:SetSize(90, 30)
		self.returnButtonTitle:SetPos(self.returnButton:GetWide() * 0.5 - self.returnButtonTitle:GetWide() * 0.5 + 14, self.returnButton:GetTall() * 0.5 - self.returnButtonTitle:GetTall() * 0.5)
		self.returnButtonIcon:SetPos(18, self.returnButton:GetTall() * 0.5 - 20 * 0.5)
		self.buttonList:SetSize(580, 30)
	end
end

function PANEL:OnDim()
	-- disable input on this panel since it will still be in the background while invisible - prone to stray clicks if the
	-- panels overtop slide out of the way
	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
end

function PANEL:OnUndim()
	self:SetMouseInputEnabled(true)
	self:SetKeyboardInputEnabled(true)

	-- we may have just deleted a character so update the status of the return button
	self.bUsingCharacter = LocalPlayer().GetCharacter and LocalPlayer():GetCharacter()
	self:UpdateReturnButton()
end

function PANEL:OnClose()
	for _, v in pairs(self:GetChildren()) do
		if (IsValid(v)) then
			v:SetVisible(false)
		end
	end
end

vgui.Register("ixCharMenuMain", PANEL, "ixCharMenuPanel")

-- container panel
PANEL = {}

function PANEL:Init()
	if (IsValid(ix.gui.loading)) then
		ix.gui.loading:Remove()
	end

	if (IsValid(ix.gui.characterMenu)) then
		if (IsValid(ix.gui.characterMenu.channel)) then
			ix.gui.characterMenu.channel:Stop()
		end

		ix.gui.characterMenu:Remove()
	end

	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)

	-- main menu panel
	self.mainPanel = self:Add("ixCharMenuMain")

	-- new character panel
	self.newCharacterPanel = self:Add("ixCharMenuNew")
	self.newCharacterPanel:SlideDown(0)

	-- load character panel
	self.loadCharacterPanel = self:Add("ixCharMenuLoad")
	self.loadCharacterPanel:SlideDown(0)

	-- notice bar
	self.notice = self:Add("ixNoticeBar")

	-- finalization
	self:MakePopup()
	self.currentAlpha = 255
	self.volume = 0

	ix.gui.characterMenu = self

	if (!IsValid(ix.gui.intro)) then
		self:PlayMusic()
	end

	hook.Run("OnCharacterMenuCreated", self)
end

function PANEL:PlayMusic()
	local path = "sound/" .. ix.config.Get("music")
	local url = path:match("http[s]?://.+")
	local play = url and sound.PlayURL or sound.PlayFile
	path = url and url or path

	play(path, "noplay", function(channel, error, message)
		if (!IsValid(channel)) then
			return
		end

		channel:SetVolume(self.volume or 0)
		channel:Play()

		self.channel = channel

		self:CreateAnimation(audioFadeInTime, {
			index = 10,
			target = {volume = 1},

			Think = function(animation, panel)
				if (IsValid(panel.channel)) then
					panel.channel:SetVolume(self.volume * 0.5)
				end
			end
		})
	end)
end

function PANEL:ShowNotice(type, text)
	self.notice:SetType(type)
	self.notice:SetText(text)
	self.notice:Show()
end

function PANEL:HideNotice()
	if (IsValid(self.notice) and !self.notice:GetHidden()) then
		self.notice:Slide("up", 0.5, true)
	end
end

function PANEL:OnCharacterDeleted(character)
	if (#ix.characters == 0) then
		self.mainPanel.loadButton:SetDisabled(true)
		self.mainPanel.loadButtonTitle:SetTextColor(Color(90, 90, 90, 255))
		self.mainPanel.loadButtonIcon:SetImageColor(Color(90, 90, 90, 255))
		self.mainPanel:Undim() -- undim since the load panel will slide down
	else
		self.mainPanel.loadButton:SetDisabled(false)
	end

	self.loadCharacterPanel:OnCharacterDeleted(character)
end

function PANEL:OnCharacterLoadFailed(error)
	self.loadCharacterPanel:SetMouseInputEnabled(true)
	self.loadCharacterPanel:SlideUp()
	self:ShowNotice(3, error)
end

function PANEL:IsClosing()
	return self.bClosing
end

function PANEL:Close(bFromMenu)
	self.bClosing = true
	self.bFromMenu = bFromMenu

	local fadeOutTime = animationTime * 8

	self:CreateAnimation(fadeOutTime, {
		index = 1,
		target = {currentAlpha = 0},

		Think = function(animation, panel)
			panel:SetAlpha(panel.currentAlpha)
		end,

		OnComplete = function(animation, panel)
			panel:Remove()
		end
	})

	self:CreateAnimation(fadeOutTime - 0.1, {
		index = 10,
		target = {volume = 0},

		Think = function(animation, panel)
			if (IsValid(panel.channel)) then
				panel.channel:SetVolume(self.volume * 0.5)
			end
		end,

		OnComplete = function(animation, panel)
			if (IsValid(panel.channel)) then
				panel.channel:Stop()
				panel.channel = nil
			end
		end
	})

	-- hide children if we're already dimmed
	if (bFromMenu) then
		for _, v in pairs(self:GetChildren()) do
			if (IsValid(v)) then
				v:SetVisible(false)
			end
		end
	else
		-- fade out the main panel quicker because it significantly blocks the screen
		self.mainPanel.currentAlpha = 255

		self.mainPanel:CreateAnimation(animationTime * 2, {
			target = {currentAlpha = 0},
			easing = "outQuint",

			Think = function(animation, panel)
				panel:SetAlpha(panel.currentAlpha)
			end,

			OnComplete = function(animation, panel)
				panel:SetVisible(false)
			end
		})
	end

	-- relinquish mouse control
	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
	gui.EnableScreenClicker(false)
end

function PANEL:Paint(width, height)
	surface.SetMaterial(Material(background_url))
	surface.SetDrawColor(255, 255, 255, 255)
	surface.DrawTexturedRect(0, 0, width, height)

	--[[surface.SetDrawColor(0, 0, 0, 150)
	surface.DrawTexturedRect(0, 0, width, height)
	ix.util.DrawBlur(self, Lerp((255 - 100) / 255, 0, 10))]]--
end

function PANEL:PaintOver(width, height)
	if (self.bClosing and self.bFromMenu) then
		surface.SetDrawColor(color_black)
		surface.DrawRect(0, 0, width, height)
	end
end

vgui.Register("ixCharMenu", PANEL, "EditablePanel")

if (IsValid(ix.gui.characterMenu)) then
	ix.gui.characterMenu:Remove()

	--TODO: REMOVE ME
	ix.gui.characterMenu = vgui.Create("ixCharMenu")
end