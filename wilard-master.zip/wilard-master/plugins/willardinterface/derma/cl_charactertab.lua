local PANEL = {}

function PANEL:Init()

	self:SetSize(ScrW(), ScrH())
	self:SetPos(-30, 0)
	
	self.Paint = function(self, w, h)
	end
	
	self.informationFrame = self:Add("DPanel")
	self.informationFrame:SetSize(530, 480)
	self.informationFrame:SetPos(ScrW() * 0.5 - 1060 * 0.5 - 35 + 18, 150)
	
	self.informationFrame.Paint = function( panel, width, height )
		surface.SetDrawColor(Color(255, 255, 255, 0));
	end
	
	local characterTitleIcon = self.informationFrame:Add("DImage")
	characterTitleIcon:SetImage("willardnetworks/tabmenu/charmenu/name.png")
	characterTitleIcon:SetSize(20, 20)
	characterTitleIcon:SetPos(0, 2)
	
	local characterTitle = self.informationFrame:Add("DLabel")
	characterTitle:SetFont("TitlesFont")
	characterTitle:SetText("Character")
	characterTitle:SetPos(27)
	characterTitle:SizeToContents()
	
	local informationSubframe = self.informationFrame:Add("DPanel")
	informationSubframe:SetSize(530, 449)
	informationSubframe:SetPos(0, 31)
	
	informationSubframe.Paint = function( panel, width, height )
		surface.SetDrawColor(Color(255, 255, 255, 30));
		surface.DrawOutlinedRect(0, 0, informationSubframe:GetWide(), informationSubframe:GetTall())
	end
	
	local informationTextFrame = informationSubframe:Add("DPanel")
	informationTextFrame:SetSize(462, 366)
	informationTextFrame:SetPos(35, 35)
	
	informationTextFrame.Paint = function( panel, width, height )
	end
	
	local textPadding = textPadding;
	
	for x = 1, 1 do
		for y = 1, 6 do
			local dividers = informationTextFrame:Add("DPanel")
			dividers:SetPos(0, (y - 1) * 52 + 30)
			dividers:SetSize(informationTextFrame:GetWide(), 1)
			dividers.Paint = function(self, w, h)
				surface.SetDrawColor(Color(255, 255, 255, 30))
				surface.DrawRect(0, 0, informationTextFrame:GetWide(), 1)
			end
		end
	end
	
	local nameIcon = informationTextFrame:Add("DImage")
	nameIcon:SetImage("willardnetworks/tabmenu/charmenu/name.png")
	nameIcon:SetSize(20, 20)
	
	local name = informationTextFrame:Add("DLabel")
	name:SetText("Name:")
	name:SetFont("SmallerTitleFontNoBold")
	name:SetPos(30, 0)
	name:SetTextColor(Color(255, 255, 255, 255))
	name:SizeToContents()
	
	local nameText = informationTextFrame:Add("DLabel")
	nameText:SetText(LocalPlayer():GetName())
	nameText:SetFont("SmallerTitleFontNoBold")
	nameText:SetPos(150, 0)
	nameText:SetTextColor(Color(220, 220, 220, 255))
	nameText:SizeToContents()
	
	local fakenameIcon = informationTextFrame:Add("DImage")
	fakenameIcon:SetImage("willardnetworks/tabmenu/charmenu/fakename.png")
	fakenameIcon:SetSize(20, 20)
	fakenameIcon:SetPos(0, 46)
	
	local fakename = informationTextFrame:Add("DLabel")
	fakename:SetText("Fake Name:")
	fakename:SetFont("SmallerTitleFontNoBold")
	fakename:SetPos(30, 46)
	fakename:SetTextColor(Color(255, 255, 255, 255))
	fakename:SizeToContents()
	
	self.fakenameText = informationTextFrame:Add("DLabel")
	self.fakenameText:SetText("--")
	self.fakenameText:SetFont("SmallerTitleFontNoBold")
	self.fakenameText:SetPos(150, 46)
	self.fakenameText:SetTextColor(Color(220, 220, 220, 255))
	self.fakenameText:SizeToContents()
	
	local editfakenameIcon = informationTextFrame:Add("DImageButton")
	editfakenameIcon:SetImage("willardnetworks/tabmenu/charmenu/edit_desc.png")
	editfakenameIcon:SetSize(20, 20)
	editfakenameIcon:SetPos(informationTextFrame:GetWide() - editfakenameIcon:GetWide(), 46)
	
	editfakenameIcon.DoClick = function()
		surface.PlaySound("helix/ui/press.wav")
		Derma_StringRequest(LocalPlayer():Name(), "Set your fake name", LocalPlayer():GetCharacter():GetData("fakename"), function(fakename)
			ix.command.Send("CharFakeName", fakename)
			
			if (!string.find(fakename, "%s")) then
				return
			end
			
			if string.len( fakename ) > 34 then
				local shortenedName = string.Left( fakename, 34 )
				self.fakenameText:SetText(shortenedName.."...")
			else
				self.fakenameText:SetText(fakename)
			end
		end)
	end
	
	local geneticDescIcon = informationTextFrame:Add("DImage")
	geneticDescIcon:SetImage("willardnetworks/tabmenu/charmenu/genetics.png")
	geneticDescIcon:SetSize(20, 20)
	geneticDescIcon:SetPos(0, 99)
	
	local geneticDesc = informationTextFrame:Add("DLabel")
	geneticDesc:SetText("Genetics:")
	geneticDesc:SetFont("SmallerTitleFontNoBold")
	geneticDesc:SetPos(30, 99)
	geneticDesc:SetTextColor(Color(255, 255, 255, 255))
	geneticDesc:SizeToContents()
	
	local geneticDescText = informationTextFrame:Add("DLabel")
	geneticDescText:SetText("--")
	geneticDescText:SetFont("SmallerTitleFontNoBold")
	geneticDescText:SetPos(150, 99)
	geneticDescText:SetTextColor(Color(255, 255, 255, 255))
	geneticDescText:SizeToContents()

	local descIcon = informationTextFrame:Add("DImage")
	descIcon:SetImage("willardnetworks/tabmenu/charmenu/description.png")
	descIcon:SetSize(20, 20)
	descIcon:SetPos(0, 150)
	
	local editdescIcon = informationTextFrame:Add("DImageButton")
	editdescIcon:SetImage("willardnetworks/tabmenu/charmenu/edit_desc.png")
	editdescIcon:SetSize(20, 20)
	editdescIcon:SetPos(informationTextFrame:GetWide() - editdescIcon:GetWide(), 150)
	
	local desc = informationTextFrame:Add("DLabel")
	desc:SetText("Description:")
	desc:SetFont("SmallerTitleFontNoBold")
	desc:SetPos(30, 150)
	desc:SetTextColor(Color(255, 255, 255, 255))
	desc:SizeToContents()
	
	local description = LocalPlayer():GetCharacter():GetDescription()
	
	self.descText = informationTextFrame:Add("DLabel")
	if string.len( description ) > 34 then
		local shortenedDesc = string.Left( description, 34 )
		self.descText:SetText(shortenedDesc.."...")
	else
		self.descText:SetText(description)
	end
	self.descText:SetFont("SmallerTitleFontNoBold")
	self.descText:SetPos(150, 150)
	self.descText:SetTextColor(Color(220, 220, 220, 255))
	self.descText:SizeToContents()
	
	editdescIcon.DoClick = function()
		surface.PlaySound("helix/ui/press.wav")
		Derma_StringRequest(LocalPlayer():Name(), "Set your Description", LocalPlayer():GetCharacter():GetDescription(), function(desc)
			ix.command.Send("CharDesc", desc)
			
			if (string.len( desc ) < ix.config.Get("minDescriptionLength")) then
				return
			end
			
			if (!string.find(desc, "%s")) then
				return
			end
			
			if string.len( desc ) > 34 then
				local shortenedDesc = string.Left( desc, 34 )
				self.descText:SetText(shortenedDesc.."...")
			else
				self.descText:SetText(desc)
			end
		end)
	end
	
	local cidIcon = informationTextFrame:Add("DImage")
	cidIcon:SetImage("willardnetworks/tabmenu/charmenu/cid.png")
	cidIcon:SetSize(20, 20)
	cidIcon:SetPos(0, 202)
	
	local citizenid = informationTextFrame:Add("DLabel")
	citizenid:SetText("Citizen ID:")
	citizenid:SetFont("SmallerTitleFontNoBold")
	citizenid:SetPos(30, 202)
	citizenid:SetTextColor(Color(255, 255, 255, 255))
	citizenid:SizeToContents()
	
	local function CitizenID()
		if (LocalPlayer():GetCharacter():GetData("cid")) then
			return LocalPlayer():GetCharacter():GetData("cid")
		else
			return "N/A"
		end
	end
	
	local citizenidText = informationTextFrame:Add("DLabel")
	citizenidText:SetText("#"..CitizenID())
	citizenidText:SetFont("SmallerTitleFontNoBold")
	citizenidText:SetPos(150, 202)
	citizenidText:SetTextColor(Color(220, 220, 220, 255))
	citizenidText:SizeToContents()
	
	local factionIcon = informationTextFrame:Add("DImage")
	factionIcon:SetImage("willardnetworks/tabmenu/charmenu/faction.png")
	factionIcon:SetSize(20, 20)
	factionIcon:SetPos(0, 254)
	
	local faction = informationTextFrame:Add("DLabel")
	faction:SetText("Faction:")
	faction:SetFont("SmallerTitleFontNoBold")
	faction:SetPos(30, 254)
	faction:SetTextColor(Color(255, 255, 255, 255))
	faction:SizeToContents()
	
	local faction = ix.faction.indices[LocalPlayer():GetCharacter():GetFaction()]
	
	local factionText = informationTextFrame:Add("DLabel")
	factionText:SetText(faction.name)
	factionText:SetFont("SmallerTitleFontNoBold")
	factionText:SetPos(150, 254)
	factionText:SetTextColor(Color(220, 220, 220, 255))
	factionText:SizeToContents()
	
	local licenseIcon = informationTextFrame:Add("DImage")
	licenseIcon:SetImage("willardnetworks/tabmenu/charmenu/licenses.png")
	licenseIcon:SetSize(20, 20)
	licenseIcon:SetPos(0, 302)
	
	local licenses = informationTextFrame:Add("DLabel")
	licenses:SetText("Licenses:")
	licenses:SetFont("SmallerTitleFontNoBold")
	licenses:SetPos(30, 302)
	licenses:SetTextColor(Color(255, 255, 255, 255))
	licenses:SizeToContents()
	
	local licensesText = informationTextFrame:Add("DLabel")
	licensesText:SetText("- Basic business license")
	licensesText:SetFont("SmallerTitleFontNoBold")
	licensesText:SetPos(30, 328)
	licensesText:SetTextColor(Color(220, 220, 220, 255))
	licensesText:SizeToContents()
	
	self.menuCharacterFrame = self:Add("DPanel")
	self.menuCharacterFrame:SetSize(530, 600)
	self.menuCharacterFrame:SetPos(ScrW() * 0.5 - 1060 * 0.5 + self.informationFrame:GetWide() + 18, 150)
	self.menuCharacterFrame.Paint = function( panel, width, height )
		surface.SetDrawColor(Color(255, 255, 255, 0));
	end

	local imgBackground = self.menuCharacterFrame:Add("DImage")
	imgBackground:SetImage("willardnetworks/tabmenu/inventory/char_bg.png")
	imgBackground:SetSize(362, 564)
	imgBackground:SetPos(0, 31)
	
	local statusArea = self.menuCharacterFrame:Add("DShape")
	statusArea:SetType( "Rect" )
	statusArea:SetSize( 240, imgBackground:GetTall() )
	statusArea:SetPos(imgBackground:GetWide(), 31)
	
	statusArea.Paint = function( panel, width, height )
		surface.SetDrawColor(Color(255, 255, 255, 10));
		surface.DrawRect(0, 0, 240, imgBackground:GetTall() )
	end
	
	self.model = self.menuCharacterFrame:Add("DModelPanel")
	self.model:SetSize(600, 600)
	self.model:SetPos(-118, 0)
	self.model:SetModel(LocalPlayer():GetModel())

	self.bodygroups = {}

	function self.model:LayoutEntity(Entity)
		Entity:SetAngles(Angle(0,45,0))
		local sequence = Entity:SelectWeightedSequence(ACT_IDLE)

		if (sequence <= 0) then
			sequence = Entity:LookupSequence("idle_unarmed")
		end

		if (sequence > 0) then
			Entity:ResetSequence(sequence)
		else
			local found = false

			for _, v in ipairs(Entity:GetSequenceList()) do
				if ((v:lower():find("idle") or v:lower():find("fly")) and v != "idlenoise") then
					Entity:ResetSequence(v)
					found = true

					break
				end
			end

			if (!found) then
				Entity:ResetSequence(4)
			end
		end
		
		Entity:SetIK(false)
		
		Entity:FrameAdvance(RealTime() * 0.5)
	end
	
	local currencyLabel = self.menuCharacterFrame:Add("DLabel")
	currencyLabel:SetPos(30, self.menuCharacterFrame:GetTall() - 70)
	currencyLabel:SetText("Currency")
	currencyLabel:SetTextColor( Color( 185, 185, 185, 255 ) )
	currencyLabel:SizeToContents()
	
	local tokensLabel = self.menuCharacterFrame:Add("DLabel")
	tokensLabel:SetPos(50, self.menuCharacterFrame:GetTall() - 50)
	tokensLabel:SetText("Tokens: "..LocalPlayer():GetCharacter():GetMoney())
	tokensLabel:SizeToContents()
end

vgui.Register("CharacterTab", PANEL, "DPanel")

hook.Add("CreateMenuButtons", "CharacterTab", function(tabs)
	tabs["Character"] = {
		
		RowNumber = 1,
		
		Width = 17,
		
		Height = 19,
	
		Icon = "willardnetworks/tabmenu/navicons/character.png",
	
		Create = function(info, container)
			local panel = container:Add("CharacterTab")
			ix.gui.characterpanel = panel
		end
	}
end)