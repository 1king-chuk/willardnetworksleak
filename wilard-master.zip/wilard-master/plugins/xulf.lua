
local PLUGIN = PLUGIN

PLUGIN.name = "Xulf"
PLUGIN.author = "Gary"
PLUGIN.description = "Vortigaunt xulf communication."

ix.chat.Register("xulf", {
	format = "%s telepathically says \"%s\"",
	color = Color(138, 181, 40),
	deadCanChat = false,
	OnChatAdd = function(self, speaker, text, bAnonymous, data)
		format = data.format or self.format

		chat.AddText(self.color, string.format(format, speaker:Name(), text))
	end
})

ix.command.Add("Xulf", {
	description = "@cmdXulf",
	arguments = {
		ix.type.text
	},
	OnCheckAccess = function(self, client)
		return client:Team() == FACTION_VORT
	end,
	OnRun = function(self, client, message)
		local receivers = {}
		for _, v in ipairs(player.GetAll()) do
			if v:Team() == FACTION_VORT then
				table.insert(receivers, v)
			end
		end

		ix.chat.Send(client, "xulf", message, false, receivers)
	end
})

ix.command.Add("XulfDirect", {
	description = "@cmdXulfDirect",
	arguments = {
		ix.type.character,
		ix.type.text
	},
	OnCheckAccess = function(self, client)
		return client:Team() == FACTION_VORT
	end,
	OnRun = function(self, client, target, message)
		if !(target:GetPlayer():Team() == FACTION_VORT) then
			return "@notVort"
		end

		ix.chat.Send(client, "xulf", message, false, {client, target}, {format = "%s telepathically says directly \"%s\""})
	end
})
