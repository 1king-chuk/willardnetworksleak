
LANGUAGE = {
	paper = "Paper"
}
