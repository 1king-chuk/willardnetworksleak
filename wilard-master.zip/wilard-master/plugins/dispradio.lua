
PLUGIN.name = "Dispatch Radio"
PLUGIN.author = "SleepyMode"
PLUGIN.description = "Adds the /c command."

do
	local CLASS = {}
	CLASS.color = Color(200, 0, 0)
	CLASS.format = "Dispatch radios on command \"%s\""

	function CLASS:CanSay(speaker, text)
		if (!speaker:IsDispatch()) then
			speaker:NotifyLocalized("notAllowed")

			return false
		end
	end

	function CLASS:CanHear(speaker, listener)
		return listener:IsCombine()
	end

	function CLASS:OnChatAdd(speaker, text)
		chat.AddText(self.color, string.format(self.format, text))
	end

	ix.chat.Register("dispatch_radio", CLASS)
end

do
	local COMMAND = {}
	COMMAND.arguments = ix.type.text

	function COMMAND:OnRun(client, message)
		if (!client:IsRestricted()) then
			ix.chat.Send(client, "dispatch_radio", message)
		else
			return "@notNow"
		end
	end

	ix.command.Add("C", COMMAND)
end