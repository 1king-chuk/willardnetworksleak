surface.CreateFont("SkillTitleFont", {
	font = "Roboto",
	size = 32,
	weight = 700
})

surface.CreateFont("SkillSubTextFont", {
	font = "Roboto",
	size = 20,
	weight = 0
})

surface.CreateFont("SkillPanelTitle", {
	font = "Roboto",
	size = ScreenScale(24),
	weight = 1000
})

surface.CreateFont("SkillSubPanelTitle", {
	font = "Roboto",
	size = ScreenScale(12),
	weight = 0
})

surface.CreateFont("SkillIcon", {
	font = "fontello",
	extended = true,
	size = ScreenScale(64),
	weight = 500
})

local PANEL = {}

function PANEL:Init()
	self.index = 0
	self.skill = nil

	self.backgroundIMG = self:Add("DImage")
	self.backgroundIMG:Dock(FILL)
	self.backgroundIMG:SetImage("willardnetworks/tabmenu/crafting/box_pattern.png")
	self.backgroundIMG:SetImageColor(Color(150,150,150,20))
	self.backgroundIMG:SetKeepAspect(true)
	self.backgroundIMG.PaintOver = function(this, width, height)
		surface.SetDrawColor(Color(0, 0, 0, 50))
		surface.DrawRect(0, 0, width, height)
	end

	--[[
		Selection Panel
	--]]

	self.selectionPanel = self:Add("Panel")
	self.selectionPanel:Dock(FILL)
	self.selectionPanel:SetVisible(false)

	for k, v in pairs(ix.skills.list) do
		local button = self.selectionPanel:Add("ixMenuButton")
		button:DockMargin(10,10,10,0)
		button:SetFont("SkillTitleFont")
		button:SetText(v.name)
		button:Dock(TOP)

		button.DoClick = function(this)
			if (!table.HasValue(LocalPlayer():GetCharacter():GetActiveSkills(), k)) then
				self:SetSkill(k, self.index)

				self.selectionPanel:SetVisible(false)
			end
		end
	end

	local closeButton = self.selectionPanel:Add("ixMenuButton")
	closeButton:DockMargin(10,0,10,10)
	closeButton:SetFont("SkillTitleFont")
	closeButton:SetText("CLOSE")
	closeButton:Dock(BOTTOM)

	closeButton.DoClick = function(this)
		self.selectionPanel:SetVisible(false)

		if (self.skill) then
			self.skillPanel:SetVisible(true)
		else
		    self.emptyPanel:SetVisible(true)
		end
	end

	--[[
		Empty Panel
	--]]

	self.emptyPanel = self:Add("Panel")
	self.emptyPanel:Dock(FILL)
	self.emptyPanel:SetVisible(true)
	self.emptyPanel.OnMousePressed = function(this)
		self.selectionPanel:SetVisible(true)
		self.emptyPanel:SetVisible(false)
	end

	local emptyPlus = self.emptyPanel:Add("DLabel")
	emptyPlus:Dock(FILL)
	emptyPlus:SetFont("SkillIcon")
	emptyPlus:SetText("I")
	emptyPlus:SetContentAlignment(5)

	--[[
		Skill Panel
	--]]

	self.skillPanel = self:Add("Panel")
	self.skillPanel:Dock(FILL)
	self.skillPanel:SetVisible(false)
	self.skillPanel.OnMousePressed = function(this)
		if (ix.gui.skills.panels[ix.skills.list[self.skill].name]) then
			ix.gui.skills:Remove()

			ix.gui.skills.panels[ix.skills.list[self.skill].name](ix.gui.skills:GetParent())
		end
	end

	self.skillIMG = self.skillPanel:Add("DImage")
	self.skillIMG:SetKeepAspect(true)
	self.skillIMG:Dock(FILL)

	self.skillName = self.skillPanel:Add("DLabel")
	self.skillName:Dock(FILL)
	self.skillName:DockMargin(0, 0, 0, 64)
	self.skillName:SetContentAlignment(5)
	self.skillName:SetFont("SkillPanelTitle")
	self.skillName.Paint = function(this, width, height)
	end

	self.skillLVL = self.skillPanel:Add("DLabel")
	self.skillLVL:Dock(FILL)
	self.skillLVL:DockMargin(0, 64, 0, 0)
	self.skillLVL:SetContentAlignment(5)
	self.skillLVL:SetTextColor(Color(255, 204, 0))
	self.skillLVL:SetFont("SkillSubPanelTitle")
	self.skillLVL.Paint = function(this, width, height)
	end

	local replaceButton = self.skillPanel:Add("DButton")
	replaceButton:SetText("Replace")
	replaceButton:SetFont("SkillSubTextFont")
	replaceButton:SetTall(38)
	replaceButton:DockMargin(200, 664, 200, 50)
	replaceButton:Dock(FILL)
	replaceButton.DoClick = function(this)
		self.selectionPanel:SetVisible(!self.selectionPanel:IsVisible())
		self.skillPanel:SetVisible(false)
	end
	replaceButton.Paint = function(this, width, height)
		surface.SetDrawColor(Color(255, 78, 69))
		surface.DrawRect(0, 0, width, height)
	end
end

function PANEL:SetSkill(skill, index)
	if (skill and ix.skills.list[skill]) then
		self.index = index
		self.skill = skill

		self.skillPanel:SetVisible(true)
		self.emptyPanel:SetVisible(false)

		self.skillName:SetText(ix.skills.list[skill].name:upper() or "Unknown")

		self.skillLVL:SetText("Skill level "..LocalPlayer():GetCharacter():GetSkill(skill, 0).."/"..(ix.skills.list[skill].maxValue or 150))

		if (ix.skills.list[skill].background) then
			self.backgroundIMG:SetImage(ix.skills.list[skill].background)
			self.backgroundIMG:SetImageColor(Color(255,255,255))
			self.backgroundIMG.PaintOver = function(this, width, height)
			end
		else
		    self.backgroundIMG:SetImage("willardnetworks/tabmenu/crafting/box_pattern.png")
			self.backgroundIMG:SetImageColor(Color(150,150,150,20))
			self.backgroundIMG.PaintOver = function(this, width, height)
				surface.SetDrawColor(Color(0, 0, 0, 50))
				surface.DrawRect(0, 0, width, height)
			end
		end

		net.Start("ixActiveSkill")
			net.WriteString(skill)
			net.WriteUInt(index, 8)
		net.SendToServer()
	else
		self.index = index
		self.skill = nil

	    self.skillPanel:SetVisible(false)
		self.emptyPanel:SetVisible(true)
	end

	return true
end

function PANEL:Paint(width, height)
end

function PANEL:PaintOver(width, height)
	surface.SetDrawColor(Color(100, 100, 100, 150))
	surface.DrawOutlinedRect(0, 0, width, height)
end

vgui.Register("ixSkillPanel", PANEL, "EditablePanel")

PANEL = {}

function PANEL:Init()
	if (IsValid(ix.gui.skills)) then
		ix.gui.skills:Remove()
	end

	ix.gui.skills = self

	local scrW = ScrW()

	self:Dock(FILL)
	self:DockMargin(128, 80, 128, 80)
	self:SetSize(self:GetParent():GetSize())

	self.panels = {}

	hook.Run("CreateSkillPanels", self.panels)

	local dockL, dockT, dockR, dockB = self:GetDockMargin()

	local title = self:Add("DLabel")
	title:SetFont("SkillTitleFont")
	title:SetText(LocalPlayer():Name().."'s Skills")
	title:Dock(TOP)
	title:SizeToContents()

	local subText = self:Add("DLabel")
	subText:SetTextColor(Color(255,255,255,150))
	subText:SetFont("SkillSubTextFont")
	subText:SetText("Only 3 skills can be active at any time, but you can swap\nthem out at any moment. Replaced skills reset their level.")
	subText:Dock(TOP)
	subText:SizeToContents()

	local skillPanel = self:Add("Panel")
	skillPanel:DockMargin(0, 32, 0, 32)
	skillPanel:Dock(FILL)

	local skills = {}

	for i = 1, 3 do
		local skill = skillPanel:Add("ixSkillPanel")
		skill:DockMargin(0, 0, 32, 0)
		skill:Dock(LEFT)
		skill:SetWide((self:GetWide()-(dockL*2))/3-32)

		skill:SetSkill(LocalPlayer():GetCharacter():GetActiveSkills()[i], i)

		skills[i] = skill
	end
end

vgui.Register("ixSkillsMenu", PANEL, "EditablePanel")

hook.Add("CreateMenuButtons", "ixSkillsMenu", function(tabs)
	tabs["skills"] = {
		RowNumber = 2,

		Width = 18,

		Height = 18,

		Icon = "willardnetworks/tabmenu/navicons/crafting.png",

		Create = function(info, container)
			container:Add("ixSkillsMenu")
		end
	}
end)
