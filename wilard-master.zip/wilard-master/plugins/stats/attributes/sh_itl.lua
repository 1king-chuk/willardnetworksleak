ATTRIBUTE.name = "Intelligence"
ATTRIBUTE.description = "Your general intellect."
ATTRIBUTE.skills = {"brt", "ckn", "chm"}
