ATTRIBUTE.name = "Perception"
ATTRIBUTE.description = "Your perception of the world around you."
ATTRIBUTE.skills = {"cft", "ckn", "gun"}
