ATTRIBUTE.name = "Strength"
ATTRIBUTE.description = "Your bodily strength."
ATTRIBUTE.skills = {"mel", "spd"}
