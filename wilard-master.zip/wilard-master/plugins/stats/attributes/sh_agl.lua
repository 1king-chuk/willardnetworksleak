ATTRIBUTE.name = "Agility"
ATTRIBUTE.description = "Your ability to be agile."
ATTRIBUTE.skills = {"gun", "spd"}
