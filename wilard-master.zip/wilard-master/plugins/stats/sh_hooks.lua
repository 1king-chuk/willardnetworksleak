local PLUGIN = PLUGIN

PLUGIN.disabledPlugins = {
	"stamina",
	"strength"
}

function PLUGIN:PluginShouldLoad(uniqueID)
	return !self.disabledPlugins[uniqueID]
end

function PLUGIN:GetDefaultAttributePoints(client, count)
	return 6
end
