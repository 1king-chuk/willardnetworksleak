local PLUGIN = PLUGIN

PLUGIN.name = "Character Stats"
PLUGIN.author = "Willard Networks"
PLUGIN.description = "Adds an indepth character stat system."

ix.util.Include("sh_hooks.lua")
