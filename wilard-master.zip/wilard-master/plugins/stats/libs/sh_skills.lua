
ix.skills = ix.skills or {}
ix.skills.list = ix.skills.list or {}

function ix.skills.LoadFromDir(directory)
	for _, v in ipairs(file.Find(directory.."/*.lua", "LUA")) do
		local niceName = v:sub(4, -5)

		SKILL = ix.skills.list[niceName] or {}
			if (PLUGIN) then
				SKILL.plugin = PLUGIN.uniqueID
			end

			ix.util.Include(directory.."/"..v)

			SKILL.name = SKILL.name or "Unknown"
			SKILL.description = SKILL.description or "No description availalble."

			ix.skills.list[niceName] = SKILL
		SKILL = nil
	end
end

function ix.skills.Setup(client)
	local character = client:GetCharacter()

	if (character) then
		for k, v in pairs(ix.skills.list) do
			if (v.OnSetup) then
				v:OnSetup(client, character:GetSkill(k, 0, false))
			end
		end
	end
end

do
	local CHAR = ix.meta.character

	if (SERVER) then
		util.AddNetworkString("ixSkillUpdate")
		util.AddNetworkString("ixActiveSkill")

		function CHAR:UpdateSkill(key, value)
			local skill = ix.skills.list[key]
			local client = self:GetPlayer()

			print("test")

			if (skill and table.HasValue(self:GetActiveSkills(), key)) then
				local skl = self:GetSkills()

				skl[key] = math.min((skl[key] or 0) + value, skill.maxValue or 150)

				if (IsValid(client)) then
					net.Start("ixSkillUpdate")
						net.WriteUInt(self:GetID(), 32)
						net.WriteString(key)
						net.WriteFloat(skl[key])
					net.Send(client)

					if (skill.Setup) then
						skill.Setup(skl[key])
					end
				end

				self:SetSkills(skl)

				hook.Run("CharacterSkillUpdated", client, self, key, value)
			end
		end

		function CHAR:SetSkill(key, value)
			local skill = ix.skills.list[key]
			local client = self:GetPlayer()

			if (skill) then
				local skl = self:GetSkills()

				skl[key] = value

				if (IsValid(client)) then
					net.Start("ixSkillUpdate")
						net.WriteUInt(self:GetID(), 32)
						net.WriteString(key)
						net.WriteFloat(skl[key])
					net.Send(client)

					if (skill.Setup) then
						skill.Setup(skl[key])
					end
				end

				self:SetSkills(skl)

				hook.Run("CharacterSkillUpdated", client, self, key, value)
			end
		end

		function CHAR:SetActiveSkill(key, index)
			local activeSkills = self:GetActiveSkills()

			local curSkill = activeSkills[index] or nil

			if (curSkill) then
				if (curSkill == key) then return end

				self:SetSkill(curSkill, self:GetSkill(curSkill, 0, true))

				activeSkills[index] = key
			else
			    activeSkills[index] = key
			end

			self:SetData("activeskills", activeSkills)
		end

		net.Receive("ixActiveSkill", function(length, client)
			local character = client:GetCharacter()

			if (character) then
				local key = net.ReadString()
				local index = net.ReadUInt(8)

				character:SetActiveSkill(key, index)
			end
		end)
	else
	    net.Receive("ixSkillUpdate", function()
			local id = net.ReadUInt(32)
			local character = ix.char.loaded[id]

			if (character) then
				local key = net.ReadString()
				local value = net.ReadFloat()

				character:GetSkills()[key] = value
			end
		end)
	end

	function CHAR:GetSkill(key, default, bNoLVL)
		if (!bNoLVL) then
			return self:GetSkills()[key] or default or 0
		else
			for att, tbl in pairs(ix.attributes.list) do
				if (table.HasValue(tbl.skills, key)) then
					default = default + (5 * self:GetAttribute(att, 0))
				end
			end

			return default or 0
		end
	end

	function CHAR:GetActiveSkills()
		return self:GetData("activeskills", {})
	end
end

ix.char.RegisterVar("skills", {
	field = "skills",
	fieldType = ix.type.text,
	default = {},
	index = 5,
	category = "attributes",
	isLocal = true,
	OnDisplay = function(self, container, payload)
		local skills = container:Add("DPanel")
		skills:Dock(TOP)

		local bars = {}
		local y = 0
		payload.skills = {}

		payload:AddHook("skills", function(value)
			for k, v in pairs(bars) do
				if (value[k] and IsValid(v)) then
					v:SetValue(value[k])
				end
			end
		end)

		for k, v in SortedPairsByMemberValue(ix.skills.list, "name") do
			payload.skills[k] = 0

		 	local bar = skills:Add("ixAttributeBar")
			bar:SetMax(v.maxValue or 150)
			bar:SetReadOnly()
			bar:Dock(TOP)
			bar:DockMargin(2, 2, 2, 2)
			bar:SetText(L(v.name))

			bars[k] = bar

			y = y + bar:GetTall() + 4
		end

		skills:SetTall(y)
		return skills
	end,
	OnValidate = function(self, value, data, client)
		if (value != nil) then
			if (istable(value)) then
				for _, v in pairs(value) do
					if (v > 150) then
						return false, "unknownError"
					end
				end
			else
				return false, "unknownError"
			end
		end
	end,
	ShouldDisplay = function(self, container, payload)
		return !table.IsEmpty(ix.skills.list)
	end
})

ix.char.vars["attributes"].OnDisplay = function(self, container, payload)
	local maximum = hook.Run("GetDefaultAttributePoints", LocalPlayer(), payload) or ix.config.Get("maxAttributes", 30)

	if (maximum < 1) then
		return
	end

	local attributes = container:Add("DPanel")
	attributes:Dock(TOP)

	local y
	local total = 0

	payload.attributes = {}

	-- total spendable attribute points
	local totalBar = attributes:Add("ixAttributeBar")
	totalBar:SetMax(maximum)
	totalBar:SetValue(maximum)
	totalBar:Dock(TOP)
	totalBar:DockMargin(2, 2, 2, 2)
	totalBar:SetText(L("attribPointsLeft"))
	totalBar:SetReadOnly(true)
	totalBar:SetColor(Color(20, 120, 20, 255))

	y = totalBar:GetTall() + 4

	for k, v in SortedPairsByMemberValue(ix.attributes.list, "name") do
		payload.attributes[k] = 0

		local bar = attributes:Add("ixAttributeBar")
		bar:SetMax(maximum)
		bar:Dock(TOP)
		bar:DockMargin(2, 2, 2, 2)
		bar:SetText(L(v.name))
		bar.OnChanged = function(this, difference)
			if ((total + difference) > maximum) then
				return false
			end

			total = total + difference
			payload.attributes[k] = payload.attributes[k] + difference

			totalBar:SetValue(totalBar.value - difference)

			if (v.skills and payload.skills) then
				for _, skill in pairs(v.skills) do
					if (!payload.skills[skill]) then continue end
					local newValue = (payload.skills[skill] or 0) + (5 * difference)

					local newTab = payload.skills or {}
					newTab[skill] = newValue

					payload:Set("skills", newTab)
				end
			end
		end

		if (v.noStartBonus) then
			bar:SetReadOnly()
		end

		y = y + bar:GetTall() + 4
	end

	attributes:SetTall(y)
	return attributes
end

ix.skills.LoadFromDir(Schema.folder.."/plugins/stats/skills")
