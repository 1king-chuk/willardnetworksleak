SKILL.name = "Cooking"
