SKILL.name = "Speed"
