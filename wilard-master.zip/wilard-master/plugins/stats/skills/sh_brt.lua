SKILL.name = "Bartering"
