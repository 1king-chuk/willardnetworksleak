SKILL.name = "Crafting"
SKILL.background = "willardnetworks/backgrounds/workers_bg.jpg"
