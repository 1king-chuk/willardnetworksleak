
local PLUGIN = PLUGIN
local RECIPE = PLUGIN.recipe:New()

RECIPE.name = "No subcategory"
RECIPE.uniqueID = "no_subcategory"
RECIPE.model = "models/props_junk/PopCan01a.mdl"
RECIPE.category = "No Subcategory"
RECIPE.description = "By smelting some cans, you can create pieces of metal used for things."
RECIPE.ingredients = {["water"] = 3}
RECIPE.result = {["piece_of_metal"] = 1}
RECIPE.hidden = false

RECIPE:Register()