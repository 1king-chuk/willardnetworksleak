
local PLUGIN = PLUGIN
local RECIPE = PLUGIN.recipe:New()

RECIPE.name = "Breakdown: Breen's Water Cans"
RECIPE.uniqueID = "new_breens_water"
RECIPE.model = "models/props_junk/PopCan01a.mdl"
RECIPE.category = "Gay"
RECIPE.subcategory = "Breakdown"
RECIPE.description = "By smelting some cans, you can create pieces of metal used for things."
RECIPE.ingredients = {["metropolice_supplements"] = 5, ["water"] = 2}
RECIPE.result = {["piece_of_metal"] = 1}
RECIPE.hidden = false

RECIPE:Register()