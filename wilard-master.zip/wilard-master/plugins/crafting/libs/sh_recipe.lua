
local PLUGIN = PLUGIN

PLUGIN.recipe = {}
PLUGIN.recipe.stored = {}

--[[
	Begin defining the recipe class base for other recipe's to inherit from.
--]]

--[[ Set the __index meta function of the class. --]]
local CLASS_TABLE = {__index = CLASS_TABLE}

CLASS_TABLE.name = "Blueprint Base"
CLASS_TABLE.uniqueID = "blueprint_base"
CLASS_TABLE.skin = 0
CLASS_TABLE.model = "models/error.mdl"
CLASS_TABLE.category = "Other"
CLASS_TABLE.description = "A recipe with no description."

-- Called when the recipe is converted to a string.
function CLASS_TABLE:__tostring()
	return "RECIPE["..self.name.."]"
end

--[[
	A function to override an recipe's base data. This is
	just a nicer way to set a value to go along with
	the method of querying.
--]]
function CLASS_TABLE:Override(varName, value)
	self[varName] = value
end

-- A function to register a new recipe.
function CLASS_TABLE:Register()
	return PLUGIN.recipe:Register(self)
end

function CLASS_TABLE:PlayerCanCraftRecipe(client)
	return PLUGIN.recipe:PlayerCanCraftRecipe(self, client)
end

--[[
	End defining the base recipe class.
	Begin defining the recipe utility functions.
--]]

-- A function to get all recipes.
function PLUGIN.recipe:GetAll()
	return self.stored
end

-- A function to get a new recipe.
function PLUGIN.recipe:New(recipe)
	local object = {}
		setmetatable(object, CLASS_TABLE)
		CLASS_TABLE.__index = CLASS_TABLE
	return object
end

-- A function to register a new recipe.
function PLUGIN.recipe:Register(recipe)
	recipe.uniqueID = string.lower(string.gsub(recipe.uniqueID or string.gsub(recipe.name, "%s", "_"), "['%.]", ""))
	self.stored[recipe.uniqueID] = recipe
	
	if (recipe.model) then
		util.PrecacheModel(recipe.model)
		
		if (SERVER) then
			resource.AddFile(recipe.model)
		end
	end
end

-- A function to get an recipe by its name.
function PLUGIN.recipe:FindByID(identifier)
	if (identifier and identifier != 0 and type(identifier) != "boolean") then
		if (self.stored[identifier]) then
			return self.stored[identifier]
		end
		
		local lowerName = string.lower(identifier)
		local recipe = nil
		
		for k, v in pairs(self.stored) do
			local recipeName = v.name
			
			if (string.find(string.lower(recipeName), lowerName)
			and (!recipe or string.len(recipeName) < string.len(recipe.name))) then
				recipe = v
			end
		end
		
		return recipe
	end
end

function PLUGIN.recipe:Initialize()
	local recipes = self:GetAll()

	for k, v in pairs(recipes) do
		if (v.OnSetup) then 
			v:OnSetup() 
		end
	end
end

-- Called when a player attempts to craft an item.
function PLUGIN.recipe:PlayerCanCraftRecipe(recipe, client, inventory)
	local character = client:GetCharacter()
	local inventory = inventory or character:GetInventory()
	-- Check if the player has all the needed tools if there are any needed
	if (recipe.tools) then
		for k, tool in pairs(recipe.tools) do
			if (!inventory:HasItem(tool)) then
				for _, v in pairs(ix.item.list) do
					if (v) and (v == tool) then
						return false, "You do not have a "..v.name.."."
					else
						ErrorNoHalt("[Crafting] Recipe "..recipe.name.." has an unexisting tool "..tool.."!\n")
						return false, "Recipe has unexisting tool "..tool.."!"
					end
				end
			end
		end
	end
	
	-- Check for the ingredients
	if (recipe.ingredients) then
		for ingredient, amount in pairs(recipe.ingredients) do
			local function CharIngredientAmount()
				local count = {}
				local items = client:GetCharacter():GetInventory():GetItems()
				
				if (!table.IsEmpty(count)) then
					table.remove(count)
				end
				
				for _, v in pairs(items) do
					if v.uniqueID == ingredient then
						table.insert(count, v)
					end
				end
				
				return table.Count( count ) or 0
			end
		
			if (!inventory:HasItem(ingredient)) then
				if ix.item.list[ingredient] then
					return false, "You do not have any "..ix.item.list[ingredient].name.."."
				else
					ErrorNoHalt("[Crafting] Recipe "..recipe.name.." has an unexisting ingredient "..ingredient.."!\n")
					return false, "Recipe has unexisting ingredient "..ingredient.."!"
				end
				
			elseif (CharIngredientAmount() < amount) then
				if ix.item.list[ingredient] then
					local name = ingredient
					if (amount > 1) then
						name = PLUGIN:Pluralize(ix.item.list[ingredient].name)
					end
					return false, "You need at least "..tostring(amount).." "..name.."."
				else
					ErrorNoHalt("[Crafting] Recipe "..recipe.name.." has an unexisting ingredient "..ingredient.."!\n")
					return false, "Recipe has unexisting ingredient "..ingredient.."!"
				end
			end
		end
	end

	-- Check if player is near a crafting station if needed
	if (recipe.station) then
		if ix.item.list[recipe.station] then
			-- Find the entity the player is looking at
			local entity = client:GetEyeTraceNoCursor().Entity
			local failReason = "You need to be near and looking at a "..ix.item.list[recipe.station].name
			
			if (IsValid(entity)) then
				if (entity:GetClass() != "ix_item") then
					return false, failReason
				else
					local itemTable = entity:GetItemTable()
					if (!itemTable or itemTable.uniqueID != recipe.station) then
						return false, failReason
					end
					if (client:GetShootPos():Distance(entity:GetPos()) > 100) then
						return false, failReason
					end
				end
			else
				return false, failReason
			end
		end
	end
	
	-- Check if player has the crafting license if needed
	if (recipe.license) then
		if (!inventory:HasItem(recipe.license)) then
			if ix.item.list[recipe.license] then
				return false, "You do not have a "..ix.item.list[recipe.license].name.."."
			end
		end
	end

	-- Check if the player has the correct skills
	if (recipe.skills) then
		for k, v in ipairs(recipe.skills) do
			if (character:GetSkill(k) < v) then
				return false, "You're missing the required skills to craft this."
			end
		end
	end

	return true
end

if (CLIENT) then
	function PLUGIN.recipe:GetIconInfo(recipe)
		local model = recipe.model or "models/error.mdl"
		local skin = recipe.skin
		
		return model, skin
	end

	function PLUGIN.recipe:CanPlayerSeeRecipe(recipe)
		if (recipe.hidden) then
			return false
		end

		return true
	end
else
	function PLUGIN.recipe:PlayerCraftRecipe(recipe, client)
		-- Take all the ingredients
		local item = nil
		for ingredient, amount in pairs(recipe.ingredients) do
			for i = 1, amount do
				item = client:GetCharacter():GetInventory():HasItem(ingredient)
				if (item) then item:Remove() else break end
			end
		end
		-- Give the result
		for result, amount in pairs(recipe.result) do
			local actualAmount
			if (type(amount) == "table") then
				actualAmount = amount[math.random(1, #amount)]
			else
				actualAmount = amount
			end

			for i = 1, actualAmount do
				client:GetCharacter():GetInventory():Add(result)
			end
		end
		-- Set the player's next crafting time
		client.ixNextCraftTime = CurTime() + 2
		netstream.Start("CraftTime", client.ixNextCraftTime)
	end
end