local PLUGIN = PLUGIN

PLUGIN.name = "Crafting"
PLUGIN.author = "Gr4ss, Fruity"
PLUGIN.description = "The crafting system for Willard Industries."

ix.util.IncludeDir("ixhl2rp/plugins/crafting/recipes", true)

function PLUGIN:IsVowel(letter)
	letter = stringLower(letter);
	return (letter == "a" or letter == "e" or letter == "i"
	or letter == "o" or letter == "u");
end;

function PLUGIN:Pluralize(text)
	if (string.sub(text, -2) != "fe") then
		local lastLetter = string.sub(text, -1)
		
		if (lastLetter == "y") then
			if (self:IsVowel(string.sub(text, stringLen(text) - 1, 2))) then
				return string.sub(text, 1, -2).."ies"
			else
				return text.."s"
			end
		elseif (lastLetter == "h") then
			return text.."es"
		elseif (lastLetter != "s") then
			return text.."s"
		else
			return text
		end
	else
		return string.sub(text, 1, -3).."ves"
	end
end

if (CLIENT) then
	netstream.Hook("RebuildCrafting", function(data)
		PLUGIN.craftingPanel:Rebuild()
	end)

	netstream.Hook("CraftTime", function(data)
		ix.CraftCooldown = data
		
		activePanel:Rebuild()
	end)

	-- Called when the local player's crafting is rebuilt.
	function PLUGIN:PlayerCraftingRebuilt(panel, categories) end

	-- Called when the local player's crafting item should be adjusted.
	function PLUGIN:PlayerAdjustCraftingRecipe(recipe) end
else
	netstream.Hook("CraftRecipe", function(client, data)
		local recipe = data

		local bPlayerCanCraft, err = PLUGIN:PlayerCanCraft(client)

		if (!bPlayerCanCraft) then
			if (!err) then
				err = "You cannot craft right now (but a Dev fucked up and forgot to add in why)!"
			end
			client:NotifyLocalized(err)
			return false
		end

		local bCanCraftRecipe, err = PLUGIN.recipe:PlayerCanCraftRecipe(recipe, client)

		if (!bCanCraftRecipe) then
			if (!err) then
				err = "You cannot craft this (but a Dev fucked up and forgot to add in why)!"
			end
			client:NotifyLocalized(err)
			return false
		end

		PLUGIN.recipe:PlayerCraftRecipe(recipe, client)
		client:NotifyLocalized("You've successfully crafted something")

	end)

	function PLUGIN:PlayerCanCraft(client)
		-- Check if the player has waited long enough for the next craft time
		local curTime = CurTime()
		if (client.ixNextCraftTime and curTime < client.ixNextCraftTime) then
			return false, "You need to wait "..tostring(client.ixNextCraftTime - curTime).." seconds."
		end

		return true
	end

	-- Called when a player's crafted item should be adjusted.
	function PLUGIN:PlayerAdjustCraftRecipe(client, recipe) end
end