
ITEM.name = "Furnace"
ITEM.model = "models/props/CS_militia/furnace01.mdl"
ITEM.uniqueID = "furnace"
ITEM.craftingStation = true
ITEM.category = "Crafting Station"
ITEM.description = "A furnace."