
ITEM.name = "Piece of Metal"
ITEM.uniqueID = "piece_of_metal"
ITEM.model = "models/gibs/manhack_gib01.mdl"
ITEM.category = "Junk"
ITEM.description = "A small piece of metal."