
local PLUGIN = PLUGIN
local pairs = pairs
local table = table
local vgui = vgui
local math = math

local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()
	self:SetSize(1240, 600)
	self:SetPos(0, 30)
	
	self.recipes = vgui.Create( "DScrollPanel", self)
	self.recipes:Dock(LEFT)
	self.recipes:DockMargin(0, 0, 20, 0)
	self.recipes:SetSize(400, 600)
	self.recipes.Paint = function(self, w, h) 
		surface.SetDrawColor(Color(0, 0, 0, 50))
		surface.DrawRect(0, 0, w, h)
		
		surface.SetDrawColor(Color(150, 150, 150, 20))
		surface.SetMaterial(Material("willardnetworks/tabmenu/crafting/box_pattern.png"))
		surface.DrawTexturedRect(0, 0, w, h)
		
		surface.SetDrawColor(Color(100, 100, 100, 150))
		surface.DrawOutlinedRect(0, 0, w, h)
	end
	
	self.crafting = vgui.Create( "DScrollPanel", self)
	self.crafting:Dock(LEFT)
	self.crafting:DockMargin(0, 0, 20, 0)
	self.crafting:SetSize(400, 600)
	self.crafting.Paint = function(self, w, h) 
		surface.SetDrawColor(Color(0, 0, 0, 50))
		surface.DrawRect(0, 0, w, h)
		
		surface.SetDrawColor(Color(150, 150, 150, 20))
		surface.SetMaterial(Material("willardnetworks/tabmenu/crafting/box_pattern.png"))
		surface.DrawTexturedRect(0, 0, w, h)
		
		surface.SetDrawColor(Color(100, 100, 100, 150))
		surface.DrawOutlinedRect(0, 0, w, h)
	end
	
	self.crafting.EmptyText = vgui.Create( "DLabel", self.crafting)
	self.crafting.EmptyText:SetFont("MenuFontBold")
	self.crafting.EmptyText:SetText("No item/recipe selected")
	self.crafting.EmptyText:SizeToContents()
	self.crafting.EmptyText:SetPos(self.crafting:GetWide() * 0.5 - self.crafting.EmptyText:GetWide() * 0.5, self.crafting:GetTall() * 0.5 - self.crafting.EmptyText:GetTall() * 0.5)
	
	self.preview = vgui.Create( "DScrollPanel", self)
	self.preview:Dock(LEFT)
	self.preview:DockMargin(0, 0, 0, 0)
	self.preview:SetSize(400, 600)
	self.preview.Paint = function(self, w, h) 
		surface.SetDrawColor(Color(0, 0, 0, 50))
		surface.DrawRect(0, 0, w, h)
		
		surface.SetDrawColor(Color(150, 150, 150, 20))
		surface.SetMaterial(Material("willardnetworks/tabmenu/crafting/box_pattern.png"))
		surface.DrawTexturedRect(0, 0, w, h)
		
		surface.SetDrawColor(Color(100, 100, 100, 150))
		surface.DrawOutlinedRect(0, 0, w, h)
	end
	
	self.preview.EmptyText = vgui.Create( "DLabel", self.preview)
	self.preview.EmptyText:SetFont("MenuFontBold")
	self.preview.EmptyText:SetText("No item/recipe selected")
	self.preview.EmptyText:SizeToContents()
	self.preview.EmptyText:SetPos(self.preview:GetWide() * 0.5 - self.preview.EmptyText:GetWide() * 0.5, self.preview:GetTall() * 0.5 - self.preview.EmptyText:GetTall() * 0.5)
	
	self.previewModelFrame = self.preview:Add("DFrame")
	self.previewModelFrame:SetSize(self.preview:GetSize())
	self.previewModelFrame.Paint = function(self, w, h) end
	self:SetDFrame(self.previewModelFrame)
	
	self.model = self.previewModelFrame:Add("DModelPanel")
	self.model:SetVisible(false)
	self.model:SetSize(600, 600)

	self:Rebuild()
end

-- A function to rebuild the panel.
function PANEL:Rebuild()
	
	local categories = {}
	local recipesList = {}
	
	for k, v in pairs(PLUGIN.recipe:GetAll()) do
		if (PLUGIN.recipe:CanPlayerSeeRecipe(v)) then
			local recipeCategory = v.category
			recipesList[recipeCategory] = recipesList[recipeCategory] or {}
			recipesList[recipeCategory][#recipesList[recipeCategory] + 1] = v
		end
	end
	
	for k, v in pairs(recipesList) do
		categories[#categories + 1] = {
			recipesList = v,
			category = k
		}
	end
	
	table.sort(categories, function(a, b)
		return a.category < b.category
	end)
	
	PLUGIN:PlayerCraftingRebuilt(self, categories)
	
	for k, v in pairs(categories) do
		local collapsibleCategory = vgui.Create( "DCollapsibleCategory", self.recipes)
			collapsibleCategory:Dock(TOP)
			
			if k == 1 then
				collapsibleCategory:DockMargin(0, 10, 0, 10)
			else
				collapsibleCategory:DockMargin(0, 0, 0, 10)
			end
			
			collapsibleCategory:SetLabel("")
			collapsibleCategory:SetExpanded( false )
			collapsibleCategory.Paint = function(self, w, h)
				if collapsibleCategory:GetExpanded() then
					surface.SetDrawColor(Color(255, 255, 255, 255))	
					surface.SetMaterial( Material("willardnetworks/tabmenu/crafting/minus.png"))
					surface.DrawTexturedRect(20, 20 * 0.5 - 15 * 0.5, 15, 15)
				else
					surface.SetDrawColor(Color(255, 255, 255, 255))	
					surface.SetMaterial( Material("willardnetworks/tabmenu/crafting/plus.png"))
					surface.DrawTexturedRect(20, 20 * 0.5 - 15 * 0.5, 15, 15)
				end
			end
			
		local categoryTitle = vgui.Create("DLabel", collapsibleCategory)
		categoryTitle:SetText(v.category)
		categoryTitle:SetFont("MenuFontBold")
		categoryTitle:SizeToContents()
		categoryTitle:SetPos(40, collapsibleCategory:GetTall() * 0.5 - categoryTitle:GetTall() * 0.5 + 1)
		
		local categoryList = vgui.Create("DScrollPanel", collapsibleCategory)
			categoryList:Dock(FILL)
		collapsibleCategory:SetContents(categoryList)
		
		table.sort(v.recipesList, function(a, b)
			return a.name < b.name
		end)
		
		for k2, v2 in pairs(v.recipesList) do
			self.recipeData = {
				recipe = v2
			}
			
			if self.recipeData.recipe.subcategory then
				local collapsibleSubCategory = vgui.Create("DCollapsibleCategory", collapsibleCategory)
				collapsibleSubCategory:Dock(TOP)
				collapsibleSubCategory:SetLabel("")
				collapsibleSubCategory:DockMargin(0, 5, 0, 0)
				collapsibleSubCategory:SetExpanded( false )
				collapsibleSubCategory.Paint = function(self, w, h)
					if collapsibleSubCategory:GetExpanded() then
						surface.SetDrawColor(Color(255, 255, 255, 255))	
						surface.SetMaterial( Material("willardnetworks/tabmenu/crafting/minus.png"))
						surface.DrawTexturedRect(40, 20 * 0.5 - 15 * 0.5, 15, 15)
					else
						surface.SetDrawColor(Color(255, 255, 255, 255))	
						surface.SetMaterial( Material("willardnetworks/tabmenu/crafting/plus.png"))
						surface.DrawTexturedRect(40, 20 * 0.5 - 15 * 0.5, 15, 15)
					end
				end
				
				local subcategoryTitle = vgui.Create("DLabel", collapsibleSubCategory)
				subcategoryTitle:SetText(self.recipeData.recipe.subcategory)
				subcategoryTitle:SetFont("MenuFont")
				subcategoryTitle:SizeToContents()
				subcategoryTitle:SetPos(60, collapsibleSubCategory:GetTall() * 0.5 - subcategoryTitle:GetTall() * 0.5 + 1)
				
				local subcategoryList = vgui.Create("DScrollPanel", collapsibleSubCategory)
					subcategoryList:Dock(FILL)
					subcategoryList.isSubCategory = true
				collapsibleSubCategory:SetContents(subcategoryList)
				
				subcategoryList:AddItem(vgui.Create("ixCraftingItem", self))
			else
				categoryList:AddItem(vgui.Create("ixCraftingItem", self))
			end
		end
	end
	
	--Derma
	self.craftingFrame = vgui.Create("DScrollPanel", self.crafting)
	self.craftingFrame:SetSize(self.crafting:GetWide() - 60, self.crafting:GetTall() - 60)
	self.craftingFrame:SetPos(self.crafting:GetWide() * 0.5 - self.craftingFrame:GetWide() * 0.5, self.crafting:GetTall() * 0.5 - self.craftingFrame:GetTall() * 0.5)
	
	self.craftingTopFrame = self.craftingFrame:Add("DFrame")
	self.craftingTopFrame:Dock(TOP)
	self.craftingTopFrame:DockMargin(0, 0, 0, 10)
	self.craftingTopFrame:SetSize(self.craftingFrame:GetWide(), 110)
	self.craftingTopFrame.Paint = function(self, w, h) end
	
	self.iconFrame = self.craftingTopFrame:Add("DFrame")
	self.iconFrame:Dock(LEFT)
	self.iconFrame:DockMargin(-5, -29, 0, 0)
	self.iconFrame:SetSize(100, 100)
	self.iconFrame.Paint = function(self, w, h) end
	
	self.itemIcon = self.iconFrame:Add("SpawnIcon")
	self.itemIcon:SetModel("");
	self.itemIcon:SetSize(100, 100)
	self.itemIcon:SetVisible(false)
	self.itemIcon.PaintOver = function(self, w, h) end
	
	self.craftingTextFrame = self.craftingTopFrame:Add("DFrame")
	self.craftingTextFrame:Dock(LEFT)
	self.craftingTextFrame:DockMargin(0, -29, 0, 0)
	self.craftingTextFrame:SetSize(self.craftingFrame:GetWide() - 100, 100)
	self.craftingTextFrame.Paint = function(self, w, h) end
	
	self.itemTitle = self.craftingTextFrame:Add("DLabel")
	self.itemTitle:SetVisible(false)
	
	self.itemDesc = self.craftingTextFrame:Add("DLabel")
	self.itemDesc:SetVisible(false)
	
	self.itemLevelUp = self.craftingTextFrame:Add("DLabel")
	self.itemLevelUp:SetVisible(false)
	
	self.craftingAttributeFrame = self.craftingFrame:Add("DFrame")
	self.craftingAttributeFrame:SetSize(self.craftingFrame:GetWide(), 60)
	self.craftingAttributeFrame:Dock(TOP)
	self.craftingAttributeFrame:DockMargin(0, 0, 0, 14)
	self.craftingAttributeFrame:SetVisible(false)
	self.craftingAttributeFrame.Paint = function(self, w, h) 
		surface.SetDrawColor(Color(0, 0, 0, 150))
		surface.DrawRect(0, 0, w, h)
	
		surface.SetDrawColor(Color(100, 100, 100, 150))
		surface.DrawOutlinedRect(0, 0, w, h)
	end
	
	self.craftingAttributeText = self.craftingAttributeFrame:Add("DLabel")
	self.craftingAttributeText:SetText("")
	self.craftingAttributeFrame:SetVisible(false)
	
	self.requirementsFrame = self.craftingFrame:Add("DFrame")
	self.requirementsFrame:SetSize(self.craftingFrame:GetWide(), 55)
	self.requirementsFrame:Dock(TOP)
	self.requirementsFrame:SetVisible(false)
	self.requirementsFrame.Paint = function(self, w, h) end
	
	self.requirementsTitle = self.requirementsFrame:Add("DLabel")
	self.requirementsTitle:SetFont("MenuFont")
	self.requirementsTitle:SetText("Requirements: ")
	self.requirementsTitle:SetTextColor(Color(255, 204, 0, 255))
	self.requirementsTitle:SizeToContents()
	
	self.requirementsText = self.requirementsFrame:Add("DLabel")
	self.requirementsText:SetText("")
	
	self.ingredientsTitle = self.requirementsFrame:Add("DLabel")
	self.ingredientsTitle:SetFont("MenuFont")
	self.ingredientsTitle:SetText("Ingredients:")
	self.ingredientsTitle:SetTextColor(Color(255, 204, 0, 255))
	self.ingredientsTitle:SetPos(0, self.requirementsTitle:GetTall() + 3)
	self.ingredientsTitle:SizeToContents()
	
	self.ingredients = self.craftingFrame:Add("DScrollPanel")
	self.ingredients:Dock(TOP)
	self.ingredients:SetSize(self.craftingFrame:GetWide(), 245)
	self.ingredients:DockMargin(0, 0, 0, 15)
	
	self.craftButton = self.craftingFrame:Add("DButton")
	self.craftButton:SetVisible(false)
	
	self:SetDFrame(self.requirementsFrame)
	self:SetDFrame(self.craftingAttributeFrame)
	self:SetDFrame(self.craftingTextFrame)
	self:SetDFrame(self.iconFrame)
	self:SetDFrame(self.craftingTopFrame)
end

function PANEL:SetDFrame(frame)
	frame:ShowCloseButton(false)
	frame:SetDeleteOnClose(true)
	frame:SetDraggable( false )
	frame:SetTitle("")
end

-- Called when the panel is painted.
function PANEL:Paint(w, h) end

function PANEL:Remove()
	self.model:Remove()
end

vgui.Register("ixCrafting", PANEL, "EditablePanel")

local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()
	local recipeData = self:GetParent().recipeData
		self:SetSize(self:GetParent():GetWide(), 20)
		self.recipe = recipeData.recipe
	PLUGIN:PlayerAdjustCraftingRecipe(self.recipe)
	
	local model = PLUGIN.recipe:GetIconInfo(self.recipe)
	self.recipeButton = self:Add("DButton")
	
	-- Called when the spawn icon is clicked.
	function self.recipeButton.DoClick(spawnIcon)
		surface.PlaySound("helix/ui/press.wav")
		self:RebuildCrafting()
	end
	
	self.recipeButton:SetContentAlignment(4)
	
	if recipeData.recipe.subcategory then
		self.recipeButton:SetTextInset(61, 0)
	else
		self.recipeButton:SetTextInset(41, 0)
	end
	
	self.recipeButton:SetFont("MenuFont")
	self.recipeButton:SetText(self.recipe.name)
	self.recipeButton:SetSize(self:GetParent():GetWide(), 20)
	
	self.recipeButton.OnCursorEntered = function()
		surface.PlaySound("helix/ui/rollover.wav")
	end
end

function PANEL:Paint(w, h)
	local color = Color(255, 255, 255, 255)
	if (PLUGIN.recipe:PlayerCanCraftRecipe(self.recipe, LocalPlayer(), LocalPlayer():GetCharacter():GetInventory())) then
		color = Color(255, 204, 0, 255)
	end
	
	self.recipeButton.Paint = function(self, w, h) 
		if self:IsHovered() then
			self:SetTextColor(color)
			local gradient = Material("willardnetworks/tabmenu/crafting/leftgradient.png")
			surface.SetDrawColor(ColorAlpha(color_white, 22))
			surface.SetMaterial(gradient)
			surface.DrawTexturedRect(0, 0, self:GetWide(), h)
		end
	end
end

-- Called each frame.
function PANEL:Think()
	local color = Color(150, 150, 150, 255)
	if (PLUGIN.recipe:PlayerCanCraftRecipe(self.recipe, LocalPlayer(), LocalPlayer():GetCharacter():GetInventory())) then
		color = Color(255, 204, 0, 255)
	end

	self.recipeButton:SetTextColor(color)
end

function PANEL:RebuildCrafting()
	local parentFrame = parentFrame
		
	if not self.recipe.subcategory then
		parentFrame = self:GetParent():GetParent():GetParent():GetParent():GetParent():GetParent()
	else
		parentFrame = self:GetParent():GetParent():GetParent():GetParent():GetParent():GetParent():GetParent()
	end
	
	local model, skin = PLUGIN.recipe:GetIconInfo(self.recipe);
	parentFrame.itemIcon:SetModel(model, skin);
	parentFrame.itemIcon:SetVisible(true)
	parentFrame.itemIcon.PaintOver = function(self, w, h) end
	
	parentFrame.ingredients:Clear()
	
	parentFrame.iconFrame.Paint = function(self, w, h) 
		surface.SetDrawColor(Color(0, 0, 0, 150))
		surface.DrawRect(0, 0, w, h)
	
		surface.SetDrawColor(Color(100, 100, 100, 150))
		surface.DrawOutlinedRect(0, 0, w, h)
	end
	
	for k, v in pairs(ix.item.list) do
		for k2, v2 in pairs(self.recipe.ingredients) do
			if v.uniqueID == k2 then			
				local ingredientsFrame = parentFrame.ingredients:Add("DFrame")
				ingredientsFrame:SetSize(parentFrame.craftingFrame:GetWide(), 83)
				ingredientsFrame:Dock(TOP)
				ingredientsFrame.name = v.name
				ingredientsFrame.Paint = function(self, w, h) end
				parentFrame:SetDFrame(ingredientsFrame)
				
				parentFrame.ingredientIconFrame = ingredientsFrame:Add("DFrame")
				parentFrame.ingredientIconFrame:Dock(LEFT)
				parentFrame.ingredientIconFrame:DockMargin(-5, -29, 0, 0)
				parentFrame.ingredientIconFrame:SetSize(100, 75)
				parentFrame.ingredientIconFrame.Paint = function(self, w, h) 
					surface.SetDrawColor(Color(0, 0, 0, 150))
					surface.DrawRect(0, 0, w, h)
				
					surface.SetDrawColor(Color(100, 100, 100, 150))
					surface.DrawOutlinedRect(0, 0, w, h)
				end
				parentFrame:SetDFrame(parentFrame.ingredientIconFrame)
				
				local model = v.model
				
				parentFrame.ingredientItemIcon = parentFrame.ingredientIconFrame:Add("SpawnIcon")
				parentFrame.ingredientItemIcon:SetModel(model)
				parentFrame.ingredientItemIcon:SetSize(50, 50)
				parentFrame.ingredientItemIcon:SetPos(parentFrame.ingredientIconFrame:GetWide() * 0.5 - parentFrame.ingredientItemIcon:GetWide() * 0.5, parentFrame.ingredientIconFrame:GetTall() * 0.5 - parentFrame.ingredientItemIcon:GetTall() * 0.5)
				parentFrame.ingredientItemIcon:SetVisible(true)
				parentFrame.ingredientItemIcon.PaintOver = function(self, w, h) end
				
				local function CharIngredientAmount()
					local count = {}
					local items = LocalPlayer():GetCharacter():GetInventory():GetItems()
					
					if (!table.IsEmpty(count)) then
						table.remove(count)
					end
					
					for _, v in pairs(items) do
						if v.uniqueID == k2 then
							table.insert(count, v)
						end
					end
					
					return table.Count( count ) or 0
				end
				
				parentFrame.ingredientItemText = parentFrame.ingredientIconFrame:Add("DLabel")
				parentFrame.ingredientItemText:SetFont("MenuFont")
				parentFrame.ingredientItemText:SetText(CharIngredientAmount().."/"..v2)
				parentFrame.ingredientItemText:SizeToContents()
				parentFrame.ingredientItemText:SetPos(parentFrame.ingredientIconFrame:GetWide() - parentFrame.ingredientItemText:GetWide() - 5, parentFrame.ingredientIconFrame:GetTall() - parentFrame.ingredientItemText:GetTall())
				
				parentFrame.ingredientTextFrame = ingredientsFrame:Add("DFrame")
				parentFrame.ingredientTextFrame:Dock(LEFT)
				parentFrame.ingredientTextFrame:DockMargin(0, -29, 0, 0)
				parentFrame.ingredientTextFrame:SetSize(parentFrame.craftingFrame:GetWide() - 100, 83)
				parentFrame.ingredientTextFrame.Paint = function(self, w, h) end
				parentFrame:SetDFrame(parentFrame.ingredientTextFrame)
				
				parentFrame.ingredientTitle = parentFrame.ingredientTextFrame:Add("DLabel")
				parentFrame.ingredientTitle:SetFont("SmallerTitleFont")
				parentFrame.ingredientTitle:SetText(v.name)
				parentFrame.ingredientTitle:SetVisible(true)
				parentFrame.ingredientTitle:SetWide(parentFrame.craftingTextFrame:GetWide() - 10)
				parentFrame.ingredientTitle:SetWrap(true)
				parentFrame.ingredientTitle:SetAutoStretchVertical(true)
				parentFrame.ingredientTitle:Dock(TOP)
				parentFrame.ingredientTitle:DockMargin(5, -33, 0, 5)
				
				parentFrame.ingredientDesc = parentFrame.ingredientTextFrame:Add("DLabel")
				parentFrame.ingredientDesc:SetFont("MenuFont")
				parentFrame.ingredientDesc:SetText(v.description)
				parentFrame.ingredientDesc:SetVisible(true)
				parentFrame.ingredientDesc:SetWide(parentFrame.craftingTextFrame:GetWide() - 10)
				parentFrame.ingredientDesc:SetWrap(true)
				parentFrame.ingredientDesc:SetAutoStretchVertical(true)
				parentFrame.ingredientDesc:Dock(TOP)
				parentFrame.ingredientDesc:DockMargin(5, 0, 0, 5)
				
				parentFrame.craftButton:SetVisible(true)
				parentFrame.craftButton:SetFont("MenuFontBold")
				parentFrame.craftButton:SetText("Create "..self.recipe.name)
				parentFrame.craftButton:SetTextColor(Color(50, 50, 50, 255))
				parentFrame.craftButton:Dock(TOP)
				parentFrame.craftButton:SizeToContents()
				parentFrame.craftButton:SetTall(30)
				parentFrame.craftButton.Paint = function(self, w, h)
					surface.SetDrawColor(255, 204, 0, 255)
					surface.DrawRect(0, 0, w, h)
				end	
				
				parentFrame.craftButton.DoClick = function()
					surface.PlaySound("helix/ui/press.wav")
					netstream.Start("CraftRecipe", self.recipe)
					timer.Simple(0.1, function()
						parentFrame.ingredientItemText:SetText(CharIngredientAmount().."/"..v2)
					end)
				end
				
				parentFrame.craftButton.OnCursorEntered = function()
					surface.PlaySound("helix/ui/rollover.wav")
					parentFrame.craftButton:SetTextColor(Color(20, 20, 20, 255))
					parentFrame.craftButton.Paint = function(self, w, h)
						surface.SetDrawColor(213, 170, 0, 255)
						surface.DrawRect(0, 0, w, h)
					end	
				end
				
				parentFrame.craftButton.OnCursorExited = function()
					parentFrame.craftButton:SetTextColor(Color(50, 50, 50, 255))
					parentFrame.craftButton.Paint = function(self, w, h)
						surface.SetDrawColor(255, 204, 0, 255)
						surface.DrawRect(0, 0, w, h)
					end	
				end
			end
		end
	end
	
	parentFrame.itemTitle:SetFont("SmallerTitleFont")
	parentFrame.itemTitle:SetText(self.recipe.name)
	parentFrame.itemTitle:SetVisible(true)
	parentFrame.itemTitle:SetWide(parentFrame.craftingTextFrame:GetWide() - 10)
	parentFrame.itemTitle:SetWrap(true)
	parentFrame.itemTitle:SetAutoStretchVertical(true)
	parentFrame.itemTitle:Dock(TOP)
	parentFrame.itemTitle:DockMargin(5, -33, 0, 5)
	
	parentFrame.itemDesc:SetFont("MenuFont")
	parentFrame.itemDesc:SetText(self.recipe.description)
	parentFrame.itemDesc:SetVisible(true)
	parentFrame.itemDesc:SetWide(parentFrame.craftingTextFrame:GetWide() - 10)
	parentFrame.itemDesc:SetWrap(true)
	parentFrame.itemDesc:SetAutoStretchVertical(true)
	parentFrame.itemDesc:Dock(TOP)
	parentFrame.itemDesc:DockMargin(5, 0, 0, 5)
	
	parentFrame.itemLevelUp:SetFont("MenuFont")
	parentFrame.itemLevelUp:SetText("This item will not level up crafting")
	parentFrame.itemLevelUp:SetTextColor(Color(191, 66, 67, 255))
	parentFrame.itemLevelUp:SetVisible(true)
	parentFrame.itemLevelUp:Dock(TOP)
	parentFrame.itemLevelUp:DockMargin(5, 0, 0, 0)
	
	parentFrame.craftingAttributeFrame:SetVisible(true)
	parentFrame.craftingAttributeText:SetFont("MenuFont")
	parentFrame.craftingAttributeText:SetText("This item offers no attribute boosts")
	parentFrame.craftingAttributeText:SetVisible(true)
	parentFrame.craftingAttributeText:SizeToContents()
	parentFrame.craftingAttributeText:SetPos(parentFrame.craftingAttributeFrame:GetWide() * 0.5 - parentFrame.craftingAttributeText:GetWide() * 0.5, parentFrame.craftingAttributeFrame:GetTall() * 0.5 - parentFrame.craftingAttributeText:GetTall() * 0.5)
	parentFrame.craftingAttributeFrame:SetVisible(true)
	
	parentFrame.requirementsFrame:SetVisible(true)
	parentFrame.requirementsText:SetFont("MenuFont")
	parentFrame.requirementsText:SetText(string.gsub( (self.recipe.station or self.recipe.license or "no requirements"), "^.", string.upper ))
	parentFrame.requirementsText:SetPos(parentFrame.requirementsTitle:GetWide())
	parentFrame.requirementsText:SizeToContents()
	
	parentFrame.crafting.EmptyText:SetVisible(false)
	parentFrame.preview.EmptyText:SetVisible(false)
	parentFrame.model:SetVisible(true)
	
	if ix.item.list[self.recipe.uniqueID] and ix.item.list[self.recipe.uniqueID].base == "base_clothing" then
		parentFrame.model:SetPos(-118, 0)
		parentFrame.model:SetModel(LocalPlayer():GetModel())

		parentFrame.model.bodygroups = {}

		function parentFrame.model:LayoutEntity(Entity)
			Entity:SetAngles(Angle(0,45,0))
			local sequence = Entity:SelectWeightedSequence(ACT_IDLE)

			if (sequence <= 0) then
				sequence = Entity:LookupSequence("idle_unarmed")
			end

			if (sequence > 0) then
				Entity:ResetSequence(sequence)
			else
				local found = false

				for _, v in ipairs(Entity:GetSequenceList()) do
					if ((v:lower():find("idle") or v:lower():find("fly")) and v != "idlenoise") then
						Entity:ResetSequence(v)
						found = true

						break
					end
				end

				if (!found) then
					Entity:ResetSequence(4)
				end
			end
			
			Entity:SetIK(false)
			
			Entity:FrameAdvance(RealTime() * 0.5)
		end
	else
		parentFrame.model:SetModel(self.recipe.model)
		parentFrame.model:SetSize(parentFrame.model:GetSize())
		parentFrame.model:Center()
		
		local mn, mx = parentFrame.model.Entity:GetRenderBounds()
		local size = 0
		size = math.max( size, math.abs( mn.x ) + math.abs( mx.x ) )
		size = math.max( size, math.abs( mn.y ) + math.abs( mx.y ) )
		size = math.max( size, math.abs( mn.z ) + math.abs( mx.z ) )
		
		parentFrame.model:SetFOV( 90 )
		parentFrame.model:SetCamPos( Vector( size, size, size ) )
		parentFrame.model:SetLookAt( ( mn + mx ) * 0.5 )
	end
end
	
vgui.Register("ixCraftingItem", PANEL, "DPanel")

hook.Add("CreateMenuButtons", "ixCrafting", function(tabs)
	tabs["Crafting"] = {
		
		RowNumber = 6,
		
		Width = 18,
		
		Height = 18,
		
		Icon = "willardnetworks/tabmenu/navicons/crafting.png",
	
		Create = function(info, container)
			local newContainer = container:Add("DFrame")
			newContainer:ShowCloseButton(false)
			newContainer:SetDeleteOnClose(true)
			newContainer:SetDraggable( false )
			newContainer:SetTitle("")
			newContainer:SetSize(1240, 630)
			newContainer:SetPos(ScrW() * 0.5 - newContainer:GetWide() * 0.5 - 25, 150)
			
			newContainer.Paint = function(self, w, h) end
			
			local recipesIcon = newContainer:Add("DImage")
			recipesIcon:SetImage("willardnetworks/tabmenu/charmenu/licenses.png")
			recipesIcon:SetSize(20, 20)
			recipesIcon:SetPos(-2, 2)
			
			local recipesTitle = newContainer:Add("DLabel")
			recipesTitle:SetFont("TitlesFont")
			recipesTitle:SetText("Recipes")
			recipesTitle:SetPos(24)
			recipesTitle:SizeToContents()
			
			local craftingIcon = newContainer:Add("DImage")
			craftingIcon:SetImage("willardnetworks/tabmenu/navicons/crafting.png")
			craftingIcon:SetSize(18, 18)
			craftingIcon:SetPos(420, 4)
			
			local craftingTitle = newContainer:Add("DLabel")
			craftingTitle:SetFont("TitlesFont")
			craftingTitle:SetText("Crafting")
			craftingTitle:SetPos(444)
			craftingTitle:SizeToContents()
			
			local previewIcon = newContainer:Add("DImage")
			previewIcon:SetImage("willardnetworks/tabmenu/charmenu/name.png")
			previewIcon:SetSize(20, 20)
			previewIcon:SetPos(839, 2)
			
			local previewTitle = newContainer:Add("DLabel")
			previewTitle:SetFont("TitlesFont")
			previewTitle:SetText("Preview")
			previewTitle:SetPos(864)
			previewTitle:SizeToContents()

			local panel = newContainer:Add("ixCrafting")
			
			ix.gui.craftingpanel = panel
		end
	}
end)