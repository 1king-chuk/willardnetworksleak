local PLUGIN = PLUGIN

PLUGIN.name = "Bag System"
PLUGIN.author = "Fruity"
PLUGIN.description = "A simple bag system."

if (SERVER) then
	function PLUGIN:PlayerLoadedCharacter(client)
		local character = client:GetCharacter()
		local inventory = character:GetInventory()
		
		if (!inventory:HasItem("pockets")) then
			inventory:Add("pockets")
		end
	end
end