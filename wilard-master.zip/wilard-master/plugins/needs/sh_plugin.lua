
PLUGIN.name = "Needs"
PLUGIN.author = "SleepyMode"
PLUGIN.description = "Implements needs."

ix.char.RegisterVar("hunger", {
	default = 0,
	bNoDisplay = true
})

ix.char.RegisterVar("thirst", {
	default = 0,
	bNoDisplay = true
})

ix.config.Add("killOnMaxNeeds", false, "Enable players being killed when reaching max hunger or thirst", nil, {
	category = "needs"
})

ix.config.Add("hungerHours", 6, "How many hours it takes for a player to gain 60 hunger", nil, {
	category = "needs"
})

ix.config.Add("thirstHours", 4, "How many hours it takes for a player to gain 60 thirst", nil, {
	category = "needs"
})

ix.config.Add("needsTickTime", 300, "How many seconds between each time a player's needs are calculated", nil, {
	category = "needs"
})

ix.util.Include("cl_plugin.lua")
ix.util.Include("sv_hooks.lua")