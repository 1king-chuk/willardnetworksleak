
local PLUGIN = PLUGIN

ix.bar.Add(function()
	local character = LocalPlayer():GetCharacter()

	local value = 0
	local text = "Unknown"

	if (character) then
		local hunger = character:GetHunger()
		value = hunger

		if (hunger <= 50) then
			text = "Satisfied"
		elseif (hunger <= 60) then
			text = "Slightly Hungry"
		elseif (hunger <= 80) then
			text = "Hungry"
		elseif (hunger <= 90) then
			text = "Very Hungry"
		elseif (hunger <= 100) then
			text = "Starving"
		end
	end

	return value, text
end, Color(200, 200, 40), nil, "hunger")

ix.bar.Add(function()
	local character = LocalPlayer():GetCharacter()

	local value = 0
	local text = "Unknown"

	if (character) then
		local thirst = character:GetThirst()
		value = thirst

		if (thirst <= 50) then
			text = "Satisfied"
		elseif (thirst <= 60) then
			text = "Slightly Thirsty"
		elseif (thirst <= 80) then
			text = "Thirsty"
		elseif (thirst <= 90) then
			text = "Very Thirsty"
		elseif (thirst <= 100) then
			text = "Dehydrated"
		end
	end

	return value, text
end, Color(0, 119, 201), nil, "thirst")