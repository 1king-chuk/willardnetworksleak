
ITEM.name = "Consumable Base"
ITEM.model = Model("models/props_junk/garbage_takeoutcarton001a.mdl")
ITEM.description = "A base for consumables."
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Consumable"

ITEM.useSound = {"npc/barnacle/barnacle_crunch3.wav", "npc/barnacle/barnacle_crunch2.wav"}

ITEM.hunger = 0
ITEM.thirst = 0
ITEM.health = 0
ITEM.damage = 0

ITEM.functions.Consume = {
	OnRun = function(item)
		local client = item.player
		local character = item.player:GetCharacter()

		if (item.thirst > 0) then
			character:SetThirst(math.Clamp(character:GetThirst() - item.thirst, 0, 100))
		end

		if (item.hunger > 0) then
			character:SetHunger(math.Clamp(character:GetHunger() - item.hunger, 0, 100))
		end

		if (item.health > 0) then
			client:SetHealth(math.Clamp(client:Health() + item.health, 0, client:GetMaxHealth()))
		end

		if (item.damage > 0) then
			client:TakeDamage(item.damage, client, client)
		end

		client:EmitSound(table.Random(item.useSound))

		-- Spawn the junk item if it exists
		if (item.junk) then
			if (!character:GetInventory():Add(item.junk)) then
				ix.item.Spawn(item.junk, client)
			end
		end
	end
}