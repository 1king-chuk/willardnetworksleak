ITEM.name = "Yellow Worker's Shirt"
ITEM.uniqueID = "yellow_worker_shirt"
ITEM.description = "A thick and strong yellow worker's shirt."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 12
}
