ITEM.name = "Grey Jumper"
ITEM.uniqueID = "grey_jumper"
ITEM.description = "A grey, soft jumper."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 3
}
