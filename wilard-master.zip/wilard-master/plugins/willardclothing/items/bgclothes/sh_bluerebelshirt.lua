ITEM.name = "Blue Resistance Uniform"
ITEM.uniqueID = "blue_rebel_shirt"
ITEM.description = "A padded and sewn blue uniform."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 14
}
