ITEM.name = "Orange Worker's Shirt"
ITEM.uniqueID = "orange_worker_shirt"
ITEM.description = "A thick and strong orange worker's shirt."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 13
}
