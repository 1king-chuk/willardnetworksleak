ITEM.name = "Glasses"
ITEM.uniqueID = "glasses"
ITEM.description = "A fashionable pair of glasses."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Head"

ITEM.bodyGroups = {
	["head"] = 6
}
