ITEM.name = "Army Helmet"
ITEM.uniqueID = "army_helmet"
ITEM.description = "A beaten, green metallic helmet."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Head"

ITEM.bodyGroups = {
	["head"] = 7
}
