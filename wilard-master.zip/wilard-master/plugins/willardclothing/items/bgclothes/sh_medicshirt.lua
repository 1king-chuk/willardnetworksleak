ITEM.name = "Medical Shirt"
ITEM.uniqueID = "medical_shirt"
ITEM.description = "A thick, cotton shirt with a medic patch."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 7
}
