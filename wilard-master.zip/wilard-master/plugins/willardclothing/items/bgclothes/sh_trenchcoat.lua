ITEM.name = "Brown Trench Coat"
ITEM.uniqueID = "trenchcoat"
ITEM.description = "A weird looking coat."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 20
}
