ITEM.name = "Reinforced Blue Shirt"
ITEM.uniqueID = "reinforced_blue_shirt"
ITEM.description = "A padded and sewn blue uniform with added kevlar."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 18
}
