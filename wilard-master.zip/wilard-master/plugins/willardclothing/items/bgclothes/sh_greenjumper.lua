ITEM.name = "Green Jumper"
ITEM.uniqueID = "green_jumper"
ITEM.description = "A green, soft jumper."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 5
}
