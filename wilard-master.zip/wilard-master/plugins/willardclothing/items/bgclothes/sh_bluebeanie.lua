ITEM.name = "Blue Beanie"
ITEM.uniqueID = "blue_beanie"
ITEM.description = "A blue, woolie beanie."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Head"

ITEM.bodyGroups = {
	["head"] = 2
}
