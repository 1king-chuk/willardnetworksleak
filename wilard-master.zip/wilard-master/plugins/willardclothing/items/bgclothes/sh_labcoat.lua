ITEM.name = "Labcoat"
ITEM.uniqueID = "labcoat"
ITEM.description = "A large, hanging labcoat with pockets."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 11
}
