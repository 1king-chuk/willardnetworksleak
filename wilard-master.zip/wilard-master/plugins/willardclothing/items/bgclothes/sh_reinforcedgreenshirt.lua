ITEM.name = "Reinforced Green Shirt"
ITEM.uniqueID = "reinforced_green_shirt"
ITEM.description = "A padded and sewn green uniform with added kevlar."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 17
}
