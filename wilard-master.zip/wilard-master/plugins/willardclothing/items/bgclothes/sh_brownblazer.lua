ITEM.name = "Brown Formal Blazer"
ITEM.uniqueID = "brown_blazer"
ITEM.description = "A well-fitted brown blazer."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 10
}
