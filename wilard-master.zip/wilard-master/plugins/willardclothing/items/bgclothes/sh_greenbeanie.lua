ITEM.name = "Green Beanie"
ITEM.uniqueID = "green_beanie"
ITEM.description = "A green, woolie beanie."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Head"

ITEM.bodyGroups = {
	["head"] = 3
}
