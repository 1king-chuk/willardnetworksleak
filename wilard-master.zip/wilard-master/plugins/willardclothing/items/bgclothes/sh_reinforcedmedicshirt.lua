ITEM.name = "Reinforced Medic Shirt"
ITEM.uniqueID = "reinforced_medic_shirt"
ITEM.description = "A padded and sewn white uniform with added kevlar and medical patches."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 19
}
