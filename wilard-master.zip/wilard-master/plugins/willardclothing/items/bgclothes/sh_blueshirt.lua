ITEM.name = "Blue Shirt"
ITEM.uniqueID = "blue_shirt"
ITEM.description = "A blue, uncomfortable shirt."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 1
}
