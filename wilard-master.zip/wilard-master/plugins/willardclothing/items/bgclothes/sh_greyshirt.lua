ITEM.name = "Grey Shirt"
ITEM.uniqueID = "Grey_shirt"
ITEM.description = "A Grey, uncomfortable shirt."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 2
}
