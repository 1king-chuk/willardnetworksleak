ITEM.name = "Green Resistance Uniform"
ITEM.uniqueID = "green_rebel_shirt"
ITEM.description = "A padded and sewn green uniform."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 13
}
