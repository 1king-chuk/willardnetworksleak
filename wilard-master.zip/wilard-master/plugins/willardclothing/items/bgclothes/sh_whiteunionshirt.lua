ITEM.name = "UU White Shirt"
ITEM.uniqueID = "uu_white_shirt"
ITEM.description = "A thin white shirt with a small Union badge on the sleeve."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 8
}
