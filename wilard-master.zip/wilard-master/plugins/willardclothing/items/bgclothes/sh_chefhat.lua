ITEM.name = "Chef's Hat"
ITEM.uniqueID = "chefhat"
ITEM.description = "A hat for the finest chefs."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Head"

ITEM.bodyGroups = {
	["head"] = 1
}
