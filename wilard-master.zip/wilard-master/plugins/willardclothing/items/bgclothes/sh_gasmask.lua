ITEM.name = "Full-Face Gasmask"
ITEM.uniqueID = "full_gasmask"
ITEM.description = "An old Soviet gasmask."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Head"

ITEM.bodyGroups = {
	["head"] = 5
}
