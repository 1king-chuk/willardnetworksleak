ITEM.name = "Maroon Jumper"
ITEM.uniqueID = "maroon_jumper"
ITEM.description = "A maroon, soft jumper."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 3
}
