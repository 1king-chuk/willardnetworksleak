ITEM.name = "Medical Resistance Uniform"
ITEM.uniqueID = "medic_rebel_shirt"
ITEM.description = "A padded and sewn white uniform with kevlar and medical patches."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 16
}
