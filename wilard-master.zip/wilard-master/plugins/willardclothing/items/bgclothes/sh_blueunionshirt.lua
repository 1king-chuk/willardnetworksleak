ITEM.name = "UU Blue Shirt"
ITEM.uniqueID = "uu_blue_shirt"
ITEM.description = "A thin blue shirt with a small Union badge on the sleeve."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 9
}
