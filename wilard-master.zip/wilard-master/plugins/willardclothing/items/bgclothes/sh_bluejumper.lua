ITEM.name = "Blue Jumper"
ITEM.uniqueID = "blue_jumper"
ITEM.description = "A blue, soft jumper."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Torso"

ITEM.bodyGroups = {
	["torso"] = 6
}
