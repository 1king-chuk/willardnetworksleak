ITEM.name = "Mouth Cover"
ITEM.uniqueID = "mouth_cover"
ITEM.description = "A patterned piece of fabric."
ITEM.category = "Outfit"
ITEM.outfitCategory = "Head"

ITEM.bodyGroups = {
	["head"] = 3
}
