
local PLUGIN = PLUGIN

PLUGIN.name = "Willard Clothing System"
PLUGIN.author = "Gary Tate"
PLUGIN.description = "Allows for items/clothing to be able to set bodygroups."
