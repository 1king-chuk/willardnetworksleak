LANGUAGE = {
	cmdCreateCustomScript = "Create a custom script."
}
