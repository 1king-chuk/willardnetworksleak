local playerMeta = FindMetaTable("Player")

function playerMeta:IsCombine()
	local faction = self:Team()
	return faction == FACTION_MPF or faction == FACTION_OTA or faction == FACTION_OVERWATCH
end

function playerMeta:ShouldHaveCombineVCs()
	local faction = self:Team()
	return faction == FACTION_MPF or faction == FACTION_OTA
end

function playerMeta:IsDispatch()
	return self:Team() == FACTION_OVERWATCH or self:Team() == FACTION_OTA
end
