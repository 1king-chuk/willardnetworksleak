FACTION.name = "Civil Administration"
FACTION.description = "A member of the Civil Authority."
FACTION.color = Color(255, 200, 100, 255)
FACTION.models = {
	"models/humans/group17/female_01.mdl",
	"models/humans/group17/female_02.mdl",
	"models/humans/group17/female_03.mdl",
	"models/humans/group17/female_04.mdl",
	"models/humans/group17/female_06.mdl",
	"models/humans/group17/female_07.mdl",
	"models/humans/group17/male_01.mdl",
	"models/humans/group17/male_02.mdl",
	"models/humans/group17/male_03.mdl",
	"models/humans/group17/male_04.mdl",
	"models/humans/group17/male_05.mdl",
	"models/humans/group17/male_06.mdl",
	"models/humans/group17/male_07.mdl",
	"models/humans/group17/male_08.mdl",
	"models/humans/group17/male_09.mdl"
}
FACTION.isDefault = false
FACTION.isGloballyRecognized = true

FACTION.factionImage = "materials/willardnetworks/faction_imgs/citizen.png"
FACTION.selectImage = "materials/willardnetworks/charselect/citizen2.png"

FACTION.radioChannels = {
	["combine"] = true,
	["cab"] = true
}

FACTION_ADMIN = FACTION.index
