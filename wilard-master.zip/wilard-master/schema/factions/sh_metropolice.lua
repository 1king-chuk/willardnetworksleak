FACTION.name = "Civil Protection"
FACTION.description = "A metropolice unit working as Civil Protection."
FACTION.color = Color(50, 100, 150)
FACTION.models = {"models/police.mdl"}
FACTION.weapons = {"ix_stunstick"}
FACTION.isDefault = false
FACTION.isGloballyRecognized = false
FACTION.runSounds = {[0] = "NPC_MetroPolice.RunFootstepLeft", [1] = "NPC_MetroPolice.RunFootstepRight"}
FACTION.factionImage = "materials/willardnetworks/faction_imgs/cp.png"
FACTION.selectImage = "materials/willardnetworks/charselect/combine.png"

FACTION.radioChannels = {
	["combine"] = true,
	["tac"] = true
}

function FACTION:GetDefaultName(client)
	return "C"
	.. ix.config.Get("cityIndex", "17")
	.. ".i"
	.. (ix.config.Get("operationIndex", "1"))
	.. ":ECHO-"
	.. Schema:ZeroNumber(math.random(1, 9), 1), true

	--return "MPF-RCT." .. Schema:ZeroNumber(math.random(1, 99999), 5), true
end

function FACTION:OnTransfered(client)
	local character = client:GetCharacter()

	character:SetName(self:GetDefaultName())
	character:SetModel(self.models[1])
end

FACTION_MPF = FACTION.index
