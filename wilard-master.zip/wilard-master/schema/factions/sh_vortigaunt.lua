FACTION.name = "Vortigaunt"
FACTION.description = "A free Vortigaunt."
FACTION.color = Color(138, 181, 40)
FACTION.models = {"models/vortigaunt.mdl"}

FACTION.isDefault = false
FACTION.isGloballyRecognized = false

FACTION.factionImage = "materials/willardnetworks/faction_imgs/vort.png"
FACTION.selectImage = "materials/willardnetworks/charselect/vort.png"

function FACTION:OnTransferred(client)
    local character = client:GetCharacter()

    character:SetModel(self.models[1])
end

FACTION_VORT = FACTION.index
