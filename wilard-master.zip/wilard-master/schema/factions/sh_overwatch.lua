FACTION.name = "Overwatch AI"
FACTION.description = "The central Overwatch network."
FACTION.color = Color(150, 50, 50, 255)
FACTION.models = {"models/bloocobalt/combine/combine_s.mdl"}
FACTION.isDefault = false
FACTION.isGloballyRecognized = true
FACTION.runSounds = {[0] = "NPC_CombineS.RunFootstepLeft", [1] = "NPC_CombineS.RunFootstepRight"}

FACTION.radioChannels = {
	["overwatch"] = true,
	["combine"] = true,
	["tac"] = true,
	["cab"] = true
}

function FACTION:GetDefaultName(client)
	return "DISP.AI/XXXXX", false
end

function FACTION:OnTransfered(client)
	local character = client:GetCharacter()

	character:SetName(self:GetDefaultName())
	character:SetModel(self.models[1])
end

function FACTION:OnNameChanged(client, oldValue, value)
	local character = client:GetCharacter()

	if (!Schema:IsCombineRank(oldValue, "SCN") and Schema:IsCombineRank(value, "SCN")
	or !Schema:IsCombineRank(oldValue, "SHIELD") and Schema:IsCombineRank(value, "SHIELD")) then
		Schema:CreateScanner(client, Schema:IsCombineRank(client:Name(), "SHIELD") and "npc_clawscanner" or nil)
	end
end

function FACTION:CanPlayerEnterObserver(client)
	return true
end

FACTION_OVERWATCH = FACTION.index
