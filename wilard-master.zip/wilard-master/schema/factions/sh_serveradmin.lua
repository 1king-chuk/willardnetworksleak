FACTION.name = "Server Administration"
FACTION.description = "Staff members of Willard.Network"
FACTION.color = Color(255, 85, 20, 255)
FACTION.models = {"models/breen.mdl"}
FACTION.isDefault = false
FACTION.isGloballyRecognized = true

function FACTION:GetDefaultName(client)
	return client:SteamName(), false
end

FACTION_SERVERADMIN = FACTION.index
