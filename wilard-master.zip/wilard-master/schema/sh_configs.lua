
ix.currency.symbol = ""
ix.currency.singular = "token"
ix.currency.plural = "tokens"

ix.config.SetDefault("scoreboardRecognition", true)
ix.config.SetDefault("music", "music/hl2_song19.mp3")

ix.config.Add("rationTokens", 20, "The amount of tokens that a person will get from a ration", nil, {
	data = {min = 0, max = 1000},
	category = "economy"
})

ix.config.Add("rationInterval", 300, "How long a person needs to wait in seconds to get their next ration", nil, {
	data = {min = 0, max = 86400},
	category = "economy"
})

-- Overwatch Configuration
ix.config.Add("cityIndex", 17, "The City citizens are residing in.", nil, {
	data = {min = 1, max = 99},
	category = "Overwatch Systems"
})

ix.config.Add("sectorIndex", 10, "The Sector citizens are residing in.", nil, {
	data = {min = 1, max = 30},
	category = "Overwatch Systems"
})

ix.config.Add("operationIndex", 1, "Active operational index.", nil, {
	data = {min = 1, max = 5},
	category = "Overwatch Systems"
})
